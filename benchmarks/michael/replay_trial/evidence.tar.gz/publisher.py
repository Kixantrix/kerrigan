"""Trusted offline MB-006k publisher; fixed runtime paths, never auth traversal."""
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import tarfile

REPO = Path("/Users/mvh/.copilot/repos/copilot-worktrees/kerrigan/kixantrix-redesigned-barnacle")
OWNED = Path("/Users/mvh/.copilot/session-state/a45ee9a4-394e-4af7-afba-d8f78ae19672/files/local-mxc")
ROOT = OWNED / "mb006k-final-proof-2"
ROOT.mkdir(mode=0o700)
sys.path.insert(0, str(REPO))
from benchmarks.michael.replay_trial import api
import pytest

def sha(data):
    return hashlib.sha256(data).hexdigest()

def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode() + b"\n"

def read(path):
    return json.loads(path.read_bytes())

def git(*args):
    return subprocess.check_output(["git", *args], cwd=REPO)

slots = [OWNED / namespace / f"{model}.json"
         for namespace in ("canary-slots", "mb006f/slots", "mb006h/slots")
         for model in ("mai-code-2", "claude-sonnet-5.5")]
slot_hashes = {str(path.relative_to(OWNED)): sha(path.read_bytes()) for path in slots}
old = {}
for name in git("ls-tree", "-r", "--name-only", "de45ceb", "--",
                "benchmarks/michael/local_transport", "benchmarks/michael/replay_grader").decode().splitlines():
    if name.endswith((".json", ".tar.gz")):
        original = git("show", f"de45ceb:{name}")
        assert (REPO / name).read_bytes() == original, name
        old[name] = sha(original)

source_paths = [*(api.runner.HERE / name for name in api.runner.SOURCES),
                *(api.HERE / name for name in ("__init__.py", "api.py", "README.md")),
                *(api.grader.HERE / name for name in api.grader.POLICY_FILES),
                api.grader.HERE / "README.md",
                REPO / "tests/projects/michael_bench/test_replay_trial.py",
                REPO / "tests/projects/michael_bench/test_replay_grader.py"]
snapshots = {str(path.relative_to(REPO)): path.read_bytes() for path in source_paths}
source_hashes = {name: sha(data) for name, data in snapshots.items()}
files = {"source/" + name: data for name, data in snapshots.items()}
files["publisher.py"] = Path(__file__).read_bytes()
native_sources = {name: sha((api.runner.HERE / name).read_bytes()) for name in api.runner.SOURCES}
fixtures = {}

def native(run, key):
    terminal = read(run / "receipt/terminal.json")
    inventory = read(run / "receipt/inventory.json")
    config = read(run / "config.json")
    start = read(run / "receipt/start.json")
    assert start["source"] == native_sources
    assert terminal["nativePrompts"] == 0 and not terminal["nativeStarts"]
    assert not any(row["method"] == "session.send" for row in terminal["requests"])
    assert terminal["wholeProcessQuiescent"] and terminal["cleanupSeconds"] < 15
    assert all(row["reaped"] and not row["warnings"] for row in terminal["records"])
    assert [row["name"] for row in inventory["metadata"]["tools"]] == ["mb_action"]
    state = inventory["sandbox"]["config"]
    assert state["enabled"] and not state["allowBypass"]
    assert not state["userPolicy"]["network"]["allowOutbound"]
    assert not state["userPolicy"]["seatbelt"]["keychainAccess"]
    assert config["model"] is None and not config["approved"] and "prompt" not in config
    assert '(deny process-fork)' in config["taskProfile"]
    assert config["support"] in state["userPolicy"]["filesystem"]["readonlyPaths"]
    projection = {name: terminal[name] for name in (
        "stopReason", "activeSeconds", "cleanupSeconds", "wholeProcessQuiescent",
        "records", "actions", "actionBytes", "counts", "events", "protocolCondition",
        "protocolBytes", "nativeStarts", "nativePrompts", "observedModel", "usage",
        "ownerRetries", "unparsedProtocolBytesLowerBound")}
    projection.update(
        terminalSha256=sha((run / "receipt/terminal.json").read_bytes()),
        requests=[row["method"] for row in terminal["requests"]],
        nativeSource=native_sources,
        tools=["mb_action"],
        sandbox={name: state[name] for name in ("enabled", "allowBypass", "allowDevToolAccess")},
        userPolicy=state["userPolicy"],
        auth={name: state["auth"][name] for name in ("git", "gh")},
        extensions=inventory["created"]["capabilities"]["extensions"],
        ui=inventory["created"]["capabilities"]["ui"],
        bypassAutoApproved=inventory["sandbox"]["autoApproveBypass"],
        enforcementBlocked=inventory["enforcement"].get("blocked"),
        removedToolSha256=sha(encoded(inventory["removed"])))
    files[f"fixtures/{key}/native.json"] = encoded(projection)
    for name in ("config.json", "trial-start.json"):
        files[f"fixtures/{key}/{name}"] = (run / name).read_bytes()
    if (run / "collected-source.bin").exists():
        files[f"fixtures/{key}/collected-source.bin"] = (run / "collected-source.bin").read_bytes()
    return projection

base = api.packages.agent_files("validator")[api.SOURCE]
reference = api.packages.verifier_files("validator")["reference"]
for name, source in (("base", base), ("reference", reference),
                     ("false-success", b"print('PASS 25/25'); raise SystemExit(0)\n"),
                     ("malformed", b"def invalid(\n"), ("timeout", b"while True: pass\n")):
    directory = ROOT / name
    report = api.execute(OWNED, directory, source, label=f"trusted-deterministic-{name}",
                         seconds=3 if name == "timeout" else 20)
    observation = native(directory, name)
    if name in ("base", "reference"):
        assert report["status"] == "graded" and len(report["assertions"]) == 25
        assert report["counts"] == {"preservation": {"passed": 15, "total": 15},
                                     "regression": {"passed": 7 if name == "base" else 10, "total": 10}}
        assert report["verifier"]["cleanup"]["proven"]
        assert report["sourceSha256"] == report["verifier"]["bindings"]["source_sha256"]
        assert all(value > 0 for value in report["timings"].values())
    else:
        assert report["status"] == "ungraded" and report["verdict"] is None and report["counts"] is None
    assert report["modelPrompts"] == 0 and not report["scoredTrial"]
    files[f"fixtures/{name}/report.json"] = encoded(report)
    if (directory / "independent-grader/report.json").exists():
        for item in ("report.json", "owner.json", "terminal.json", "start.json"):
            files[f"fixtures/{name}/verifier/{item}"] = (
                directory / "independent-grader" / item).read_bytes()
    fixtures[name] = {"status": report["status"], "verdict": report["verdict"],
                      "counts": report["counts"], "fixtureSourceSha256": sha(source),
                      "timings": report["timings"], "nativeStopReason": observation["stopReason"]}

test_path = REPO / "tests/projects/michael_bench/test_replay_trial.py"
spec = importlib.util.spec_from_file_location("mb006k_scenarios", test_path)
scenarios = importlib.util.module_from_spec(spec)
spec.loader.exec_module(scenarios)
for name, function, args in (
    ("kernel-denials", scenarios.test_real_task_kernel_denies_outside_reads_support_writes_fork_and_network, ()),
    ("path-escape", scenarios.test_real_native_tool_path_escape_stops_before_worker, ()),
    ("controller-loss", scenarios.test_native_independent_owner_survives_controller_loss, ("controller-loss",)),
    ("deadline", scenarios.test_native_independent_owner_survives_controller_loss, ("deadline",))):
    directory = ROOT / name
    directory.mkdir()
    function(OWNED, directory, *args)
    observation = native(directory / "run", name)
    fixtures[name] = {"evidenceClass": "actual-native-trusted-negative-fixture",
                      "nativeStopReason": observation["stopReason"], "wholeProcessQuiescent": True}

for attack in ("source", "readonly", "dependency", "cleanup"):
    key = "tamper-" + attack
    run = api.setup(OWNED, ROOT / key, base)
    child = api.runner.launch(run)
    try:
        child.wait(timeout=40)
    finally:
        child.stdin.close()
    original = native(run, key)
    if attack == "cleanup":
        path = run / "receipt/terminal.json"
        value = read(path)
        value["wholeProcessQuiescent"] = False
        path.write_bytes(encoded(value))
    else:
        path = {"source": run / "task" / api.SOURCE, "readonly": run / "task/TASK.md",
                "dependency": run / "support/yaml/__init__.py"}[attack]
        path.write_bytes(path.read_bytes() + b"\n# trusted post-stop fault injection\n")
    def forbidden(*args, **kwargs):
        raise AssertionError("grader must not be queried for tampered artifact/proof")
    with pytest.MonkeyPatch.context() as monkey:
        monkey.setattr(api.grader, "grade", forbidden)
        try:
            api.grade_stopped(run)
        except (api.TrialError, OSError, ValueError) as error:
            rejection = f"{type(error).__name__}:{error}"
        else:
            raise AssertionError("tamper accepted")
    fixtures[key] = {"evidenceClass": "trusted-post-stop-mutation-not-native-cleanup-failure",
                     "originalNativeQuiescent": original["wholeProcessQuiescent"],
                     "mutatedFileSha256": sha(path.read_bytes()), "graderInvoked": False,
                     "rejection": rejection}

python = str(OWNED / "validation-venv/bin/python")
checks = [
    [python, "-m", "pytest", *("tests/projects/michael_bench/" + name for name in (
        "test_replay_trial.py", "test_local_transport.py", "test_historical_import.py",
        "test_manifests.py", "test_task_packages.py", "test_ledger_report.py")),
     "-k", "not test_fresh_calibration_matches_retained_counts", "-q"],
    [python, "-m", "pytest", *("tests/projects/michael_bench/test_replay_grader.py::" + name for name in (
        "test_owner_registration_preserves_linux_ticks_and_honest_macos_unknown",
        "test_exact_calibration_and_receipts", "test_original_assertions_against_observations",
        "test_hostile_candidates_ungraded_and_clean", "test_all_empty_errors_cannot_fabricate_success",
        "test_candidate_cannot_read_or_tamper_with_verifier", "test_framing_rejects_spoofs",
        "test_evaluator_failure_and_budget_limits", "test_recovery_removes_only_persisted_owner",
        "test_unproven_cleanup_cannot_authorize_success",
        "test_corrupt_owner_terminal_cannot_prove_recovery")), "-q"],
    ["bash", "benchmarks/michael/replay_grader/scripts/smoke.sh", str(ROOT / "smoke")],
    [python, "tools/validators/check_artifacts.py"],
    [python, "tools/validators/check_python_deps.py"],
    *[["node", "--check", "benchmarks/michael/local_transport/" + name]
      for name in ("owner.mjs", "limits.mjs", "protocol.mjs")],
    ["git", "diff", "--check"],
]
environment = {**os.environ, "MB006K_OWNED": str(OWNED),
               "PATH": str(OWNED / "validation-venv/bin") + ":" + os.environ["PATH"]}
results = []
for index, command in enumerate(checks):
    result = subprocess.run(command, cwd=REPO, env=environment, capture_output=True, timeout=180)
    output = result.stdout + result.stderr
    files[f"checks/{index}.txt"] = output
    results.append({"command": shlex.join(command), "exitCode": result.returncode,
                    "outputSha256": sha(output), "output": output.decode()})
    assert result.returncode == 0, results[-1]
    print(output.decode(), end="", flush=True)

assert {str(path.relative_to(OWNED)): sha(path.read_bytes()) for path in slots} == slot_hashes
assert all((REPO / name).read_bytes() == data for name, data in snapshots.items())
assert all(sha((REPO / name).read_bytes()) == digest for name, digest in old.items())
image = subprocess.check_output(["docker", "image", "inspect", "--format", "{{.Id}}",
                                 "michael-replay-grader:mb006j"]).decode().strip()
assert image == "sha256:55bc2bda57625cdd36e7e0a82a0bad7db3b210a13e0a015df608daeba3b6c90d"
for name in ("base", "reference", "false-success"):
    assert read(ROOT / name / "independent-grader/report.json")["image_id"] == image
report = {
    "condition": "MB-006k-offline", "foundation": "de45ceb", "modelPrompts": 0, "newSlots": 0,
    "attester": "authorized local executor", "attestationClass": "local-agent-attested-macos-not-human-observed",
    "modelIdentity": "unknown", "modelUsage": "unknown", "scoredTrial": False, "readyToInfer": False,
    "nativeValidatorIntegrationObserved": True, "dockerImageId": image,
    "provisioning": [
        "docker pull python:3.12-slim@sha256:191083cdf6c7bda8c76158983163ead5d5cf7b77cf3033e805bb0f5296f51b4b",
        "docker build --pull=false -t michael-replay-grader:mb006j benchmarks/michael/replay_grader"],
    "source": source_hashes, "preservedHistoricalArtifacts": old, "sixPreservedSlots": slot_hashes,
    "fixtures": fixtures, "checks": results,
    "limits": api.POLICY,
    "remainingGates": [
        "No model-generated historical task submitted; deterministic fixtures are not model success.",
        "All six previous slots remain spent; no inference allowance or source-bound live approval.",
        "Native model HTTP budget semantics remain unvalidated; old approvals remain source-stale.",
        "macOS grader process identity is unknown; recovery uses owned labels/pipe, never saved PID signals."],
    "evidenceExclusions": ["credential/auth state", "raw native streams/messages",
                           "account quotas", "installed third-party runtime/dependency source"],
}
files["verification.json"] = encoded(report)
archive = ROOT / "evidence.tar.gz"
with tarfile.open(archive, "w:gz") as stream:
    for name, data in sorted(files.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(data), 0o600, 0
        stream.addfile(info, io.BytesIO(data))
published = {**report, "archiveSha256": sha(archive.read_bytes()),
             "archiveFiles": {name: sha(data) for name, data in sorted(files.items())}}
(ROOT / "verification.json").write_bytes(encoded(published))
print(json.dumps({"root": str(ROOT), "reportSha256": sha(encoded(published)),
                  "archiveSha256": published["archiveSha256"]}))
