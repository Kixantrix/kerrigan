"""Trusted zero-inference MB-006l proof publisher. Never traverses auth state."""
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import tarfile

REPO = Path("/Users/mvh/.copilot/repos/copilot-worktrees/kerrigan/kixantrix-redesigned-barnacle")
OWNED = Path("/Users/mvh/.copilot/session-state/a45ee9a4-394e-4af7-afba-d8f78ae19672/files/local-mxc")
ROOT = OWNED / "mb006l-standing-direction-safety-2"
ROOT.mkdir(mode=0o700)
sys.path.insert(0, str(REPO))
from benchmarks.michael.replay_trial import api, validator
import pytest

sha = lambda data: hashlib.sha256(data).hexdigest()
encoded = lambda data: (json.dumps(data, sort_keys=True, separators=(",", ":")) + "\n").encode()
read = lambda path: json.loads(path.read_bytes())
git = lambda *args: subprocess.check_output(["git", *args], cwd=REPO)
assert not (OWNED / validator.NAMESPACE).exists() and not validator.SEAL.exists()
slot_paths = [OWNED / namespace / f"{model}.json" for namespace in (
    "canary-slots", "mb006f/slots", "mb006h/slots") for model in api.runner.MODELS]
slots = {str(p.relative_to(OWNED)): sha(p.read_bytes()) for p in slot_paths}
history = {}
superseded_policy = "benchmarks/michael/local_transport/validator-task-policy.json"
original_policy = git("show", f"2d46551:{superseded_policy}")
with tarfile.open(REPO / "benchmarks/michael/replay_trial/mb006l-retained-evidence.tar.gz") as previous:
    assert previous.extractfile("source/" + superseded_policy).read() == original_policy
for name in git("ls-tree", "-r", "--name-only", "2d46551", "--",
                "benchmarks/michael/local_transport", "benchmarks/michael/replay_trial",
                "benchmarks/michael/replay_grader").decode().splitlines():
    if name.endswith((".json", ".tar.gz")) and name != superseded_policy:
        original = git("show", f"2d46551:{name}")
        assert (REPO / name).read_bytes() == original
        history[name] = sha(original)
condition = validator.frozen(OWNED)
source = {name: (REPO / name).read_bytes() for name in condition["source"]}
for name in ("tests/projects/michael_bench/test_replay_trial.py",
             "benchmarks/michael/local_transport/synthetic_sdk.mjs",
             "benchmarks/michael/replay_trial/MB-006l.md"):
    source[name] = (REPO / name).read_bytes()
files = {"source/" + name: data for name, data in source.items()}
files["publisher.py"] = Path(__file__).read_bytes()
spec = importlib.util.spec_from_file_location("mb006l_scenarios",
    REPO / "tests/projects/michael_bench/test_replay_trial.py")
scenarios = importlib.util.module_from_spec(spec)
spec.loader.exec_module(scenarios)
native_sources = {name: sha((api.runner.HERE / name).read_bytes()) for name in api.runner.SOURCES}
observations = {}

def capture(run, name, *, synthetic=False):
    terminal = read(run / "receipt/terminal.json")
    inventory = read(run / "receipt/inventory.json")
    assert terminal["nativePrompts"] == 0
    assert not any(row["method"] == "session.send" for row in terminal["requests"])
    assert synthetic or not terminal["nativeStarts"]
    assert terminal["wholeProcessQuiescent"] and terminal["cleanupSeconds"] < 15
    assert all(row["reaped"] and not row["warnings"] for row in terminal["records"])
    assert read(run / "receipt/start.json")["source"] == native_sources
    assert [row["name"] for row in inventory["metadata"]["tools"]] == ["mb_action"]
    sandbox = inventory["sandbox"]["config"]
    assert sandbox["enabled"] and not sandbox["allowBypass"]
    projection = {key: terminal[key] for key in ("stopReason", "activeSeconds", "cleanupSeconds",
        "wholeProcessQuiescent", "records", "actions", "counts", "events", "nativePrompts", "nativeStarts",
        "ownerRetries", "protocolBytes", "observedModel", "usage", "taskOutputBytesBeforeCutoff")}
    projection.update(evidenceClass="synthetic-SDK-not-native-proof" if synthetic else "actual-native-offline",
        nativeSource=native_sources, terminalSha256=sha((run / "receipt/terminal.json").read_bytes()),
        requests=[row["method"] for row in terminal["requests"]], tools=["mb_action"],
        sandbox=sandbox, bypassAutoApproved=inventory["sandbox"]["autoApproveBypass"])
    projection["partialBudgetExhausted"] = terminal.get("partialBudgetExhausted", False)
    projection["taskOutputRetainedBytes"] = terminal["taskOutputRetainedBytes"]
    projection["finalSourceError"] = terminal.get("finalSourceError")
    files[f"cases/{name}/native.json"] = encoded(projection)
    for path in ("config.json", "trial-start.json", "collected-source.bin", "synthetic-result.json",
                 "independent-grader/report.json", "independent-grader/terminal.json"):
        if (run / path).exists():
            files[f"cases/{name}/{path}"] = (run / path).read_bytes()
    observations[name] = {"evidenceClass": projection["evidenceClass"],
        "stopReason": terminal["stopReason"], "nativePrompts": 0, "quiescent": True,
        "activeSeconds": terminal["activeSeconds"], "cleanupSeconds": terminal["cleanupSeconds"]}

native = ROOT / "native"
native.mkdir()
scenarios.test_mb006l_native_unknown_repair_and_contracts(OWNED, native)
for label in ("base", "reference"):
    capture(native / label, label)
    graded = read(native / label / "independent-grader/report.json")
    observations[label]["counts"] = graded["counts"]
    assert graded["cleanup"]["proven"] and len(graded["assertions"]) == 25
for name in ("synthetic-ledger.jsonl", "synthetic-comparison.json"):
    files[name] = (native / name).read_bytes()
for mode in ("escape", "timeout", "kernel"):
    path = ROOT / mode
    path.mkdir()
    scenarios.test_mb006l_native_boundaries(OWNED, path, mode)
    capture(path / "run", mode)
for mode in ("hang", "overflow", "deadline", "actions", "runaway", "retained"):
    path = ROOT / ("review-" + mode)
    path.mkdir()
    scenarios.test_mb006l_review_native_feedback_and_partial(OWNED, path, mode)
    run = path / "run"
    capture(run, "review-" + mode)
    terminal = read(run / "receipt/terminal.json")
    observations["review-" + mode]["partialBudgetExhausted"] = terminal["partialBudgetExhausted"]
    observations["review-" + mode]["counts"] = read(run / "independent-grader/report.json")["counts"]
    if mode in ("hang", "overflow", "runaway"):
        result = read(run / "receipt/action-result-2.json")["result"]
        feedback = {key: result[key] for key in ("exitCode", "timedOut", "feedback")}
        files[f"cases/review-{mode}/feedback.json"] = encoded(feedback)
    else:
        files[f"cases/review-{mode}/synthetic-partial.jsonl"] = (path / "synthetic-partial.jsonl").read_bytes()
path = ROOT / "controller-loss"
path.mkdir()
scenarios.test_mb006l_native_owner_survives_controller_loss(OWNED, path)
capture(path / "run", "controller-loss")
for failure in (False, True):
    path = ROOT / ("synthetic-failure" if failure else "synthetic-loop")
    path.mkdir()
    scenarios.test_mb006l_synthetic_owner_tool_loop(path, failure)
    capture(path / "run", path.name, synthetic=True)

https = api.runner.prepare(OWNED, ROOT / "https", seconds=10, transport_probe=True)
config = read(https / "config.json")
config.pop("prompt")
api.grader.persist(https / "config.json", config)
child = api.runner.launch(https)
try:
    child.wait(timeout=27)
finally:
    child.stdin.close()
capture(https, "public-https")
transport = read(https / "receipt/transport.json")
assert api.runner.bound_transport({"transportReady": True, "transport": transport}, native_sources, OWNED)
files["native-https.json"] = encoded(transport)

python = str(OWNED / "validation-venv/bin/python")
checks = [[python, "-m", "pytest", *("tests/projects/michael_bench/" + name for name in (
    "test_replay_trial.py", "test_local_transport.py", "test_historical_import.py",
    "test_manifests.py", "test_task_packages.py", "test_ledger_report.py")),
    "-k", "not test_fresh_calibration_matches_retained_counts", "-q"]]
checks.append(shlex.split(read(api.HERE / "verification.json")["checks"][1]["command"]))
assert checks[1][:3] == [python, "-m", "pytest"]
assert all(arg.startswith("tests/projects/michael_bench/test_replay_grader.py::") or arg == "-q"
           for arg in checks[1][3:])
checks += [["bash", "benchmarks/michael/replay_grader/scripts/smoke.sh", str(ROOT / "smoke")],
           [python, "tools/validators/check_artifacts.py"], [python, "tools/validators/check_python_deps.py"]]
checks += [["node", "--check", str((api.runner.HERE / name).relative_to(REPO))]
           for name in ("owner.mjs", "limits.mjs", "protocol.mjs", "validator_admission.mjs", "synthetic_sdk.mjs")]
checks.append(["git", "diff", "--check"])
environment = {**os.environ, "MB006K_OWNED": str(OWNED),
               "PATH": str(OWNED / "validation-venv/bin") + ":" + os.environ["PATH"]}
results = []
for index, command in enumerate(checks):
    process = subprocess.run(command, cwd=REPO, env=environment, capture_output=True, timeout=2400)
    output = process.stdout + process.stderr
    results.append({"command": shlex.join(command), "exitCode": process.returncode, "output": output.decode()})
    files[f"checks/{index}.txt"] = output
    assert process.returncode == 0, results[-1]
    print(output.decode(), end="", flush=True)

assert {str(p.relative_to(OWNED)): sha(p.read_bytes()) for p in slot_paths} == slots
assert not (OWNED / validator.NAMESPACE).exists() and not validator.SEAL.exists()
assert validator.frozen(OWNED) == condition
assert all((REPO / name).read_bytes() == data for name, data in source.items())
assert all(sha((REPO / name).read_bytes()) == digest for name, digest in history.items())
report = {"condition": condition, "conditionSha256": validator.digest(condition),
    "priorVerificationFailure": "Previous offline suite retained: 236 passed, two native fixtures "
        "were interrupted by host execution gaps of about 1000 seconds despite 45-second "
        "deadlines; both reaped and preserved partial bytes. Rerun uses process-scoped "
        "caffeinate -i, without shared settings changes.",
    "supersedes": "2d46551ce8c1a3e322bce24081ce6c79072f4030; all prior reports/archives preserved",
    "supersededPolicySha256": sha(original_policy),
    "publicationInfrastructure": "First publisher stopped before native runs: its historical-artifact filter "
        "misclassified the intentionally changed execution-policy source. Only that source is excluded now; "
        "its original bytes were verified in the unchanged bcdb342 archive; the current baseline "
        "policy is verified in the unchanged 503f689 archive.",
    "readyToInfer": False, "modelPrompts": 0, "realSlotsAllocated": 0,
    "attester": "authorized local executor", "attestation": "local-agent-attested-macos; not human observation",
    "nativeOffline": observations, "preservedHistoricalArtifacts": history, "sixSpentSlots": slots,
    "source": {name: sha(data) for name, data in source.items()}, "checks": results,
    "checkEnvironment": {"MB006K_OWNED": str(OWNED), "PATHPrepend": str(OWNED / "validation-venv/bin")},
    "publicationCommand": shlex.join([python, "-c",
        f"import pytest,runpy; runpy.run_path({str(Path(__file__))!r})"]),
    "modelIdentity": "unknown", "usage": "unknown", "cost": "unknown", "scoredModelResults": 0,
    "remainingGates": ["Bind executor seal to exact condition and passed local-native safety proof.",
        "Standing user direction at 02c8779 authorizes execution without another question.",
        "Fresh strict native HTTPS/effective sandbox required before each future prompt.",
        "Native 131072 response environment parsing/counting/acceptance remains unvalidated."],
    "exclusions": ["auth/credential state", "raw native streams/messages", "account quotas",
                   "third-party runtime/dependency source"]}
files["verification.json"] = encoded(report)
archive = ROOT / "evidence.tar.gz"
with tarfile.open(archive, "w:gz") as stream:
    for name, data in sorted(files.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(data), 0o600, 0
        stream.addfile(info, io.BytesIO(data))
published = {**report, "archiveSha256": sha(archive.read_bytes()),
             "archiveFiles": {name: sha(data) for name, data in sorted(files.items())}}
(ROOT / "verification.json").write_bytes(encoded(published))
print(json.dumps({"reportSha256": sha(encoded(published)), "archiveSha256": published["archiveSha256"],
                  "conditionSha256": published["conditionSha256"], "root": str(ROOT)}))
