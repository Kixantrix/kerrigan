import json
from pathlib import Path
import sys

ROOT = Path("/Users/mvh/.copilot/repos/copilot-worktrees/kerrigan/kixantrix-redesigned-barnacle")
OWNED = Path(__file__).parent
sys.path.insert(0, str(ROOT / "benchmarks/michael/local_transport"))
from proof import capture, environment, fixture

state = fixture(OWNED / "access-only")
requests = [
    {"jsonrpc": "2.0", "id": 1, "method": "initialize",
     "params": {"protocolVersion": 1, "clientCapabilities": {},
                "clientInfo": {"name": "mb-access-only", "version": "1"}}},
    {"jsonrpc": "2.0", "id": 2, "method": "session/new",
     "params": {"cwd": str(state / "task"), "mcpServers": []}},
]
payload = "".join(json.dumps(request) + "\n" for request in requests).encode()
receipt = capture([
    str(OWNED / "install/copilot"), "--acp", "--sandbox", "--no-auto-update",
    "--disable-builtin-mcps", "--available-tools=mb-not-installed",
    "--no-ask-user", "--disallow-temp-dir", "--sync-session=off", "--log-level=none",
    "--log-dir", str(state / "logs"),
], state / "task", state / "receipt", seconds=20,
    input_bytes=payload, env=environment(state))
print(json.dumps(receipt))
