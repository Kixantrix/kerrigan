import json
from pathlib import Path
import shutil
import socket
import sys

ROOT = Path("/Users/mvh/.copilot/repos/copilot-worktrees/kerrigan/kixantrix-redesigned-barnacle")
OWNED = Path(__file__).parent
sys.path.insert(0, str(ROOT / "benchmarks/michael/local_transport"))
from proof import capture, digest, environment, fixture, mxc_policy, persist

state = fixture(OWNED / "offline-3")
env = environment(state)
cli = OWNED / "install/copilot"
mxc = OWNED / "sdk/node_modules/@microsoft/mxc-sdk/bin/arm64/mxc-exec-mac"
summary = {"cli_sha256": digest(cli), "mxc_sha256": digest(mxc),
           "native_canaries_consumed": 0, "native_effective_inventory": "unknown",
           "whole_process_cleanup": "unproven"}
for name, args in (("version", ["--version"]), ("help", ["--help"]),
                   ("sandbox-help", ["help", "sandbox"]), ("login-help", ["login", "--help"])):
    summary[name] = capture([str(cli), "--no-auto-update", *args], state / "task",
                            state / name, env=env)
shutil.copyfile(ROOT / "benchmarks/michael/local_transport/probe.py", state / "task/probe.py")
listener = socket.socket()
listener.bind(("127.0.0.1", 0))
listener.listen(1)
port = listener.getsockname()[1]
with socket.create_connection(("127.0.0.1", port), timeout=1):
    connection, _ = listener.accept()
    connection.close()
policy = mxc_policy(mxc, state / "task", state / "denied",
                    f"/usr/bin/python3 {state}/task/probe.py {state}/task {state}/denied {port}")
persist(state / "policy.json", policy)
summary["policy_sha256"] = digest(state / "policy.json")
summary["dry_run"] = capture([str(mxc), "--dry-run", str(state / "policy.json")],
                             state / "task", state / "dry-run", env=env)
if summary["dry_run"]["returncode"] == 0:
    summary["probe"] = capture([str(mxc), str(state / "policy.json")],
                               state / "task", state / "probe", env=env)
    summary["debug_probe"] = capture(
        [str(mxc), "--debug", str(state / "policy.json")],
        state / "task", state / "debug-probe", env=env)
unsupported = json.loads(json.dumps(policy))
unsupported["network"]["egress"]["allow"] = [{"to": [{"cidr": "192.0.2.0/24"}]}]
unsupported["process"]["commandLine"] = (
    f"/bin/sh -c 'echo synthetic > {state}/task/unsupported-executed'")
persist(state / "unsupported-policy.json", unsupported)
summary["unsupported_policy"] = capture([str(mxc), str(state / "unsupported-policy.json")],
                                        state / "task", state / "unsupported-policy", env=env)
summary["unsupported_command_executed"] = (state / "task/unsupported-executed").exists()
listener.close()
persist(state / "summary.json", summary)
print(json.dumps(summary, indent=2))
