"""Frozen two-slot local executor; never inspects authentication state."""
import base64
import datetime
import io
import json
from pathlib import Path
import sys
import tarfile

ROOT = Path.cwd()
HERE = ROOT / "benchmarks/michael/local_transport"
OWNED = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from proof import MODELS, digest, persist
from runner import SOURCES, bound_transport, launch, prepare, recovery

state = OWNED / "mb006f"
state.mkdir(mode=0o700)
source = {name: digest(HERE / name) for name in SOURCES}
old = {str(path.relative_to(OWNED)): digest(path)
       for path in (OWNED / "canary-slots").glob("*.json")}
historical = {name: digest(HERE / name) for name in (
    "evidence.tar.gz", "receipt.json", "containment-addendum.tar.gz",
    "addendum.json", "integrated-evidence.tar.gz", "verification.json",
    "tls-evidence.tar.gz", "tls-diagnosis.json")}
safety = json.loads((OWNED / "mb006f-safety/safety.json").read_text())
assert safety["source"] == source and safety["transportReady"] is True
assert bound_transport(safety, source, OWNED)
assert safety["taskPolicyByteEquivalent"] is True
assert safety["archiveSha256"] == digest(HERE / "mb006f-safety.tar.gz")
prior = json.loads((HERE / "tls-diagnosis.json").read_text())
assert prior["archiveSha256"] == digest(HERE / "tls-evidence.tar.gz")
assert digest(HERE / "tls-diagnosis.json") == "6d6cff1e70213e981ba999eca3d7200ade521dc6ed994641f899a6fcf4a3b54d"

proof = {
    "condition": "MB-006f", "source": source, "passed": True, "transportReady": True,
    "transport": safety["transport"], "attester": "authorized-local-executor",
    "evidenceClass": "local-agent-attested", "environment": "local-attested-macos",
    "level": "scenario", "humanObserved": False,
    "authorization": "Human directly selected: I authorize this exact MB-006f condition",
    "attestedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "priorEvidence": historical,
    "currentSafetyArchiveSha256": safety["archiveSha256"],
    "currentSafety": {name: json.loads((OWNED / "mb006f-safety" / name / "receipt/terminal.json").read_text())[
        "wholeProcessQuiescent"] for name in ("native-https", "task-denials", "controller-loss", "deadline")},
    "assertion": "Exact preserved macOS denial/cutoff proof reviewed by the authorized local executor, with current-source live HTTPS, unchanged task profile, fresh denied credential/Keychain/fork/trust IPC, controller-loss and deadline exits. Not human-observed or manually attested."
}
assert all(proof["currentSafety"].values())
persist(state / "approval.json", proof)
seal = {
    "condition": "MB-006f", "models": list(MODELS), "controllerPromptsPerModel": 1,
    "activeSeconds": 180, "cleanupSeconds": 15, "source": source,
    "approvalSha256": digest(state / "approval.json"),
    "priorSlots": old, "retry": False, "scored": False,
}
persist(HERE / "mb006f-authorization.json", seal)
persist(HERE / "mb006f-attestation.json", proof)
public = {}


def save(name, value):
    public[name] = json.dumps(value, separators=(",", ":"), sort_keys=True).encode()


summaries = []
selected = {"model.model_call_started", "model.call_failure", "model.model_call_failure",
            "model.turn_retry", "assistant.turn_retry", "assistant.usage", "session.error",
            "session.idle", "assistant.turn_start", "assistant.turn_end"}
for model in MODELS:
    assert {name: digest(HERE / name) for name in SOURCES} == source
    for path, sha in old.items():
        assert digest(OWNED / path) == sha
    run = prepare(OWNED, state / model, seconds=180, model=model,
                  approval=state / "approval.json", corrected_condition=True)
    child = launch(run)
    try:
        child.wait(timeout=196)
    finally:
        child.stdin.close()
    terminal = json.loads((run / "receipt/terminal.json").read_text())
    safe = {key: terminal[key] for key in (
        "stopReason", "activeSeconds", "cleanupSeconds", "wholeProcessQuiescent",
        "actions", "actionBytes", "counts", "events", "requestedModel", "observedModel",
        "usage", "ownerRetries", "nativeStarts", "nativePrompts", "replayedActions", "verdict")}
    safe["nativeInvocationEvents"] = [
        item for item in terminal["messages"]
        if item["message"].get("params", {}).get("event", {}).get("type") in selected]
    safe["records"] = [{key: record.get(key) for key in (
        "kind", "id", "reaped", "result", "warnings", "finishedMs")} for record in terminal["records"]]
    safe["rawSha256"] = {path.name: digest(path) for path in (run / "receipt").glob("*.bin")}
    safe["backendExecutionIdentity"] = "unknown"
    safe["cost"] = "unknown"
    safe["independentTaskCompletion"] = "not evaluated; readiness only"
    inventory = json.loads((run / "receipt/inventory.json").read_text())
    transport = json.loads((run / "receipt/transport.json").read_text())
    assert transport["transportReady"] is True
    assert transport["source"] == source and transport["response"]["verified"] is True
    assert [tool["name"] for tool in inventory["metadata"]["tools"]] == ["mb_action"]
    assert terminal["nativePrompts"] <= 1 and terminal["ownerRetries"] == 0
    assert terminal["activeSeconds"] <= 181 and terminal["cleanupSeconds"] <= 15
    assert terminal["wholeProcessQuiescent"] is True
    assert all(record["reaped"] and not record["warnings"] for record in terminal["records"])
    assert recovery(run)["signalsSent"] == recovery(run)["replayedActions"] == 0
    safe["actionsObserved"] = []
    for action in sorted((run / "receipt").glob("action-*.json")):
        value = json.loads(action.read_text())
        save(f"{model}/{action.name}", value)
        if "args" in value:
            safe["actionsObserved"].append({"op": value["args"]["op"], "path": value["args"]["path"]})
        if "result" in value:
            result = value["result"]
            if "stdout" in result:
                safe.setdefault("actionStdout", []).append(base64.b64decode(result["stdout"]).decode(errors="replace"))
    save(f"{model}/terminal-safe.json", safe)
    save(f"{model}/config.json", json.loads((run / "config.json").read_text()))
    save(f"{model}/transport.json", transport)
    save(f"{model}/inventory-safe.json", {
        "tools": ["mb_action"], "sandbox": inventory["sandbox"], "enforcement": inventory["enforcement"],
        "removed": inventory["removed"]})
    for name in ("start.json", "prompt-start.json"):
        path = run / "receipt" / name
        if path.exists():
            save(f"{model}/{name}", json.loads(path.read_text()))
    summaries.append(safe)
    persist(run / "summary.json", safe)
    print(json.dumps({key: safe[key] for key in (
        "requestedModel", "stopReason", "nativePrompts", "activeSeconds", "cleanupSeconds",
        "wholeProcessQuiescent", "nativeStarts", "actionsObserved", "usage")}), flush=True)

for path, sha in old.items():
    assert digest(OWNED / path) == sha
for name, sha in historical.items():
    assert digest(HERE / name) == sha
for name in SOURCES:
    public["source/" + name] = (HERE / name).read_bytes()
public["procedure/mb006f_run.py"] = Path(__file__).read_bytes()
public["procedure/publish_tls.py"] = (OWNED / "publish_tls.py").read_bytes()
for path in sorted((state / "slots").glob("*.json")):
    save("slots/" + path.name, json.loads(path.read_text()))
with tarfile.open(HERE / "mb006f-canaries.tar.gz", "x:gz") as archive:
    for name, content in sorted(public.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(content), 0o600, 0
        archive.addfile(info, io.BytesIO(content))
report = {
    "condition": "MB-006f", "source": source, "attestationSha256": digest(HERE / "mb006f-attestation.json"),
    "authorizationSha256": digest(HERE / "mb006f-authorization.json"),
    "safetyArchiveSha256": digest(HERE / "mb006f-safety.tar.gz"),
    "canaryArchiveSha256": digest(HERE / "mb006f-canaries.tar.gz"),
    "historicalPreserved": historical, "oldSlotsPreserved": old, "canaries": summaries,
    "controllerPrompts": sum(item["nativePrompts"] for item in summaries),
    "nativeStarts": sum(len(item["nativeStarts"]) for item in summaries),
    "verdict": "ungraded", "scoredTasks": 0, "backendExecutionIdentity": "unknown", "cost": "unknown",
    "remainingGates": ["readiness does not establish independent task completion",
                       "historical scoring/integration requires separate authorization"]
}
with (HERE / "mb006f-outcomes.json").open("x") as stream:
    stream.write(json.dumps(report, separators=(",", ":"), sort_keys=True) + "\n")
print("REPORT", digest(HERE / "mb006f-outcomes.json"), flush=True)
