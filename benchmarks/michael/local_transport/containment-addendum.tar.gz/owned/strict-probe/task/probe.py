import errno,json,os,subprocess
r={}
try:
 p=os.fork()
except OSError as e:
 r['fork_errno']=e.errno
else:
 if p==0: os._exit(0)
 os.waitpid(p,0);r['fork_errno']=0
try:
 p=subprocess.run(['/bin/echo','synthetic'],capture_output=True,timeout=1)
except OSError as e:
 r['spawn_errno']=e.errno
else:
 r['spawn_errno']=0;r['spawn_returncode']=p.returncode
print(json.dumps(r))
