import base64
import json
import os
from pathlib import Path
import selectors
import subprocess
import sys
import time
import uuid

ROOT = Path("/Users/mvh/.copilot/repos/copilot-worktrees/kerrigan/kixantrix-redesigned-barnacle")
OWNED = Path(__file__).parent
sys.path.insert(0, str(ROOT / "benchmarks/michael/local_transport"))
from proof import environment, fresh, persist, monotonic

task = fresh(OWNED / "inventory-task-3")
evidence = fresh(OWNED / "inventory-receipt-3")
sid = str(uuid.uuid4())
policy = {
    "enabled": True, "allowBypass": False, "allowDevToolAccess": False,
    "sandboxMcpServers": True, "sandboxLspServers": True, "sandboxExtensions": True,
    "auth": {"git": False, "gh": False},
    "userPolicy": {
        "filesystem": {"readwritePaths": [str(task)], "deniedPaths": [
            str(OWNED / "access-only"), "/Library/Keychains", "/System/Library/Keychains"]},
        "network": {"allowOutbound": False, "allowLocalNetwork": False},
        "seatbelt": {"keychainAccess": False, "nestedPty": False},
    },
}
argv = ["/opt/homebrew/bin/node", str(OWNED / "sealed_cli.mjs")]
persist(evidence / "start.json", {"argv": argv, "active_seconds": 15,
        "started_monotonic": monotonic(), "native_prompts": 0, "verdict": "ungraded"})
p = subprocess.Popen(argv, cwd=task, env=environment(OWNED / "access-only"),
                     stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=0)
selector = selectors.DefaultSelector()
selector.register(p.stdout, selectors.EVENT_READ, "stdout")
selector.register(p.stderr, selectors.EVENT_READ, "stderr")
raw = {"stdout": bytearray(), "stderr": bytearray()}
pending = bytearray()
until = monotonic() + 15
messages, sent = [], []

def send(identity, method, params):
    assert method in ("session.create", "session.tools.initializeAndValidate",
                      "session.tools.getCurrentMetadata", "session.sandbox.getState",
                      "session.sandbox.getEnforcementStatus", "session.destroy",
                      "session.tools.execute")
    body = json.dumps({"jsonrpc":"2.0","id":identity,"method":method,"params":params}).encode()
    sent.append({"id": identity, "method": method, "params": params})
    p.stdin.write(f"Content-Length: {len(body)}\r\n\r\n".encode() + body)

try:
    send(1, "session.create", {"sessionId": sid, "workspace": {"workingDirectory": str(task)},
         "permissions": {"sandbox": policy},
         "tools": {"definitions": [{"name": "mb_action", "description": "Confined synthetic action",
                   "parameters": {"type": "object", "properties": {}, "additionalProperties": False},
                   "hasHandler": True}], "availableTools": ["mb_action"]}})
    done = False
    while not done and monotonic() < until:
        for key, _ in selector.select(0.02):
            chunk = os.read(key.fd, 8192)
            if not chunk:
                selector.unregister(key.fileobj)
                continue
            if len(raw[key.data]) + len(chunk) > 65536:
                raise RuntimeError("output_overflow")
            raw[key.data].extend(chunk)
            if key.data != "stdout":
                continue
            pending.extend(chunk)
            while b"\r\n\r\n" in pending:
                header, tail = pending.split(b"\r\n\r\n", 1)
                length = int(header.decode().split("Content-Length: ")[1].split("\r\n")[0])
                if length > 65536:
                    raise RuntimeError("frame_overflow")
                if len(tail) < length:
                    break
                message = json.loads(tail[:length])
                pending = bytearray(tail[length:])
                messages.append(message)
                identity = message.get("id")
                if "method" in message and identity is not None:
                    body = json.dumps({"jsonrpc":"2.0","id":identity,
                                       "error":{"code":-32601,"message":"Unsupported client callback"}}).encode()
                    p.stdin.write(f"Content-Length: {len(body)}\r\n\r\n".encode() + body)
                elif identity == 1:
                    if "error" in message:
                        done = True
                    else:
                        send(2, "session.tools.initializeAndValidate", {"sessionId": sid})
                elif identity == 2:
                    send(3, "session.tools.getCurrentMetadata", {"sessionId": sid})
                elif identity == 3:
                    send(4, "session.sandbox.getState", {"sessionId": sid})
                elif identity == 4:
                    send(5, "session.sandbox.getEnforcementStatus", {"sessionId": sid})
                elif identity == 5:
                    send(6, "session.tools.execute", {"sessionId": sid, "name": "view",
                         "arguments": {"path": str(task / "not-readable-by-removed-tool")}})
                elif identity == 6:
                    send(7, "session.destroy", {"sessionId": sid})
                elif identity == 7:
                    done = True
        if p.poll() is not None:
            break
finally:
    p.stdin.close()
    try:
        p.wait(timeout=5)
    except subprocess.TimeoutExpired:
        p.kill()
        p.wait(timeout=5)
    selector.close()
    persist(evidence / "receipt.json", {"sent": sent, "messages": messages,
            "returncode": p.returncode, "verdict": "ungraded", "native_prompts": 0,
            "whole_process_cleanup": "unproven",
            "raw": {k: base64.b64encode(v).decode() for k,v in raw.items()}})
    print(json.dumps(messages, indent=2))
