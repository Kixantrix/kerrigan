import json
from pathlib import Path
import selectors
import subprocess

root = Path(__file__).parent
process = subprocess.Popen(["/opt/homebrew/bin/node", str(root / "lifetime_probe.mjs")],
                           stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE, bufsize=0)
selector = selectors.DefaultSelector()
selector.register(process.stdout, selectors.EVENT_READ)
try:
    if not selector.select(timeout=5):
        raise RuntimeError("no native ready acknowledgement")
    assert process.stdout.readline() == b"ready\n"
    process.stdin.write(b"cancel\n")
    process.stdin.close()
    process.wait(timeout=15)
    assert process.returncode == 0, process.stderr.read(65536)
    print((root / "lifetime-receipt.json").read_text())
finally:
    selector.close()
    if process.poll() is None:
        process.kill()
        process.wait(timeout=2)
