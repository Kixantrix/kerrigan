import base64
import json
from pathlib import Path
import sys

ROOT = Path("/Users/mvh/.copilot/repos/copilot-worktrees/kerrigan/kixantrix-redesigned-barnacle")
OWNED = Path(__file__).parent
sys.path.insert(0, str(ROOT / "benchmarks/michael/local_transport"))
from proof import capture, environment, fixture, persist

state = fixture(OWNED / "strict-probe")
raw = json.loads((OWNED / "offline-3/debug-probe/capture.json").read_text())
text = base64.b64decode(raw["channels"]["stdout"]["base64_prefix"]).decode()
profile = text.split("Seatbelt: --- begin generated profile ---\n", 1)[1].split(
    "Seatbelt: --- end generated profile ---", 1)[0]
assert profile.count("(allow process-fork)") == 1
profile = profile.replace("(allow process-fork)", "(deny process-fork)")
profile = profile.replace(str(OWNED / "offline-3/task"), str(state / "task"))
profile = profile.replace(str(OWNED / "offline-3/denied"), str(state / "denied"))
for path in ("/Library/Keychains", "/System/Library/Keychains", str(OWNED / "access-only")):
    profile += f'\n(deny file-read* file-read-metadata file-write* (subpath "{path}"))\n'
program = (
    "import errno,json,os,subprocess\nr={}\n"
    "try:\n p=os.fork()\n"
    "except OSError as e:\n r['fork_errno']=e.errno\n"
    "else:\n"
    " if p==0: os._exit(0)\n"
    " os.waitpid(p,0);r['fork_errno']=0\n"
    "try:\n p=subprocess.run(['/bin/echo','synthetic'],capture_output=True,timeout=1)\n"
    "except OSError as e:\n r['spawn_errno']=e.errno\n"
    "else:\n r['spawn_errno']=0;r['spawn_returncode']=p.returncode\n"
    "print(json.dumps(r))\n"
)
(state / "task/probe.py").write_text(program)
policy = json.loads((OWNED / "offline-3/policy.json").read_text())
policy["process"]["cwd"] = str(state / "task")
policy["process"]["commandLine"] = (
    f"/Library/Developer/CommandLineTools/Library/Frameworks/Python3.framework/Versions/3.9/bin/python3 "
    f"{state}/task/probe.py")
policy["seatbelt"]["profileOverride"] = profile
policy["seatbelt"]["nestedPty"] = False
persist(state / "policy.json", policy)
mxc = OWNED / "sdk/node_modules/@microsoft/mxc-sdk/bin/arm64/mxc-exec-mac"
receipt = capture([str(mxc), "--debug", str(state / "policy.json")],
                  state / "task", state / "receipt", env=environment(state))
print(json.dumps(receipt))
result = json.loads((state / "receipt/capture.json").read_text())
print(base64.b64decode(result["channels"]["stdout"]["base64_prefix"]).decode())
print(base64.b64decode(result["channels"]["stderr"]["base64_prefix"]).decode())
