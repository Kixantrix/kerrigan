import { readFileSync, writeFileSync } from "node:fs";
import { spawnWithExtendedOptions } from "./sdk/node_modules/@microsoft/mxc-sdk/dist/v1/index.js";

const root = new URL("./", import.meta.url).pathname;
const policy = JSON.parse(readFileSync(root + "strict-probe/policy.json", "utf8"));
let profile = policy.seatbelt.profileOverride;
profile = profile.replace(/\(deny file-read\* file-read-metadata file-write\* \(subpath "[^"]*\/access-only"\)\)/, "");
profile += `\n(allow file-read* (subpath "${root}install"))\n`;
profile += `\n(allow file-read* file-write* (subpath "${root}access-only/cli") (subpath "${root}access-only/cache"))\n`;
profile += `\n(allow network-outbound)\n(allow network-bind (local ip))\n(allow system-socket)\n(deny network-outbound (remote ip "localhost:*"))\n`;
writeFileSync(root + "sealed-cli-profile.sb", profile);
const task = root + "inventory-task-3";
profile += `\n(allow file-read* file-write* (subpath "${task}"))\n`;
const child = await spawnWithExtendedOptions({
  command: root + "install/copilot --headless --stdio --sandbox --no-auto-update --disable-builtin-mcps --no-ask-user --disallow-temp-dir --sync-session=off --log-level=none",
  workingDirectory: task,
  containment: { type: "seatbelt", config: { profileOverride: profile, nestedPty: false,
                                            keychainAccess: false } },
  timeoutMs: 20000,
  environment: {
    PATH: "/usr/bin:/bin", HOME: root + "access-only/home",
    COPILOT_HOME: root + "access-only/cli", COPILOT_CACHE_HOME: root + "access-only/cache",
    COPILOT_DISABLE_LOGIN_SHELL_ENV: "true", COPILOT_PLUGIN_DIR_ONLY: "true",
    COPILOT_MCP_TOOL_CACHE: "false", USE_TGREP: "false",
    COPILOT_DISABLE_DESKTOP_NOTIFICATIONS: "1"
  }
}, { stdio: "inherit" });
process.on("SIGTERM", () => child.kill());
try {
  const result = await child.wait();
  writeFileSync(root + "sealed-cli-lifetime.json", JSON.stringify({result, warnings: child.warnings,
    scope: "MXC native CLI root under process-fork denial", nativePrompts: 0}, null, 2));
} finally {
  child.dispose();
}
