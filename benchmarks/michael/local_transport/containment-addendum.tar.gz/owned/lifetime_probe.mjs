import { readFileSync, writeFileSync } from "node:fs";
import { performance } from "node:perf_hooks";
import { spawn } from "./sdk/node_modules/@microsoft/mxc-sdk/dist/v1/index.js";

const root = new URL("./", import.meta.url).pathname;
const policy = JSON.parse(readFileSync(root + "strict-probe/policy.json", "utf8"));
const worker = root + "strict-probe/task/lifetime.py";
writeFileSync(worker, "import os,time\nprint('ready',flush=True)\ntime.sleep(3)\n");
const began = performance.now();
writeFileSync(root + "lifetime-start.json", JSON.stringify({
  state: "started", nativePrompts: 0, activeSeconds: 2, cleanupSeconds: 15
}));
const child = await spawn({
  command: "/Library/Developer/CommandLineTools/Library/Frameworks/Python3.framework/Versions/3.9/bin/python3 " + worker,
  workingDirectory: root + "strict-probe/task",
  containment: { type: "seatbelt", config: { profileOverride: policy.seatbelt.profileOverride,
                                           nestedPty: false, keychainAccess: false }},
  network: { egress: { default: "deny" }, ingress: { default: "deny", hostLoopback: "deny" } },
  timeoutMs: 2000,
  environment: { PATH: "/usr/bin:/bin" }
});
let output = "", errorOutput = "", stopped = false;
function stop() {
  if (!stopped) {
    stopped = true;
    child.kill();
  }
}
child.standardOutput.on("data", bytes => {
  output += bytes.toString();
  if (Buffer.byteLength(output) > 65536) throw new Error("stdout overflow");
  if (output.includes("ready")) process.stdout.write("ready\n");
});
child.standardError.on("data", bytes => {
  errorOutput += bytes.toString();
  if (Buffer.byteLength(errorOutput) > 65536) throw new Error("stderr overflow");
});
process.stdin.on("data", stop);
process.stdin.on("end", stop);
const fallback = setTimeout(stop, 1800);
try {
  const result = await child.wait();
  writeFileSync(root + "lifetime-receipt.json", JSON.stringify({
    result, output, errorOutput, warnings: child.warnings,
    activeSeconds: (performance.now() - began) / 1000,
    externalCancellationReceived: stopped,
    identity: "live MXC native process handle, no recorded PID signals",
    scope: "non-forking task process only; CLI lifetime still unproven",
    nativePrompts: 0, verdict: "ungraded"
  }, null, 2));
} finally {
  clearTimeout(fallback);
  child.dispose();
}
