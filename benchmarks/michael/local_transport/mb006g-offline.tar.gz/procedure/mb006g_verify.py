"""Offline synthetic owner verification and private native-shape replay only."""
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT = Path.cwd()
HERE = ROOT / "benchmarks/michael/local_transport"
OWNED = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from proof import digest
from runner import SOURCES, ProofError, prepare

suite = OWNED / "mb006g-offline"
suite.mkdir(mode=0o700)
source = {name: digest(HERE / name) for name in SOURCES}
historical_report = json.loads((HERE / "mb006f-outcomes.json").read_text())
historical = {name: digest(HERE / name) for name in (
    *historical_report["historicalPreserved"], "mb006f-attestation.json",
    "mb006f-authorization.json", "mb006f-canaries.tar.gz", "mb006f-outcomes.json",
    "mb006f-audit.json", "mb006f-safety.tar.gz")}
for name, sha in historical_report["historicalPreserved"].items():
    assert historical[name] == sha
assert historical["mb006f-authorization.json"] == historical_report["authorizationSha256"]
old_slots = {str(path.relative_to(OWNED)): digest(path)
             for folder in ("canary-slots", "mb006f/slots")
             for path in (OWNED / folder).glob("*.json")}
assert len(old_slots) == 4
assert json.loads((HERE / "mb006f-authorization.json").read_text())["source"] != source
try:
    prepare(OWNED, suite / "stale-denied", seconds=180, model="mai-code-2",
            approval=OWNED / "mb006f/approval.json", corrected_condition=True)
except ProofError as error:
    assert str(error) == "bound containment approval required"
else:
    raise AssertionError("spent condition accepted changed sources")

spec = importlib.util.spec_from_file_location(
    "mb006g_tests", ROOT / "tests/projects/michael_bench/test_local_transport.py")
tests = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tests)
public = {}


def save(name, value):
    public[name] = json.dumps(value, separators=(",", ":"), sort_keys=True).encode()


synthetic = []
variants = [
    ({}, "diagnostics_complete"),
    ({"fragment": 7}, "diagnostics_complete"),
    ({"failure": True}, "native_model_failure:model.call_failure"),
    ({"duplicate": True}, "broker:duplicate_or_invalid_action"),
    ({"sideChannel": True}, 'runtime:diagnostic_failed:{"resultType":"side_channel_denied"}'),
    ({"taskOverflow": True}, "output_overflow:task-2-stdout"),
]
for index, (variant, expected) in enumerate(variants):
    folder = suite / f"synthetic-{index}"
    folder.mkdir()
    tests.test_actual_owner_broker_with_labeled_synthetic_sdk(folder, variant, expected)
    receipt = folder / "run/receipt"
    terminal = json.loads((receipt / "terminal.json").read_text())
    safe = {key: terminal[key] for key in (
        "stopReason", "wholeProcessQuiescent", "actions", "counts", "events",
        "nativePrompts", "protocolCondition", "protocolBytes",
        "unparsedProtocolBytesLowerBound", "evidenceDiskBytesBeforeTerminal")}
    safe["label"] = "synthetic CLI and task handles; actual owner/parser/broker; no native CLI or inference"
    safe["variant"] = variant
    safe["rawSha256"] = {path.name: digest(path) for path in receipt.glob("*.bin")}
    safe["receiptDiskBytes"] = sum(path.stat().st_size for path in receipt.iterdir() if path.is_file())
    assert safe["receiptDiskBytes"] <= 16777216
    save(f"synthetic/{index}/terminal-safe.json", safe)
    synthetic.append(safe)
    for path in receipt.glob("action*.json"):
        save(f"synthetic/{index}/{path.name}", json.loads(path.read_text()))

script = """
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {Protocol} from './benchmarks/michael/local_transport/protocol.mjs';
import {nativeFailure} from './benchmarks/michael/local_transport/limits.mjs';
const out=[];
for(const spec of JSON.parse(process.argv[1])) {
 const bytes=readFileSync(spec.path);
 for(const cutoff of [false,true]) {
  const counts={}, p=new Protocol(m=>{
   const e=m.params?.event, name=e?.type||m.method||'rpc-response';
   counts[name]=(counts[name]||0)+1;
   return !(cutoff && e && nativeFailure(e,spec.model));
  });
  let finish='complete';
  try { for(let n=0;n<bytes.length;n+=17)p.feed(bytes.subarray(n,n+17));p.finish(); }
  catch(e) {finish=e.message;if(finish!=='protocol_truncated')throw e;}
  out.push({case:spec.case,cutoff,counts,finish,halted:p.halted,
   consumedBytes:p.total,retainedBytes:bytes.length,unparsedBytes:bytes.length-p.total,
   sha256:createHash('sha256').update(bytes).digest('hex')});
 }
}
console.log(JSON.stringify(out));
"""
inputs = []
for condition, prefix in (("MB-006d", "canary-"), ("MB-006f", "mb006f/")):
    for model in ("mai-code-2", "claude-sonnet-5.5"):
        inputs.append({"case": f"{condition}/{model}", "model": model,
                       "path": str(OWNED / f"{prefix}{model}/receipt/cli-0-stdout.bin")})
replays = json.loads(subprocess.check_output(
    ["node", "--input-type=module", "-e", script, json.dumps(inputs)], cwd=ROOT, timeout=10))
assert all(item["consumedBytes"] <= item["retainedBytes"] for item in replays)
assert all(item["halted"] for item in replays if item["case"].startswith("MB-006d") and item["cutoff"])
for item in replays:
    save("replay/" + item["case"] + f"-{item['cutoff']}.json", item)

safety = json.loads((OWNED / "mb006g-safety/safety.json").read_text())
assert safety["source"] == source and safety["archiveSha256"] == digest(HERE / "mb006g-safety.tar.gz")
for name in (*SOURCES, "synthetic_sdk.mjs"):
    public["source/" + name] = (HERE / name).read_bytes()
public["procedure/mb006g_verify.py"] = Path(__file__).read_bytes()
public["procedure/publish_tls.py"] = (OWNED / "publish_tls.py").read_bytes()
schema = OWNED / "copilot-rpc.ts"
schema_receipt = {
    "schemaSha256": digest(schema),
    "pushStreaming": "SessionOpenEventOptions at lines 47070-47075 exposes only streaming",
    "pullFiltering": "EventLogReadRequest types at 21715-21717 applies to history reads, not suppression of pushed traffic",
    "decision": "Retain all push events and current streaming setting; no unverified filtering or guessed flags",
}
save("schema.json", schema_receipt)
with tarfile.open(HERE / "mb006g-offline.tar.gz", "x:gz") as archive:
    for name, content in sorted(public.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(content), 0o600, 0
        archive.addfile(info, io.BytesIO(content))
for name, sha in historical.items():
    assert digest(HERE / name) == sha
for name, sha in old_slots.items():
    assert digest(OWNED / name) == sha
report = {
    "condition": "MB-006g-offline", "source": source, "schema": schema_receipt,
    "offlineArchiveSha256": digest(HERE / "mb006g-offline.tar.gz"),
    "safetyArchiveSha256": safety["archiveSha256"], "synthetic": synthetic, "replays": replays,
    "historicalPreserved": historical, "slotsPreserved": old_slots,
    "nativePrompts": 0, "newSlots": 0, "newCanaries": 0, "readyToInfer": False,
    "nativeHttps": safety["transport"], "taskPolicyByteEquivalent": True,
    "testSourceSha256": digest(ROOT / "tests/projects/michael_bench/test_local_transport.py"),
    "liveValidationGap": "No model tool loop has run under MB-006g. Synthetic handles do not prove native task completion. MB-006f authorization remains source-stale; all four slots stay spent.",
    "commands": [
        "python -m pytest tests/projects/michael_bench/test_local_transport.py tests/projects/michael_bench/test_historical_import.py tests/projects/michael_bench/test_manifests.py -q: 137 passed",
        "publish_tls.py: current-source native HTTPS/task denials/controller-loss/deadline passed",
        "mb006g_verify.py: actual owner synthetic write/run/result/idle and rejection cases passed; private native bytes replayed with shape-only publication",
    ],
}
with (HERE / "mb006g-verification.json").open("x") as stream:
    stream.write(json.dumps(report, separators=(",", ":"), sort_keys=True) + "\n")
print("OFFLINE_VERIFIED", digest(HERE / "mb006g-verification.json"))
