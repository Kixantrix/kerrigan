import base64
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path("/Users/mvh/.copilot/repos/copilot-worktrees/kerrigan/kixantrix-redesigned-barnacle")
sys.path.insert(0, str(ROOT / "benchmarks/michael/local_transport"))
from runner import HERE, SOURCES, PYTHON, prepare, launch, recovery
from proof import digest, persist, fresh

OWNED = Path(__file__).parent
SUITE = fresh(OWNED / "boundary-suite-5")
summaries = {}

def run_case(name, code=None, *, seconds=10, extra=(), duplicate=False, lose=False, cancel=False):
    operations = [] if code is None else [
        {"op": "write", "path": "candidate.py", "data": code},
        {"op": "run", "path": "candidate.py"}, *extra]
    run = prepare(OWNED, SUITE / name, seconds=seconds, diagnostics=operations,
                  hold=lose or cancel, duplicate_ids=duplicate)
    controller = None
    if lose:
        controller = subprocess.Popen([sys.executable, str(OWNED / "death_controller.py"), str(run)])
        owner = None
    else:
        owner = launch(run)
    if lose or cancel:
        end = time.monotonic() + seconds
        marker = run / "receipt/task-2-stdout.bin"
        while not marker.exists() or b"running" not in marker.read_bytes():
            if (controller or owner).poll() is not None or time.monotonic() > end:
                raise RuntimeError("task owner failed before cancellation")
            time.sleep(0.01)
        if cancel:
            owner.stdin.write(b'{"stop":true}\n')
            owner.stdin.flush()
        else:
            controller.kill()
            controller.wait(timeout=2)
    if owner:
        owner.wait(timeout=seconds + 15)
        owner.stdin.close()
    else:
        end = time.monotonic() + 15
        while not (run / "receipt/terminal.json").exists():
            if time.monotonic() > end:
                raise RuntimeError("independent owner did not acknowledge controller death")
            time.sleep(0.01)
    terminal = json.loads((run / "receipt/terminal.json").read_text())
    assert terminal["wholeProcessQuiescent"] is True, terminal["stopReason"]
    assert terminal["cleanupSeconds"] < 15
    assert terminal["nativePrompts"] == 0
    assert all(record["reaped"] and not record["warnings"] for record in terminal["records"])
    assert recovery(run)["signalsSent"] == 0 and recovery(run)["replayedActions"] == 0
    summaries[name] = {key: terminal[key] for key in
        ("stopReason", "activeSeconds", "cleanupSeconds", "wholeProcessQuiescent", "actions", "counts")}
    print(name, terminal["stopReason"], flush=True)
    return run, terminal

denials = f"""
import ctypes,errno,json,os,socket,subprocess
results={{}}
def deny(name,call):
    try: call()
    except OSError as error:
        assert error.errno==errno.EPERM,(name,error)
        results[name]=error.errno
    else: raise AssertionError(name)
deny("credentials",lambda:os.open({str(OWNED / "access-only")!r},os.O_RDONLY))
deny("keychains",lambda:os.open("/Library/Keychains",os.O_RDONLY))
deny("system_keychains",lambda:os.open("/System/Library/Keychains",os.O_RDONLY))
deny("fork",os.fork)
deny("spawn_detached",lambda:subprocess.Popen([{PYTHON!r},"-c","import time;time.sleep(60)"],start_new_session=True))
deny("network_loopback",lambda:socket.create_connection(("127.0.0.1",9),1))
deny("network_remote",lambda:socket.create_connection(("192.0.2.1",9),1))
deny("tty",lambda:os.open("/dev/tty",os.O_RDWR))
lib=ctypes.CDLL("/usr/lib/libSystem.B.dylib")
port=ctypes.c_uint(); server=ctypes.c_uint()
assert lib.task_get_special_port(lib.mach_task_self(),4,ctypes.byref(port))==0
status=lib.bootstrap_look_up(port.value,b"com.apple.securityd",ctypes.byref(server))
assert status==1100,status
results["securityd_lookup"]=status
print(json.dumps(results))
"""
run, terminal = run_case("denials", denials)
assert terminal["stopReason"] == "diagnostics_complete"
output = json.loads((run / "receipt/action-result-2.json").read_text())["result"]
assert len(json.loads(base64.b64decode(output["stdout"]))) == 9
_, result = run_case("timeout", "import time;time.sleep(60)", seconds=1.5)
assert result["stopReason"] in ("timeout", "task_timeout", "broker:worker_failed")
assert 0 < result["activeSeconds"] < 2
_, result = run_case("controller-lost", "print('running',flush=True);import time;time.sleep(60)", lose=True)
assert result["stopReason"] == "controller_lost"
_, result = run_case("external-cancel", """
import os,time
try:
    os.setsid()
    print("setsid succeeded")
except OSError as error:
    print("setsid refused",error.errno)
print('running',flush=True)
time.sleep(60)
""", cancel=True)
assert result["stopReason"] == "external_cancel"
_, result = run_case("overflow", "import os\nwhile True: os.write(1,b'x'*8192)")
assert result["stopReason"].startswith("output_overflow:task-")
assert max(result["counts"].values()) > 65536
_, result = run_case("duplicate", "print(5)", duplicate=True)
assert result["stopReason"] == "broker:duplicate_or_invalid_action"
_, result = run_case("symlink", "import os;os.symlink('/Library/Keychains','result.txt')",
                    extra=[{"op": "read", "path": "result.txt"}])
assert result["stopReason"] == "broker:worker_failed"
persist(SUITE / "approval.json", {"passed": True, "cases": summaries,
        "source": {name: digest(HERE / name) for name in SOURCES},
        "nativePrompts": 0, "attestation": "local execution evidence; human attestation pending"})
print("APPROVAL", SUITE / "approval.json")
run = prepare(OWNED, SUITE / "public-ca-transport", seconds=12, transport_probe=True)
owner = launch(run)
owner.wait(timeout=27)
owner.stdin.close()
print("PUBLIC_CA_TRANSPORT", (run / "receipt/transport.json").read_text())
