import sys
from pathlib import Path

ROOT = Path("/Users/mvh/.copilot/repos/copilot-worktrees/kerrigan/kixantrix-redesigned-barnacle")
sys.path.insert(0, str(ROOT / "benchmarks/michael/local_transport"))
from runner import launch

process = launch(sys.argv[1])
process.wait()
