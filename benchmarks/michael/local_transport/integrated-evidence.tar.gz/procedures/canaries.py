import json
from pathlib import Path
import sys

ROOT = Path("/Users/mvh/.copilot/repos/copilot-worktrees/kerrigan/kixantrix-redesigned-barnacle")
sys.path.insert(0, str(ROOT / "benchmarks/michael/local_transport"))
from runner import prepare, launch, recovery
from proof import MODELS, persist

OWNED = Path(__file__).parent
for model in MODELS:
    run = prepare(OWNED, OWNED / f"canary-{model}", seconds=180, model=model,
                  approval=OWNED / "boundary-suite-2/approval.json")
    process = launch(run)
    try:
        process.wait(timeout=195)
    finally:
        process.stdin.close()
    path = run / "receipt/terminal.json"
    if not path.exists():
        persist(run / "receipt/missing-terminal.json", recovery(run))
        raise RuntimeError("native owner failed; quiescence unknown; do not continue")
    terminal = json.loads(path.read_text())
    safe = {key: terminal[key] for key in ("stopReason", "activeSeconds", "cleanupSeconds",
            "wholeProcessQuiescent", "actions", "nativePrompts", "requestedModel",
            "observedModel", "usage")}
    persist(run / "summary.json", safe)
    print(model, json.dumps(safe), flush=True)
    if not terminal["wholeProcessQuiescent"] or terminal["cleanupSeconds"] > 15:
        raise RuntimeError("cleanup not proven; remaining canary stays unused")
