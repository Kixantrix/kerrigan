"""Whitelisted non-inference verification/publication; never visits auth state."""
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import time

ROOT = Path.cwd()
HERE = ROOT / "benchmarks/michael/local_transport"
OWNED = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from proof import digest, persist
from runner import SOURCES, bound_transport, launch, prepare, recovery

historical = {name: digest(HERE / name) for name in
              ("integrated-evidence.tar.gz", "verification.json", "receipt.json", "evidence.tar.gz",
               "addendum.json", "containment-addendum.tar.gz")}
suite = OWNED / "mb006e-current-2"
suite.mkdir(mode=0o700)
public = {}


def add(name, value):
    public[name] = json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def wait_file(path, seconds=30):
    until = time.monotonic() + seconds
    while not path.exists():
        if time.monotonic() >= until:
            raise TimeoutError(str(path))
        time.sleep(0.025)


def project(name, run):
    terminal = json.loads((run / "receipt/terminal.json").read_text())
    assert terminal["nativePrompts"] == 0 and not terminal["nativeStarts"]
    assert terminal["wholeProcessQuiescent"] is True and terminal["cleanupSeconds"] <= 15
    assert terminal["replayedActions"] == 0
    safe = {key: terminal[key] for key in (
        "stopReason", "activeSeconds", "cleanupSeconds", "wholeProcessQuiescent", "actions",
        "actionBytes", "counts", "events", "requestedModel", "observedModel", "usage",
        "ownerRetries", "nativeStarts", "nativePrompts", "replayedActions", "verdict")}
    safe["records"] = [{key: record.get(key) for key in (
        "kind", "id", "reaped", "result", "warnings", "finishedMs")} for record in terminal["records"]]
    add(f"current/{name}/terminal-safe.json", safe)
    add(f"current/{name}/config.json", json.loads((run / "config.json").read_text()))
    add(f"current/{name}/start.json", json.loads((run / "receipt/start.json").read_text()))
    return terminal


run = prepare(OWNED, suite / "native-https", seconds=12, transport_probe=True)
child = launch(run)
child.wait(timeout=30)
child.stdin.close()
terminal = project("native-https", run)
assert terminal["stopReason"] == "transport_probe_complete"
witness = json.loads((run / "receipt/transport.json").read_text())
source = {name: digest(HERE / name) for name in SOURCES}
assert bound_transport({"transportReady": True, "transport": witness}, source, OWNED)
inventory = json.loads((run / "receipt/inventory.json").read_text())
assert [tool["name"] for tool in inventory["metadata"]["tools"]] == ["mb_action"]
add("current/native-https/transport.json", witness)
add("current/native-https/effective-policy.json", {
    "tools": ["mb_action"], "sandbox": inventory["sandbox"], "enforcement": inventory["enforcement"],
    "removed": inventory["removed"]})

baseline = json.loads((OWNED / "tls-matrix-4/minimal-trust-pem/diagnostic-config.json").read_text())


def normalized_task(config):
    task = Path(config["task"])
    return config["taskProfile"].replace(str(task.parent / "trusted"), "$TRUSTED").replace(
        str(task), "$TASK").replace(str(OWNED / "access-only"), "$AUTH")


assert normalized_task(baseline) == normalized_task(witness["config"])
original_config = json.loads(next((OWNED / "tls-matrix-1").glob("*/diagnostic-config.json")).read_text())
trust_grant = ('(allow mach-lookup (global-name "com.apple.SecurityServer") '
               '(global-name "com.apple.trustd") (global-name "com.apple.trustd.agent"))')


def normalized_cli(config):
    task = Path(config["task"])
    return config["cliProfile"].replace(str(task.parent / "trusted"), "$TRUSTED").replace(
        str(task), "$TASK").replace(str(OWNED / "access-only"), "$AUTH")


assert normalized_cli(witness["config"]).replace(trust_grant + "\n", "") == normalized_cli(original_config)
for policy in (witness["config"]["cliProfile"], witness["config"]["taskProfile"]):
    assert "(deny process-fork)" in policy and "(deny default)" in policy
    assert '(deny mach-lookup (global-name "com.apple.securityd")' in policy
    for path in ("/Library/Keychains", "/System/Library/Keychains"):
        assert f'(deny file-read* file-read-metadata file-write* (subpath "{path}"))' in policy
assert trust_grant not in witness["config"]["taskProfile"]
fixture = """import ctypes,errno,json,os
r={}
for name,path in [('credential',AUTH),('keychain','/Library/Keychains')]:
    try:
        fd=os.open(path,os.O_RDONLY)
    except OSError as e:
        assert e.errno in (errno.EACCES,errno.EPERM),(name,e.errno)
        r[name]=e.errno
    else:
        os.close(fd)
        raise RuntimeError(name+' unexpectedly accessible')
try:
    child=os.fork()
except OSError as e:
    assert e.errno in (errno.EACCES,errno.EPERM)
    r['fork']=e.errno
else:
    if child==0: os._exit(99)
    os.waitpid(child,0)
    raise RuntimeError('fork unexpectedly permitted')
lib=ctypes.CDLL('/usr/lib/libSystem.B.dylib')
self_port=ctypes.c_uint.in_dll(lib,'mach_task_self_').value
bootstrap=ctypes.c_uint()
lib.task_get_special_port.argtypes=[ctypes.c_uint,ctypes.c_int,ctypes.POINTER(ctypes.c_uint)]
lib.task_get_special_port.restype=ctypes.c_int
assert lib.task_get_special_port(self_port,4,ctypes.byref(bootstrap))==0
lib.bootstrap_look_up.argtypes=[ctypes.c_uint,ctypes.c_char_p,ctypes.POINTER(ctypes.c_uint)]
lib.bootstrap_look_up.restype=ctypes.c_int
r['trustLookup']={}
for name in ['com.apple.SecurityServer','com.apple.trustd','com.apple.trustd.agent']:
    port=ctypes.c_uint()
    code=lib.bootstrap_look_up(bootstrap,name.encode(),ctypes.byref(port))
    assert code!=0 and port.value==0,(name,code)
    r['trustLookup'][name]=code
print(json.dumps(r))
""".replace("AUTH", repr(str(OWNED / "access-only")))
run = prepare(OWNED, suite / "task-denials", seconds=12, diagnostics=(
    {"op": "write", "path": "candidate.py", "data": fixture},
    {"op": "run", "path": "candidate.py"}))
child = launch(run)
child.wait(timeout=30)
child.stdin.close()
terminal = project("task-denials", run)
assert terminal["stopReason"] == "diagnostics_complete"
denials = json.loads((run / "receipt/task-2-stdout.bin").read_bytes())
assert set(denials["trustLookup"]) == {
    "com.apple.SecurityServer", "com.apple.trustd", "com.apple.trustd.agent"}
add("current/task-denials/denials.json", denials)

controller_code = (
    "import sys,time;from pathlib import Path;"
    f"sys.path.insert(0,{str(HERE)!r});from runner import prepare,launch;"
    f"run=prepare({str(OWNED)!r},{str(suite / 'controller-loss')!r},seconds=12,hold=True);"
    "child=launch(run);child.wait(timeout=30)"
)
controller = subprocess.Popen([sys.executable, "-c", controller_code])
run = suite / "controller-loss"
wait_file(run / "receipt/ready.json")
controller.kill()
controller.wait(timeout=5)
wait_file(run / "receipt/terminal.json")
terminal = project("controller-loss", run)
assert terminal["stopReason"] == "controller_lost"
add("current/controller-loss/recovery.json", recovery(run))

run = prepare(OWNED, suite / "deadline", seconds=1, hold=True)
child = launch(run)
child.wait(timeout=30)
child.stdin.close()
terminal = project("deadline", run)
assert terminal["stopReason"] == "timeout"

controls = []
for number in range(1, 5):
    matrix = OWNED / f"tls-matrix-{number}"
    for config_path in sorted(matrix.glob("*/diagnostic-config.json")):
        config = json.loads(config_path.read_text())
        receipt = json.loads((config_path.parent / "receipt/tls-comparison.json").read_text())
        name = f"controls/matrix-{number}/{config_path.parent.name}"
        add(name + "/config.json", config)
        add(name + "/receipt.json", receipt)
        controls.append({"case": name, "outcome": receipt})
for name in (*SOURCES, "tls_probe.mjs"):
    public["source/" + name] = (HERE / name).read_bytes()
public["source/publish_tls.py"] = Path(__file__).read_bytes()
failed = OWNED / "mb006e-current/task-denials"
project("retained-fixture-abi-failure", failed)
add("current/retained-fixture-abi-failure/error.json",
    {"error": "task_get_bootstrap_port is a macro, not an exported libSystem symbol",
     "correction": "Use the existing validated task_get_special_port API with TASK_BOOTSTRAP_PORT=4"})
assert "session.send" not in (HERE / "tls_probe.mjs").read_text()
for name, sha in historical.items():
    assert digest(HERE / name) == sha

with tarfile.open(HERE / "tls-evidence.tar.gz", "x:gz") as archive:
    for name, content in sorted(public.items()):
        member = tarfile.TarInfo(name)
        member.size, member.mode, member.mtime = len(content), 0o600, 0
        archive.addfile(member, io.BytesIO(content))
receipt = {
    "slice": "MB-006e", "source": source, "transportReady": True, "transport": witness,
    "archiveSha256": digest(HERE / "tls-evidence.tar.gz"), "controls": controls,
    "historicalPreserved": historical, "taskPolicyByteEquivalent": True,
    "transportPolicyExactDelta": ["com.apple.SecurityServer", "com.apple.trustd", "com.apple.trustd.agent"],
    "evidenceGeneratorSha256": digest(Path(__file__)),
    "infrastructureFailures": [{
        "command": f"{sys.executable} -m pytest tests/projects/michael_bench/ -q",
        "result": "collection failed: tests/projects/michael_bench/test_cli.py imports missing inspect_ai",
        "handling": "Retained; no package installation; exact focused selectors passed instead"
    }],
    "nativePrompts": 0, "newCanaries": 0, "oldSlotsSpent": 2,
    "backendIdentity": "unknown", "modelUsage": "unknown",
    "platformAttestation": "pending-authorized-local-attestation",
    "diagnosis": "Custom CLI profile lacked native public-trust IPC. Pinned PEM works in the actual native component; three documented IPC grants suffice without fork, securityd or Keychain-file access.",
    "scope": "Public HTTPS and trusted confined fixture/cutoff checks only; no inference authority restored.",
}
persist(HERE / "tls-diagnosis.json", receipt)
print(json.dumps({"transportReady": True, "nativePrompts": 0, "newCanaries": 0,
                  "archiveSha256": receipt["archiveSha256"], "taskPolicyByteEquivalent": True}))
