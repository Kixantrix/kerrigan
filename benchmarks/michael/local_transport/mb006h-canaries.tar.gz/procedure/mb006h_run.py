"""Exactly the two directly authorized MB-006h controller prompts; no retry."""
import base64
import collections
import datetime
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT = Path.cwd()
HERE = ROOT / "benchmarks/michael/local_transport"
OWNED = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from proof import MODELS, digest, persist
from runner import SOURCES, MB006H_LIMITS, bound_transport, launch, prepare, recovery

state = OWNED / "mb006h"
state.mkdir(mode=0o700)
source = {name: digest(HERE / name) for name in SOURCES}
protocol = json.loads(subprocess.check_output([
    "node", "--input-type=module", "-e",
    "import {PROTOCOL} from './benchmarks/michael/local_transport/protocol.mjs';"
    "console.log(JSON.stringify(PROTOCOL));"], cwd=ROOT, timeout=5))
assert {key: protocol[key] for key in MB006H_LIMITS} == MB006H_LIMITS
g = json.loads((HERE / "mb006g-verification.json").read_text())
assert source["protocol.mjs"] == g["source"]["protocol.mjs"]
assert source["owner.mjs"] == g["source"]["owner.mjs"]
old = {str(path.relative_to(OWNED)): digest(path)
       for folder in ("canary-slots", "mb006f/slots")
       for path in (OWNED / folder).glob("*.json")}
assert len(old) == 4
historical = {path.name: digest(path) for path in HERE.iterdir() if path.is_file()
              and path.suffix in (".json", ".gz") and not path.name.startswith("mb006h")}
safety = json.loads((OWNED / "mb006h-safety/safety.json").read_text())
assert safety["source"] == source and bound_transport(safety, source, OWNED)
assert safety["taskPolicyByteEquivalent"] is True
assert safety["archiveSha256"] == digest(HERE / "mb006h-safety.tar.gz")
proof = {
    "condition": "MB-006h", "source": source, "passed": True, "transportReady": True,
    "transport": safety["transport"], "attester": "authorized-local-executor",
    "evidenceClass": "local-agent-attested", "environment": "local-attested-macos",
    "level": "scenario", "humanObserved": False, "protocolLimits": MB006H_LIMITS,
    "authorization": "Human directly selected: Authorize this exact MB-006h condition",
    "attestedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "priorEvidence": historical, "currentSafetyArchiveSha256": safety["archiveSha256"],
    "currentSafety": {name: json.loads((OWNED / "mb006h-safety" / name / "receipt/terminal.json").read_text())[
        "wholeProcessQuiescent"] for name in ("native-https", "task-denials", "controller-loss", "deadline")},
    "assertion": "Authorized local executor reviewed preserved exact macOS proof and fresh final-source HTTPS, unchanged task profile, denied credential/Keychain/fork/trust IPC and owned controller-loss/deadline exits; not human-observed evidence."
}
assert all(proof["currentSafety"].values())
persist(state / "approval.json", proof)
seal = {
    "condition": "MB-006h", "models": list(MODELS), "controllerPromptsPerModel": 1,
    "activeSeconds": 180, "cleanupSeconds": 15, "source": source,
    "approvalSha256": digest(state / "approval.json"), "protocolLimits": MB006H_LIMITS,
    "priorSlots": old, "retry": False, "scored": False,
}
persist(HERE / "mb006h-authorization.json", seal)
persist(HERE / "mb006h-attestation.json", proof)
public = {}


def save(name, value):
    public[name] = json.dumps(value, separators=(",", ":"), sort_keys=True).encode()


summaries = []
selected = {"model.model_call_started", "model.call_failure", "model.model_call_failure",
            "model.turn_retry", "assistant.turn_retry", "assistant.usage", "session.error",
            "session.idle", "assistant.turn_start", "assistant.turn_end"}
for model in MODELS:
    assert {name: digest(HERE / name) for name in SOURCES} == source
    for path, sha in old.items():
        assert digest(OWNED / path) == sha
    run = prepare(OWNED, state / model, seconds=180, model=model,
                  approval=state / "approval.json", live_condition=True)
    child = launch(run)
    try:
        child.wait(timeout=196)
    finally:
        child.stdin.close()
    terminal = json.loads((run / "receipt/terminal.json").read_text())
    safe = {key: terminal[key] for key in (
        "stopReason", "activeSeconds", "cleanupSeconds", "wholeProcessQuiescent",
        "actions", "actionBytes", "counts", "events", "requestedModel", "observedModel",
        "usage", "ownerRetries", "nativeStarts", "nativePrompts", "replayedActions", "verdict",
        "protocolCondition", "protocolBytes", "unparsedProtocolBytesLowerBound",
        "evidenceDiskBytesBeforeTerminal")}
    assert {key: safe["protocolCondition"][key] for key in MB006H_LIMITS} == MB006H_LIMITS
    safe["nativeInvocationEvents"] = [
        item for item in terminal["messages"]
        if item["message"].get("params", {}).get("event", {}).get("type") in selected]
    shapes = collections.defaultdict(lambda: {"events": 0, "jsonBytes": 0})
    for item in terminal["messages"]:
        message = item["message"]
        name = message.get("params", {}).get("event", {}).get(
            "type", message.get("method", "rpc-response"))
        shapes[name]["events"] += 1
        shapes[name]["jsonBytes"] += len(json.dumps(message).encode())
    safe["eventShapeCountsOnly"] = dict(shapes)
    safe["records"] = [{key: record.get(key) for key in (
        "kind", "id", "reaped", "result", "warnings", "finishedMs")} for record in terminal["records"]]
    safe["rawSha256"] = {path.name: digest(path) for path in (run / "receipt").glob("*.bin")}
    safe["backendExecutionIdentity"], safe["cost"] = "unknown", "unknown"
    safe["independentTaskCompletion"] = "not evaluated; readiness only"
    inventory = json.loads((run / "receipt/inventory.json").read_text())
    transport = json.loads((run / "receipt/transport.json").read_text())
    assert transport["transportReady"] is True and transport["source"] == source
    assert transport["response"]["verified"] is True
    assert [tool["name"] for tool in inventory["metadata"]["tools"]] == ["mb_action"]
    assert terminal["nativePrompts"] <= 1 and terminal["ownerRetries"] == 0
    assert terminal["activeSeconds"] <= 181 and terminal["cleanupSeconds"] <= 15
    assert terminal["wholeProcessQuiescent"] is True
    assert all(record["reaped"] and not record["warnings"] for record in terminal["records"])
    assert recovery(run)["signalsSent"] == recovery(run)["replayedActions"] == 0
    safe["actionsObserved"] = []
    for action in sorted((run / "receipt").glob("action-*.json")):
        value = json.loads(action.read_text())
        save(f"{model}/{action.name}", value)
        if "args" in value:
            safe["actionsObserved"].append({"op": value["args"]["op"], "path": value["args"]["path"]})
        if "stdout" in value.get("result", {}):
            safe.setdefault("actionStdout", []).append(
                base64.b64decode(value["result"]["stdout"]).decode(errors="replace"))
    save(f"{model}/terminal-safe.json", safe)
    save(f"{model}/config.json", json.loads((run / "config.json").read_text()))
    save(f"{model}/transport.json", transport)
    save(f"{model}/inventory-safe.json", {
        "tools": ["mb_action"], "sandbox": inventory["sandbox"], "enforcement": inventory["enforcement"],
        "removed": inventory["removed"]})
    for name in ("start.json", "prompt-start.json"):
        path = run / "receipt" / name
        if path.exists():
            save(f"{model}/{name}", json.loads(path.read_text()))
    summaries.append(safe)
    persist(run / "summary.json", safe)
    print(json.dumps({key: safe.get(key) for key in (
        "requestedModel", "stopReason", "nativePrompts", "activeSeconds", "cleanupSeconds",
        "wholeProcessQuiescent", "nativeStarts", "actionsObserved", "actionStdout", "usage")}), flush=True)

for path, sha in old.items():
    assert digest(OWNED / path) == sha
for name, sha in historical.items():
    assert digest(HERE / name) == sha
for name in SOURCES:
    public["source/" + name] = (HERE / name).read_bytes()
public["procedure/mb006h_run.py"] = Path(__file__).read_bytes()
public["procedure/publish_tls.py"] = (OWNED / "publish_tls.py").read_bytes()
for path in sorted((state / "slots").glob("*.json")):
    save("slots/" + path.name, json.loads(path.read_text()))
with tarfile.open(HERE / "mb006h-canaries.tar.gz", "x:gz") as archive:
    for name, content in sorted(public.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(content), 0o600, 0
        archive.addfile(info, io.BytesIO(content))
report = {
    "condition": "MB-006h", "source": source, "attestationSha256": digest(HERE / "mb006h-attestation.json"),
    "authorizationSha256": digest(HERE / "mb006h-authorization.json"),
    "safetyArchiveSha256": digest(HERE / "mb006h-safety.tar.gz"),
    "canaryArchiveSha256": digest(HERE / "mb006h-canaries.tar.gz"),
    "historicalPreserved": historical, "oldSlotsPreserved": old, "canaries": summaries,
    "controllerPrompts": sum(item["nativePrompts"] for item in summaries),
    "nativeStarts": sum(len(item["nativeStarts"]) for item in summaries),
    "verdict": "ungraded", "scoredTasks": 0, "backendExecutionIdentity": "unknown", "cost": "unknown",
    "remainingGates": ["readiness does not establish independent historical task completion",
                       "scoring/integration requires separate authorization"],
    "commands": ["exact focused pytest selectors: 138 passed",
                 "publish_tls.py: final-source non-inference native safety/HTTPS passed",
                 "mb006h_run.py: two exclusive sequential controller prompts, no retries"],
}
with (HERE / "mb006h-outcomes.json").open("x") as stream:
    stream.write(json.dumps(report, separators=(",", ":"), sort_keys=True) + "\n")
print("REPORT", digest(HERE / "mb006h-outcomes.json"), flush=True)
