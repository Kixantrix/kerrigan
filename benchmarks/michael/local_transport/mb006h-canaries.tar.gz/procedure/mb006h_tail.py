"""Private post-cutoff shape audit; no model, task or authentication operations."""
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile

HERE = Path.cwd() / "benchmarks/michael/local_transport"
OWNED = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from proof import digest

script = """
import {readFileSync} from 'node:fs';
import {Protocol} from './benchmarks/michael/local_transport/protocol.mjs';
const out=[];
for(const spec of JSON.parse(process.argv[1])) {
 const bytes=readFileSync(spec.path),events=[];
 const p=new Protocol(m=>{const e=m.params?.event;
  if(e&&(/retry|failure/.test(e.type)||e.type==='model.model_call_started')) {
   const data=e.data||{},safe={};
   for(const key of ['model','retryAttempt','retryIndex','errorMessage','durationMs'])
    if(data[key]!==undefined)safe[key]=data[key];
   events.push({type:e.type,data:safe,streamEnd:p.total});
  }
 });
 p.feed(bytes);p.finish();
 out.push({model:spec.model,receivedBytes:bytes.length,consumedBytes:p.total,finish:'complete',events});
}
console.log(JSON.stringify(out));
"""
inputs = [{"model": model, "path": str(OWNED / f"mb006h/{model}/receipt/cli-0-stdout.bin")}
          for model in ("mai-code-2", "claude-sonnet-5.5")]
tails = json.loads(subprocess.check_output(
    ["node", "--input-type=module", "-e", script, json.dumps(inputs)], timeout=10))
report_path = HERE / "mb006h-outcomes.json"
report = json.loads(report_path.read_text())
for item in tails:
    item["rawSha256"] = digest(Path(next(x["path"] for x in inputs if x["model"] == item["model"])))
    assert not any("retry" in event["type"] for event in item["events"])
    starts = [event for event in item["events"] if event["type"] == "model.model_call_started"]
    assert len(starts) == (1 if item["model"] == "mai-code-2" else 3)
    if item["model"] == "mai-code-2":
        assert [event["type"] for event in item["events"]] == [
            "model.model_call_started", "model.call_failure", "model.model_call_failure"]
    canary = next(c for c in report["canaries"] if c["requestedModel"] == item["model"])
    assert item["rawSha256"] == canary["rawSha256"]["cli-0-stdout.bin"]
    canary["receivedNativeEventsIncludingCutoffTail"] = item["events"]
    canary["nativeEventsAfterCutoff"] = (
        "All received bytes privately parsed offline; MAI tail contains additional model.model_call_failure, no additional start/retry. Events never received after kill remain unknown."
        if item["model"] == "mai-code-2" else "No unparsed received tail; three natural calls, no native retry event observed.")
audit = {
    "condition": "MB-006h", "source": report["source"], "tails": tails,
    "controllerPrompts": 2, "nativeStartsObservedIncludingReceivedTails": 4,
    "controllerRetries": 0, "nativeRetryEventsObserved": 0,
    "boundaries": "Audit parses only retained bytes; never replays requests, authorizes tools or infers events beyond received data.",
    "commands": [
        "python -m pytest tests/projects/michael_bench/test_local_transport.py tests/projects/michael_bench/test_historical_import.py tests/projects/michael_bench/test_manifests.py -q: 138 passed",
        "python tools/validators/check_artifacts.py: passed",
        "python tools/validators/check_python_deps.py: passed, 58 test files",
        "node --check owner.mjs/protocol.mjs/synthetic_sdk.mjs: passed (individual exact paths under benchmarks/michael/local_transport)",
        "git diff --check: passed",
        "mb006h_tail.py: privately parsed received complete native frames and verified all starts/failures including cutoff tail",
    ]
}
audit_bytes = json.dumps(audit, separators=(",", ":"), sort_keys=True).encode()
with (HERE / "mb006h-audit.json").open("xb") as stream:
    stream.write(audit_bytes + b"\n")
archive_path = HERE / "mb006h-canaries.tar.gz"
assert digest(archive_path) == report["canaryArchiveSha256"]
members = {}
with tarfile.open(archive_path) as archive:
    for member in archive.getmembers():
        members[member.name] = archive.extractfile(member).read()
members["audit/received-tail-shapes.json"] = audit_bytes
members["procedure/mb006h_tail.py"] = Path(__file__).read_bytes()
archive_path.rename(OWNED / "mb006h/pre-tail-safe-canaries.tar.gz")
with tarfile.open(archive_path, "x:gz") as archive:
    for name, content in sorted(members.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(content), 0o600, 0
        archive.addfile(info, io.BytesIO(content))
report["canaryArchiveSha256"] = digest(archive_path)
report["receivedTailAuditSha256"] = digest(HERE / "mb006h-audit.json")
report_path.rename(OWNED / "mb006h/pre-tail-safe-outcomes.json")
with report_path.open("x") as stream:
    stream.write(json.dumps(report, separators=(",", ":"), sort_keys=True) + "\n")
print("FINAL_REPORT", digest(report_path), "CANARIES", digest(archive_path))
