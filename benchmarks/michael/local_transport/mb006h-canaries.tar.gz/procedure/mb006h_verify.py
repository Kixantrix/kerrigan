"""Final offline publication/binding verification; no inference or auth reads."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tarfile

HERE = Path.cwd() / "benchmarks/michael/local_transport"
OWNED = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from runner import SOURCES, MB006H_LIMITS, bound_transport, profile
from proof import digest

report_path = HERE / "mb006h-outcomes.json"
report = json.loads(report_path.read_text())
attestation = json.loads((HERE / "mb006h-attestation.json").read_text())
seal = json.loads((HERE / "mb006h-authorization.json").read_text())
source = {name: digest(HERE / name) for name in SOURCES}
assert report["source"] == attestation["source"] == seal["source"] == source
assert attestation["humanObserved"] is False
assert attestation["attester"] == "authorized-local-executor"
assert attestation["evidenceClass"] == "local-agent-attested"
assert attestation["protocolLimits"] == seal["protocolLimits"] == MB006H_LIMITS
assert bound_transport(attestation, source, OWNED)
assert seal["approvalSha256"] == digest(OWNED / "mb006h/approval.json")
for key, name in (
    ("authorizationSha256", "mb006h-authorization.json"),
    ("attestationSha256", "mb006h-attestation.json"),
    ("safetyArchiveSha256", "mb006h-safety.tar.gz"),
    ("canaryArchiveSha256", "mb006h-canaries.tar.gz"),
    ("receivedTailAuditSha256", "mb006h-audit.json"),
):
    assert report[key] == digest(HERE / name)
for name, sha in report["historicalPreserved"].items():
    assert digest(HERE / name) == sha
for name, sha in report["oldSlotsPreserved"].items():
    assert digest(OWNED / name) == sha
assert len(report["oldSlotsPreserved"]) == 4
for name in SOURCES:
    if name != "runner.py":
        assert subprocess.check_output(
            ["git", "show", f"5761e49:benchmarks/michael/local_transport/{name}"]
        ) == (HERE / name).read_bytes()


def no_private_fields(value):
    if isinstance(value, dict):
        assert not {"quotaSnapshots", "access_token", "refresh_token",
                    "authorizationToken", "bearerToken", "password", "secret"}.intersection(value)
        for item in value.values():
            no_private_fields(item)
    elif isinstance(value, list):
        for item in value:
            no_private_fields(item)


members = {}
for name in ("mb006h-safety.tar.gz", "mb006h-canaries.tar.gz"):
    with tarfile.open(HERE / name) as archive:
        for member in archive.getmembers():
            assert member.isfile() and not member.name.startswith("/")
            assert ".." not in Path(member.name).parts
            assert "access-only/" not in member.name and not member.name.endswith(".bin")
            content = archive.extractfile(member).read()
            if member.name.startswith("source/") and Path(member.name).name in source:
                filename = Path(member.name).name
                if hashlib.sha256(content).hexdigest() != source[filename]:
                    assert name == "mb006h-canaries.tar.gz" and filename.endswith(".json")
                    original = (HERE / filename).read_bytes()
                    assert json.loads(content) == json.loads(original)
                    content = original
                assert hashlib.sha256(content).hexdigest() == source[filename]
            if member.name.endswith(".json"):
                no_private_fields(json.loads(content))
            if name == "mb006h-canaries.tar.gz":
                members[member.name] = content
for model in ("mai-code-2", "claude-sonnet-5.5"):
    config = json.loads(members[f"{model}/config.json"])
    assert config["condition"] == "MB-006h"
    assert config["environment"]["COPILOT_LLM_RESPONSE_MAX_BYTES"] == "65536"
    assert config["sandbox"]["enabled"] and not config["sandbox"]["allowBypass"]
    assert config["cliProfile"] == profile(Path(config["task"]), OWNED / "access-only", transport=True)
    assert config["taskProfile"] == profile(Path(config["task"]), OWNED / "access-only")
    transport = json.loads(members[f"{model}/transport.json"])
    assert transport["transportReady"] and transport["nativePrompts"] == 0
    assert transport["source"] == source and transport["config"] == config
    assert transport["configSha256"] == hashlib.sha256(json.dumps(
        config, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()
    assert transport["runtime"] == attestation["transport"]["runtime"]
    assert transport["publicCaSha256"] == attestation["transport"]["publicCaSha256"]
    assert transport["request"]["url"] == "https://api.github.com/meta"
    assert transport["request"]["retryOptions"]["maxRetries"] == 0
    response = transport["response"]
    assert response["verified"] and response["kind"] == "response" and response["status"] == 200
    assert response["responseKeys"] == ["bodyBase64", "headers", "kind", "status", "statusText", "url"]
    assert response["bodyBytes"] == 0
    inventory = json.loads(members[f"{model}/inventory-safe.json"])
    assert inventory["tools"] == ["mb_action"]
    assert inventory["removed"]["toolTelemetry"]["properties"]["failure_reason"] == "not_found"
    sandbox = inventory["sandbox"]
    assert not sandbox["disabledForSession"] and not sandbox["autoApproveBypass"]
    assert sandbox["config"]["enabled"] and not sandbox["config"]["allowBypass"]
    assert not sandbox["config"]["userPolicy"]["network"]["allowOutbound"]
    assert sandbox["config"]["userPolicy"]["seatbelt"]["keychainAccess"] is False
    assert json.loads(members[f"slots/{model}.json"]) == json.loads(
        (OWNED / f"mb006h/slots/{model}.json").read_text())

audit_path = HERE / "mb006h-audit.json"
audit = json.loads(audit_path.read_text())
audit["commands"] = [
    f"{OWNED}/validation-venv/bin/python -m pytest tests/projects/michael_bench/test_local_transport.py tests/projects/michael_bench/test_historical_import.py tests/projects/michael_bench/test_manifests.py -q: 138 passed",
    f"{OWNED}/validation-venv/bin/python tools/validators/check_artifacts.py: passed",
    f"{OWNED}/validation-venv/bin/python tools/validators/check_python_deps.py: passed (58 test files)",
    "node --check benchmarks/michael/local_transport/owner.mjs: passed",
    "node --check benchmarks/michael/local_transport/protocol.mjs: passed",
    "node --check benchmarks/michael/local_transport/synthetic_sdk.mjs: passed",
    "git diff --check: passed",
    f"PYTHONDONTWRITEBYTECODE=1 {OWNED}/validation-venv/bin/python {OWNED}/mb006h_tail.py: passed (no inference)",
    f"PYTHONDONTWRITEBYTECODE=1 {OWNED}/validation-venv/bin/python {OWNED}/mb006h_verify.py: passed (final source/archive/slot/config/live-policy/native-HTTPS bindings)",
]
audit["verificationCorrection"] = "One exploratory validator call passed an inner witness instead of the required attestation envelope and failed closed; the corrected envelope passed. Quota projection had canonicalized JSON source-snapshot whitespace; semantic equality was checked and exact frozen source bytes restored before final archive publication. No executed source, policy or native receipts changed."
audit_path.rename(OWNED / "mb006h/pre-final-safe-audit.json")
audit_path.write_text(json.dumps(audit, separators=(",", ":"), sort_keys=True) + "\n")
members["audit/received-tail-shapes.json"] = audit_path.read_bytes()
members["procedure/mb006h_verify.py"] = Path(__file__).read_bytes()
archive_path = HERE / "mb006h-canaries.tar.gz"
archive_path.rename(OWNED / "mb006h/pre-final-safe-canaries.tar.gz")
with tarfile.open(archive_path, "x:gz") as archive:
    for name, content in sorted(members.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(content), 0o600, 0
        archive.addfile(info, io.BytesIO(content))
report["canaryArchiveSha256"] = digest(archive_path)
report["receivedTailAuditSha256"] = digest(audit_path)
report["commands"] = audit["commands"]
report_path.rename(OWNED / "mb006h/pre-final-safe-outcomes.json")
report_path.write_text(json.dumps(report, separators=(",", ":"), sort_keys=True) + "\n")
print("PASS: source/history/four-old-slots/two-spent-slots/strict-HTTPS/effective-policy/safe-archives")
for name in ("mb006h-outcomes.json", "mb006h-audit.json", "mb006h-safety.tar.gz", "mb006h-canaries.tar.gz"):
    print(name, digest(HERE / name))
