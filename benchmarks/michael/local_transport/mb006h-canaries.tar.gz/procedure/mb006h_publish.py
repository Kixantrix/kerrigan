"""Safe projection and verification of completed attempts; no execution launcher."""
import hashlib
import io
import json
from pathlib import Path
import sys
import tarfile

HERE = Path.cwd() / "benchmarks/michael/local_transport"
OWNED = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from proof import digest
from runner import SOURCES, MB006H_LIMITS

report_path = HERE / "mb006h-outcomes.json"
archive_path = HERE / "mb006h-canaries.tar.gz"
report = json.loads(report_path.read_text())
assert report["controllerPrompts"] == 2 and report["nativeStarts"] == 4
assert report["source"] == {name: digest(HERE / name) for name in SOURCES}
assert digest(archive_path) == report["canaryArchiveSha256"]
assert digest(HERE / "mb006h-attestation.json") == report["attestationSha256"]
assert digest(HERE / "mb006h-authorization.json") == report["authorizationSha256"]
assert digest(HERE / "mb006h-safety.tar.gz") == report["safetyArchiveSha256"]
for name, sha in report["historicalPreserved"].items():
    assert digest(HERE / name) == sha
for name, sha in report["oldSlotsPreserved"].items():
    assert digest(OWNED / name) == sha


def sanitize(value):
    if isinstance(value, dict):
        return {key: sanitize(item) for key, item in value.items()
                if key not in ("quotaSnapshots", "billing")}
    if isinstance(value, list):
        return [sanitize(item) for item in value]
    return value


public = {}
with tarfile.open(archive_path) as archive:
    for member in archive.getmembers():
        assert member.isfile() and not member.name.startswith("/") and ".." not in Path(member.name).parts
        assert "access-only/" not in member.name and not member.name.endswith(".bin")
        content = archive.extractfile(member).read()
        if member.name.endswith(".json"):
            content = json.dumps(sanitize(json.loads(content)),
                                 separators=(",", ":"), sort_keys=True).encode()
        public[member.name] = content
public["procedure/mb006h_publish.py"] = Path(__file__).read_bytes()
archive_path.rename(OWNED / "mb006h/private-original-canaries.tar.gz")
with tarfile.open(archive_path, "x:gz") as archive:
    for name, content in sorted(public.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(content), 0o600, 0
        archive.addfile(info, io.BytesIO(content))
report = sanitize(report)
report["canaryArchiveSha256"] = digest(archive_path)
report["publication"] = "Safe projection excludes account-wide quota snapshots and catalog billing; original native bytes and unprojected receipts remain private outside auth state."
for item in report["canaries"]:
    assert {key: item["protocolCondition"][key] for key in MB006H_LIMITS} == MB006H_LIMITS
    assert item["nativePrompts"] == 1 and item["wholeProcessQuiescent"] is True
    assert item["cleanupSeconds"] < 15 and item["ownerRetries"] == 0
    assert item["activeSeconds"] < 180
    assert not any("retry" in name for name in item["eventShapeCountsOnly"])
    item["nativeRetryEventsObserved"] = 0
    item["nativeEventsAfterCutoff"] = "unknown" if item["unparsedProtocolBytesLowerBound"] else "no unparsed bytes observed"
    if item["requestedModel"] == "mai-code-2":
        assert item["stopReason"] == "native_model_failure:model.call_failure" and not item["actions"]
        event = next(e["message"]["params"]["event"] for e in item["nativeInvocationEvents"]
                     if e["message"]["params"]["event"]["type"] == "model.call_failure")
        assert event["data"]["retryAttempt"] == 0
        item["nativeFailureMessage"] = event["data"]["errorMessage"]
        assert "Native model HTTP response exceeds the 65536-byte limit" in item["nativeFailureMessage"]
        item["toolLoopReadiness"] = "failed before any task action; native per-model HTTP response cap, not outer protocol total"
        item["nativeResponseLimitEnvironment"] = {"COPILOT_LLM_RESPONSE_MAX_BYTES": "65536"}
        item["cost"] = "unknown"
    else:
        assert item["stopReason"] == "session_idle"
        assert item["actionsObserved"] == [
            {"op": "write", "path": "candidate.py"}, {"op": "run", "path": "candidate.py"}]
        assert item["actionStdout"] == ["written\n", "5\n"]
        assert item["unparsedProtocolBytesLowerBound"] == 0 and len(item["nativeStarts"]) == 3
        assert all(usage["retryIndex"] == 0 and usage["attemptIndex"] == 0 for usage in item["usage"])
        item["toolLoopReadiness"] = "observed native write/run/result/idle; not a historical benchmark score"
        item["nativeUsageSummary"] = {
            "model": sorted({usage["model"] for usage in item["usage"]}),
            "responseModel": sorted({usage["responseModel"] for usage in item["usage"]}),
            "naturalToolLoopCalls": len(item["usage"]),
            "inputTokens": sum(usage["inputTokens"] for usage in item["usage"]),
            "outputTokens": sum(usage["outputTokens"] for usage in item["usage"]),
            "cacheReadTokens": sum(usage["cacheReadTokens"] for usage in item["usage"]),
            "cacheWriteTokens": sum(usage["cacheWriteTokens"] for usage in item["usage"]),
            "nativeCostFields": [usage["cost"] for usage in item["usage"]],
            "nativeTotalNanoAiu": sum(usage["copilotUsage"]["totalNanoAiu"] for usage in item["usage"]),
            "monetaryCost": "unknown; no unit conversion or fiat price inferred",
        }
        item["cost"] = "native counters exposed; monetary interpretation unknown"
    public_terminal = public[f"{item['requestedModel']}/terminal-safe.json"]
    assert b"quotaSnapshots" not in public_terminal
report["remainingGates"] = [
    "MAI readiness failed at the unchanged native per-response HTTP 65536-byte cap; no tuning/retry was authorized",
    "Sonnet readiness is one controlled live tool loop, not independent historical task completion or scoring",
    "all six slots remain spent; any additional inference requires separate authorization",
]
report["commands"] = [
    "python -m pytest tests/projects/michael_bench/test_local_transport.py tests/projects/michael_bench/test_historical_import.py tests/projects/michael_bench/test_manifests.py -q: 138 passed",
    "publish_tls.py: final-source native HTTPS/task-denial/controller-SIGKILL/deadline proofs passed",
    "mb006h_run.py: exactly two frozen sequential controller prompts; both native owned exits proved",
    "mb006h_publish.py: immutable historical/source/slot checks and safe quota-excluding projection passed",
]
report_path.rename(OWNED / "mb006h/private-original-outcomes.json")
with report_path.open("x") as stream:
    stream.write(json.dumps(report, separators=(",", ":"), sort_keys=True) + "\n")
print("SAFE_REPORT", digest(report_path), "CANARIES", digest(archive_path))
print(json.dumps([{"model": item["requestedModel"], "readiness": item["toolLoopReadiness"],
                   "usage": item.get("nativeUsageSummary", "unknown")} for item in report["canaries"]]))
