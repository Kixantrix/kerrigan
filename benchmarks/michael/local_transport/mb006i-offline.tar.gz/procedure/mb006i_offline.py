"""Publish labeled offline owner/parser evidence. No native SDK or inference."""
import ast
from collections import Counter
import hashlib
import importlib.util
import io
import json
import shlex
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT = Path.cwd()
HERE = ROOT / "benchmarks/michael/local_transport"
OWNED = Path(__file__).resolve().parent
STATE = OWNED / "mb006i-offline"
STATE.mkdir(exist_ok=False)
sys.path.insert(0, str(HERE))
from runner import SOURCES, corrected_allowance
from proof import BUDGETS, ProofError, digest, environment

def previous(name):
    return subprocess.check_output(["git", "show", f"9eba207:benchmarks/michael/local_transport/{name}"])

history = {}
for filename in subprocess.check_output(
        ["git", "ls-tree", "-r", "--name-only", "9eba207", "benchmarks/michael/local_transport/"],
        text=True).splitlines():
    path = Path(filename)
    if path.suffix in (".json", ".gz") and path.name != "budgets.json":
        assert path.read_bytes() == previous(path.name)
        history[path.name] = digest(path)
slots = {
    f"{namespace}/{model}.json": digest(OWNED / namespace / f"{model}.json")
    for namespace in ("canary-slots", "mb006f/slots", "mb006h/slots")
    for model in ("mai-code-2", "claude-sonnet-5.5")
}
assert len(slots) == 6
for node in ast.parse((HERE / "runner.py").read_text()).body:
    if isinstance(node, ast.FunctionDef) and node.name == "profile":
        old = next(n for n in ast.parse(previous("runner.py")).body
                   if isinstance(n, ast.FunctionDef) and n.name == "profile")
        assert ast.dump(node) == ast.dump(old)
source = {name: digest(HERE / name) for name in SOURCES}
spec = importlib.util.spec_from_file_location(
    "offline_checks", ROOT / "tests/projects/michael_bench/test_local_transport.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
summaries = []
variants = [
    ("large", {"largeResponse": True}, "diagnostics_complete"),
    ("large-first-failure", {"largeResponse": True, "fragment": 65536, "failure": True},
     "native_model_failure:model.call_failure"),
    ("full-task-output", {"taskFullOutput": True}, "diagnostics_complete"),
    ("frame-overflow", {"frameOverflow": BUDGETS["frame"]}, "protocol:protocol_frame_denied"),
]
for label, variant, expected in variants:
    work = STATE / label
    work.mkdir()
    module.test_actual_owner_broker_with_labeled_synthetic_sdk(work, variant, expected)
    terminal = json.loads((work / "run/receipt/terminal.json").read_text())
    counts = Counter(item["message"].get("params", {}).get("event", {}).get("type", "rpc-response")
                     for item in terminal["messages"])
    summaries.append({
        "label": label, "fixture": variant, "evidenceClass": "synthetic-sdk-actual-owner-parser",
        "nativeExecution": False, "nativePrompts": terminal["nativePrompts"],
        "stopReason": terminal["stopReason"], "wholeSyntheticHandlesQuiescent": terminal["wholeProcessQuiescent"],
        "activeSeconds": terminal["activeSeconds"], "cleanupSeconds": terminal["cleanupSeconds"],
        "protocolBytes": terminal["protocolBytes"], "events": terminal["events"],
        "eventTypeCounts": dict(counts), "actions": len(terminal["actions"]),
        "sentBytes": terminal["counts"].get("sent", 0),
        "evidenceDiskBytesBeforeTerminal": terminal["evidenceDiskBytesBeforeTerminal"],
        "unparsedProtocolBytesLowerBound": terminal["unparsedProtocolBytesLowerBound"],
        "rawProtocolSha256": digest(work / "run/receipt/cli-0-stdout.bin"),
        "terminalSha256": digest(work / "run/receipt/terminal.json"),
    })
for name, sha in slots.items():
    assert digest(OWNED / name) == sha
for name, sha in history.items():
    assert digest(HERE / name) == sha
assert source == {name: digest(HERE / name) for name in SOURCES}
result = {
    "condition": BUDGETS["condition"], "budgets": BUDGETS, "source": source,
    "fixtureSources": {name: digest(HERE / name) for name in ("synthetic_sdk.mjs",)},
    "controllerPrompts": 0, "nativeRequests": 0, "newSlots": 0, "spentSlotsPreserved": slots,
    "historicalPreserved": history, "scoredTasks": 0, "readyToInfer": False,
    "nativeReadiness": "unvalidated; frozen f/h source approvals stale; no new allowance",
    "nativeSemantics": {
        "observed": "Preserved MB-006h native failure names the process-local 65536-byte HTTP response ceiling",
        "installedSchema": "copilot-rpc.ts exposes gitHubFetch.bodyLimitBytes separately; not the model HTTP env parser",
        "inspection": "UTF8/UTF16 static symbol searches negative; apparent Zstd marker did not decode as a valid complete frame",
        "unknown": "Exact native pre/post-content-decoding counting, default/range parser and acceptance of proposed 131072 ceiling remain unverified; no inferred supported semantics",
    },
    "memory": "Finite wire/event retained input and one bounded frame; not an OS RSS guarantee",
    "syntheticCases": summaries,
    "verificationCommands": [
        f"{OWNED}/validation-venv/bin/python -m pytest tests/projects/michael_bench/test_local_transport.py tests/projects/michael_bench/test_historical_import.py tests/projects/michael_bench/test_manifests.py -q",
        f"PYTHONDONTWRITEBYTECODE=1 {OWNED}/validation-venv/bin/python {OWNED}/mb006i_offline.py",
        f"{OWNED}/validation-venv/bin/python tools/validators/check_artifacts.py",
        f"{OWNED}/validation-venv/bin/python tools/validators/check_python_deps.py",
        "node --check benchmarks/michael/local_transport/owner.mjs",
        "node --check benchmarks/michael/local_transport/protocol.mjs",
        "node --check benchmarks/michael/local_transport/synthetic_sdk.mjs",
        "git diff --check",
    ],
}
result["verificationResults"] = []
for index, command in enumerate(result["verificationCommands"]):
    if index == 1:
        result["verificationResults"].append({
            "command": command, "result": "passed four labeled actual-owner synthetic cases and history/slot checks"})
        continue
    checked = subprocess.run(shlex.split(command), check=True, text=True,
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=180)
    result["verificationResults"].append({
        "command": command, "result": checked.stdout.strip() or "passed (exit 0)"})
    print(command, result["verificationResults"][-1]["result"])
archive_path = HERE / "mb006i-offline.tar.gz"
with tarfile.open(archive_path, "x:gz") as archive:
    members = {f"source/{name}": (HERE / name).read_bytes() for name in SOURCES}
    members["fixture/synthetic_sdk.mjs"] = (HERE / "synthetic_sdk.mjs").read_bytes()
    members["procedure/mb006i_offline.py"] = Path(__file__).read_bytes()
    members["documentation/README.md"] = (HERE / "README.md").read_bytes()
    members["offline-synthetic-summary.json"] = json.dumps(result, sort_keys=True).encode()
    for name, content in sorted(members.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(content), 0o600, 0
        archive.addfile(info, io.BytesIO(content))
result["archiveSha256"] = digest(archive_path)
with (HERE / "mb006i-verification.json").open("x") as stream:
    stream.write(json.dumps(result, sort_keys=True, separators=(",", ":")) + "\n")
print("OFFLINE_REPORT", digest(HERE / "mb006i-verification.json"))
print("OFFLINE_ARCHIVE", result["archiveSha256"])
for item in summaries:
    print(json.dumps(item, sort_keys=True))
