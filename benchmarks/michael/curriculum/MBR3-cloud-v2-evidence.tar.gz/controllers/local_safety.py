"""Fresh pre-window native safety proof for the local-laptop task set (Docker before the window only)."""
import importlib.util
import json
from pathlib import Path
import sys

REPO = Path("/Users/mvh/.copilot/repos/copilot-worktrees/kerrigan/kixantrix-verbose-enigma")
OWNED = Path("/Users/mvh/.copilot/session-state/a45ee9a4-394e-4af7-afba-d8f78ae19672/files/local-mxc")
ROOT = OWNED / __import__("os").environ.get("MB_SAFETY_ROOT", "mbr3-local-safety-v9e")
sys.path.insert(0, str(REPO))
from benchmarks.michael.replay_trial import api, curriculum as native  # noqa: E402
from benchmarks.michael.replay_grader import specs  # noqa: E402
from benchmarks.michael.tasks import curriculum as tasks  # noqa: E402

TASKS = tuple(json.loads((Path(__file__).parent / "local_tasks.json").read_text())) + tuple(
    t for t in __import__("os").environ.get("MB_EXTRA_TASKS", "").split(",") if t)
read = lambda path: json.loads(path.read_bytes())
DISCREPANCIES = []


def main():
    assert api.packages.ROOT.resolve() == REPO.resolve()
    ROOT.mkdir(exist_ok=True)
    for name in TASKS:
        policy = native.round_three_policy(name)
        retained = read((tasks.package_dir(name) if name.startswith("anchor-") or name in tasks.PACKAGES else tasks.HERE / name) / "calibration.json")
        for label, data in (("base", specs.base(name)), ("reference", specs.reference(name))):
            folder = ROOT / "calibration" / name / label
            if (folder / "independent-grader/report.json").exists():
                assert read(folder / "curriculum-start.json")["source"] == native.sources()
                report = read(folder / "independent-grader/report.json")
            else:
                report = native.offline(OWNED, folder, name, data, policy=policy)
            phases = {p["phase"]: p for p in retained["phases"]}
            wanted = "baseline" if label == "base" else "reference"
            passed = sum(row["passed"] for row in report["counts"].values())
            total = sum(row["total"] for row in report["counts"].values())
            assert report["status"] == "graded" and total > 0
            if wanted in phases and name.startswith("anchor-") and report["counts"] != phases[wanted]["counts"]:
                # Native verifier images are rebuilt locally; keep the admission property, disclose the difference.
                assert passed < total if label == "base" else passed == total, (name, label, report["counts"])
                DISCREPANCIES.append({"task": name, "phase": label, "native": report["counts"],
                                      "retained": phases[wanted]["counts"]})
            elif wanted in phases:
                assert report["counts"] == phases[wanted]["counts"], (name, label, report["counts"])
            else:
                # Round-one packages retain differently named phases; require the admission property.
                assert passed < total if label == "base" else passed == total, (name, label, report["counts"])
            assert report["cleanup"]["proven"]
            print("calibrated", name, label, report["counts"], flush=True)
    specification = importlib.util.spec_from_file_location(
        "checks", REPO / "tests/projects/michael_bench/test_curriculum_native.py")
    checks = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(checks)
    for name in ("validator", "grouping"):
        folder = ROOT / ("scratch-proof-" + name)
        if not folder.exists():
            folder.mkdir()
            checks.test_round_three_tmpdir_write_run_cleanup_and_denial(OWNED, folder, name)
    proof = {"passed": True, "condition": __import__("os").environ.get("MB_SAFETY_CONDITION", "MB-R3/local-laptop"), "source": native.sources(),
             "calibration": str(ROOT / "calibration"), "attester": "authorized-local-executor-2",
             "nativePrompts": 0, "classes": ["exact native calibration and Docker reference/base",
                 "actual Node/Python sandbox scratch, denial/no-fork and disposal"],
             "calibrationDiscrepancies": DISCREPANCIES, "subjectTargets": __import__("os").environ.get("MB_SAFETY_TARGETS", "mtplx-inkling-2-mini-optimized-quality").split(","), "taskList": list(TASKS)}
    api.grader.persist(ROOT / "safety.json", proof)
    print("safety sealed", len(TASKS), flush=True)


if __name__ == "__main__":
    main()
