"""MB-R3M: additional cloud models on the admitted latest-version task set (screen, then fill)."""
import json
import sys
from pathlib import Path

REPO = Path("/Users/mvh/.copilot/repos/copilot-worktrees/kerrigan/kixantrix-verbose-enigma")
OWNED = Path("/Users/mvh/.copilot/session-state/a45ee9a4-394e-4af7-afba-d8f78ae19672/files/local-mxc")
sys.path.insert(0, str(REPO))
from benchmarks.michael.replay_trial import api, curriculum as native  # noqa: E402
from benchmarks.michael.curriculum import admit, live, metrics  # noqa: E402
from benchmarks.michael.tasks import curriculum as tasks  # noqa: E402

HERE = Path(__file__).parent
MODELS = ("claude-opus-5.5", "gpt-6.2-sol", "gpt-6.2-astra", "gemini-4-neon", "gpt-5.6-sol")
FAMILY = {"claude-sonnet-5.5": "anthropic", "mai-code-2": "microsoft", "claude-opus-5.5": "anthropic", "gpt-6.2-sol": "openai", "gpt-6.2-astra": "openai",
          "gemini-4-neon": "google", "gpt-5.6-sol": "openai"}
JUDGES = {"anthropic": (("gpt-5.6-sol", "openai"), ("gemini-4-neon", "google")),
          "openai": (("claude-sonnet-5.5", "anthropic"), ("gemini-4-neon", "google")),
          "google": (("claude-sonnet-5.5", "anthropic"), ("gpt-5.6-sol", "openai")),
          "microsoft": (("claude-sonnet-5.5", "anthropic"), ("gpt-5.6-sol", "openai"))}
TASKS = tuple(json.loads((HERE / "local_tasks.json").read_text()))
PHASES = {"screen": ("mbr3-models-screen-v11", (1,)), "screen12": ("mbr3-models-screen-v12b", (1,)),
          "fill": ("mbr3-models-fill-v13", (2, 3)), "anchors": ("mbr3-anchors-v13", (1, 2, 3)),
          "anchors-exception": ("mbr3-anchors-exception-v13", (1, 2, 3))}
ANCHORS = ("anchor-tb-fix-git", "anchor-tb-nginx-request-logging", "anchor-swepro-ansible",
           "anchor-swepro-openlibrary", "anchor-swepro-qutebrowser")

EARLIER = ("claude-sonnet-5.5", "mai-code-2")
ROUND12 = ("validator", "grouping", "status", "selfhost-redeploy-state", "sr-temporal-assay",
           "plan-dashboard-waves-v2", "research-serverless-cost-v2")
DEFER = __import__("os").environ.get("MB_DEFER_GRADING") == "1"
read = lambda path: json.loads(Path(path).read_bytes())


def policy(name):
    return native.round_three_policy(name, active_seconds=10800 if name in tasks.PACKAGES and tasks.meta(name).get("long_horizon") else 3600)


def rotated(index, repeat):
    shift = (index + repeat - 1) % len(MODELS)
    return list(MODELS[shift:] + MODELS[:shift])


def persist(path, value):
    if path.exists():
        assert read(path) == value, f"immutable record differs: {path}"
    else:
        api.grader.persist(path, value)


def anchors(phase="anchors"):
    """Certify (containment proof), admit, then 3 order-balanced repeats for all 7 cloud models."""
    alias, repeats = PHASES[phase]
    root = OWNED / alias
    root.mkdir(exist_ok=True)
    source_root = OWNED / __import__("os").environ.get("MB_SAFETY_ROOT", "mbr3-v13-safety")
    proof = {**read(source_root / "safety.json"), "condition": "MB-R3"}
    assert proof["passed"] and proof["source"] == native.sources()
    persist(root / "safety.json", proof)
    containment = read(source_root / "harbor-containment-proof.json")
    assert containment["passed"] and containment["source"] == proof["source"] and set(containment["tasks"]) == set(ANCHORS)
    persist(root / "harbor-containment-proof.json", containment)
    log = (root / "progress.log").open("a")
    admitted = []
    for task in (ANCHORS if phase == "anchors" else ("anchor-swepro-ansible", "anchor-swepro-qutebrowser")):
        exception = REPO / "benchmarks/michael/curriculum" / f"MBR3-{task}-admission-exception.json"
        if phase != "anchors":
            # Coordinator exception: reuse the original admission receipt, never re-admit.
            original = OWNED / PHASES["anchors"][0] / "admission" / task / "admission.json"
            value = read(exception)
            import hashlib
            assert value["exception"] == "public-anchor-as-is" and value["admissionReceiptSha256"] == \
                hashlib.sha256(original.read_bytes()).hexdigest()
            persist(root / "admission-exception.json", value)
            admitted.append(task)
            print("admission-exception", task, value["exception"], file=log, flush=True)
            continue
        where = root / "admission" / task
        admit.AUDITORS = (("claude-sonnet-5.5", "anthropic"), ("gpt-5.6-sol", "openai"))
        result = read(where / "admission.json") if (where / "admission.json").exists() else live.admission(
            OWNED, where, task, proof, active_seconds=policy(task)["activeSeconds"])
        print("admission", task, json.dumps(result["decision"])[:300], file=log, flush=True)
        if result["decision"]["state"] in ("admitted", "admitted_with_findings"):
            admitted.append(task)
    models = ("claude-sonnet-5.5", "mai-code-2") + MODELS
    schedule = []
    for repeat in repeats:
        for index, task in enumerate(admitted):
            shift = (index + repeat - 1) % len(models)
            schedule.append({"task": task, "repeat": repeat, "models": list(models[shift:] + models[:shift])})
    persist(root / "schedule.json", schedule)
    run_schedule(root, schedule, proof, log)


def run_schedule(root, schedule, proof, log):
    for item in schedule:
        name, repeat, order = item["task"], item["repeat"], item["models"]
        batch = root / "trials" / name / f"repeat-{repeat}"
        for model in order:
            run = batch / model
            if (run / "outcome.json").exists() or (run / "deferred-outcome.json").exists():
                continue
            if (batch / (model + ".json")).exists():
                print("spent-unfinished", name, repeat, model, file=log, flush=True)
                continue
            try:
                outcome = native.execute(OWNED, batch, name, model, order, proof, policy=policy(name),
                                         **({"defer": True} if DEFER else {}))
            except api.TrialError as error:
                print("slot-error", name, repeat, model, error, file=log, flush=True)
                continue
            print("subject", name, repeat, model, outcome["status"], round(outcome["elapsedSeconds"], 1),
                  outcome.get("counts"), file=log, flush=True)
    print("phase-complete", root.name, file=log, flush=True)


def main(phase):
    if phase in ("anchors", "anchors-exception"):
        return anchors(phase)
    alias, repeats = PHASES[phase]
    root = OWNED / alias
    root.mkdir(exist_ok=True)
    proof = read(OWNED / __import__("os").environ.get("MB_SAFETY_ROOT", "mbr3-models-safety-v11") / "safety.json")
    assert proof["passed"] and proof["source"] == native.sources(), "fresh current-source safety required"
    persist(root / "safety.json", proof)
    schedule = [{"task": name, "repeat": repeat, "models": rotated(index, repeat)}
                for repeat in repeats for index, name in enumerate(TASKS)]
    if phase == "screen12":
        # Remaining screen slots after the v11 driver was stopped at a slot boundary for the v12 epoch.
        done = OWNED / PHASES["screen"][0]
        schedule = [{**item, "models": [m for m in item["models"] if not
                     (done / "trials" / item["task"] / "repeat-1" / m / "outcome.json").exists()]}
                    for item in schedule]
        schedule = [item for item in schedule if item["models"]]
    if phase == "fill":
        # Sonnet/MAI ran round-1/2 tasks once (older epochs); bring them to 3 under the current epoch.
        for repeat in (2, 3):
            for index, name in enumerate(ROUND12):
                pair = list(EARLIER if (index + repeat) % 2 else reversed(EARLIER))
                schedule.append({"task": name, "repeat": repeat, "models": pair})
        # Disclosed reruns of screen slots that ended in a harness/environment fault.
        adjudicated = {(v["task"], v["model"]) for v in (read(c) for c in
                       (REPO / "benchmarks/michael/curriculum").glob("MBR3-*-task-adjudication.json"))}
        paths = [p for alias in (PHASES["screen"][0], PHASES["screen12"][0])
                 for p in sorted((OWNED / alias).glob("attribution/*/repeat-1/*/attribution.json"))]
        for path in paths:
            if read(path)["cause"] != "model" and (path.parts[-4], path.parts[-2]) not in adjudicated:
                schedule.append({"task": path.parts[-4], "repeat": 4, "models": [path.parts[-2]],
                                 "rerunOf": str(path.relative_to(OWNED))})
    persist(root / "schedule.json", schedule)
    log = (root / "progress.log").open("a")
    for item in schedule:
        name, repeat, order = item["task"], item["repeat"], item["models"]
        batch = root / "trials" / name / f"repeat-{repeat}"
        for model in order:
            run = batch / model
            if (run / "outcome.json").exists():
                outcome = read(run / "outcome.json")
            elif (run / "deferred-outcome.json").exists():
                continue
            elif (batch / (model + ".json")).exists():
                print("spent-unfinished", name, repeat, model, file=log, flush=True)
                continue
            else:
                try:
                    outcome = native.execute(OWNED, batch, name, model, order, proof, policy=policy(name),
                                             **({"defer": True} if DEFER else {}))
                except api.TrialError as error:
                    print("slot-error", name, repeat, model, error, file=log, flush=True)
                    continue
            print("subject", name, repeat, model, outcome["status"], round(outcome["elapsedSeconds"], 1),
                  outcome.get("counts"), file=log, flush=True)
            if outcome["status"] == "awaiting-deferred-verification":
                continue
            if outcome["status"] != "pass":
                where = root / "attribution" / name / f"repeat-{repeat}" / model
                if not (where / "attribution.json").exists():
                    admit.AUDITORS = JUDGES[FAMILY[model]]
                    try:
                        live.attribution(OWNED, where, name, run, proof)
                    except Exception as error:  # preserve the slot; attribution can be resumed
                        print("attribution-error", name, repeat, model, error, file=log, flush=True)
                        continue
                attribution = read(where / "attribution.json")
                print("nonpass", name, repeat, model, attribution["cause"], file=log, flush=True)
    rows = []
    for item in schedule:
        for position, model in enumerate(item["models"]):
            path = root / "trials" / item["task"] / f"repeat-{item['repeat']}" / model / "outcome.json"
            if path.exists():
                outcome = read(path)
                rows.append({"task": item["task"], "repeat": item["repeat"], "model": model, "order": position,
                             "resolved": outcome["status"] == "pass", "completion_seconds": outcome["completionSeconds"]})
    try:
        summary = metrics.repeated(rows)
    except (KeyError, ValueError, ZeroDivisionError, AssertionError) as error:
        summary = {"rows": rows, "summaryError": str(error)}
    (root / "repeated-summary.json").write_text(json.dumps(summary, sort_keys=True, indent=1))
    print("phase-complete", phase, len(rows), file=log, flush=True)


def finalize(phase, released_at_ms):
    """After the local window releases: grade deferred slots, then attribute non-passes."""
    alias, _ = PHASES[phase]
    root = OWNED / alias
    proof = read(root / "safety.json")
    log = (root / "progress.log").open("a")
    for item in read(root / "schedule.json"):
        batch = root / "trials" / item["task"] / f"repeat-{item['repeat']}"
        for model in item["models"]:
            run = batch / model
            if not (run / "deferred-outcome.json").exists():
                continue
            outcome = read(run / "outcome.json") if (run / "outcome.json").exists() else \
                native.finalize_deferred(batch, item["task"], model, released_at_ms=released_at_ms)
            print("graded", item["task"], item["repeat"], model, outcome["status"], outcome.get("counts"),
                  file=log, flush=True)
            where = root / "attribution" / item["task"] / f"repeat-{item['repeat']}" / model
            if outcome["status"] != "pass" and not (where / "attribution.json").exists():
                admit.AUDITORS = JUDGES[FAMILY.get(model, "openai")]
                try:
                    live.attribution(OWNED, where, item["task"], run, proof)
                except Exception as error:
                    print("attribution-error", item["task"], item["repeat"], model, error, file=log, flush=True)


if __name__ == "__main__":
    if sys.argv[1] == "finalize" and sys.argv[2] == "anchors":
        PHASES["anchors_finalize"] = PHASES["anchors"]
    if sys.argv[1] == "finalize":
        finalize(sys.argv[2], float(sys.argv[3]))
    else:
        main(sys.argv[1])
