"""Cloud v2: extend the immutable core archive with all round-three cloud cohorts, including MB-R3M models."""
import argparse
import copy
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile
import tempfile

from benchmarks.michael.matrix import generate

OWNED = Path("/Users/mvh/.copilot/session-state/a45ee9a4-394e-4af7-afba-d8f78ae19672/files/local-mxc")
HERE = Path(__file__).parent
DEST = generate.ROOT / "benchmarks/michael/curriculum"
PROOF = generate.ROOT / "benchmarks/michael/local_transport/mbr3-cloud-v2-verification.json"
ALLOWED = {"mbr3-expanded-v5", "mbr3-foal-v6", "mbr3-successors-v7c", "mbr3-gapfill-v8", "mbr3-anchors-v10",
           "mbr3-models-screen-v11", "mbr3-models-screen-v12b", "mbr3-models-fill-v12b", "mbr3-models-fill-v13"}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encode(value):
    return (json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n").encode()


def read(path):
    return json.loads(path.read_bytes())


def publish(aliases, *, verify_only=False):
    if not aliases or len(set(aliases)) != len(aliases) or not set(aliases) <= ALLOWED:
        raise ValueError("explicit, unique completed cloud aliases required")
    index = read(DEST / "MBR3-core-verification.json")
    archive_path = DEST / index["archiveFile"]
    assert sha(archive_path.read_bytes()) == index["archiveSha256"]
    members = {}
    with tarfile.open(archive_path, "r:gz") as archive:
        for member in archive:
            assert member.isfile() and member.name in index["members"] and member.name not in members
            raw = archive.extractfile(member).read()
            assert sha(raw) == index["members"][member.name]
            members[member.name] = raw
    assert set(members) == set(index["members"])
    plan = copy.deepcopy(json.loads(members[index["primaryPlanPath"]]))
    plan["cohortSchedules"] = [{"evidence_root": "mbr3-v1", "sha256": plan["scheduleSha256"]}]
    projections = list(index["nativeTerminalProjections"])
    expected_records = []

    def keep(path, alias=None):
        name = alias or path.relative_to(OWNED).as_posix()
        raw = path.read_bytes()
        assert name not in members or members[name] == raw
        members[name] = raw

    def terminal_projection(path):
        raw, value = path.read_bytes(), read(path)
        assert "localInference" not in value, "cloud publisher cannot silently admit a local condition"
        fields = ("stopReason", "activeSeconds", "partialBudgetExhausted", "finalSourceError",
                  "cleanupSeconds", "wholeProcessQuiescent", "actions", "actionBytes", "events",
                  "protocolBytes", "evidenceDiskBytesBeforeTerminal", "unparsedProtocolBytesLowerBound",
                  "requestedModel", "observedModel", "nativeStarts", "nativePrompts", "ownerRetries",
                  "taskOutputBytesBeforeCutoff", "taskOutputRetainedBytes", "replayedActions", "verdict", "scratch")
        projection = {key: value[key] for key in fields if key in value}
        projection["records"] = [{key: row[key] for key in ("kind", "id", "reaped", "warnings", "finishedMs")
                                  if key in row} for row in value["records"]]
        counters = ("model", "responseModel", "inputTokens", "outputTokens", "reasoningTokens",
                    "cacheReadTokens", "cacheWriteTokens")
        projection["usage"] = [{key: row[key] for key in counters if key in row}
                               for row in value["usage"]] if isinstance(value["usage"], list) else "unknown"
        projection.update(
            projection="Safe metadata allowlist; messages/requests/raw streams/account/quota/credit/provider IDs excluded.",
            rawTerminalSha256=sha(raw))
        name = path.relative_to(OWNED).as_posix()
        members[name] = encode(projection)
        projections.append({"path": name, "rawSha256": sha(raw), "projectionSha256": sha(members[name])})

    for alias in aliases:
        root = OWNED / alias
        safety_bytes, schedule_bytes = (root / "safety.json").read_bytes(), (root / "schedule.json").read_bytes()
        safety, schedule = json.loads(safety_bytes), json.loads(schedule_bytes)
        epoch = alias.removeprefix("mbr3-")
        assert safety["passed"] is True
        assert epoch not in plan["source_epochs"]
        selected = {(row["task"], row["repeat"], model) for row in schedule for model in row["models"]}
        assert len(selected) == sum(len(row["models"]) for row in schedule)
        excluded = []
        for task, repeat, model in sorted(selected):
            run = root / "trials" / task / f"repeat-{repeat}" / model
            attribution = root / "attribution" / task / f"repeat-{repeat}" / model / "attribution.json"
            if not (run / "outcome.json").exists():
                continue  # unfinished slot of a stopped driver: covered by a later cohort's schedule
            outcome = read(run / "outcome.json")
            if outcome["status"] == "pass":
                continue
            cause = read(attribution)["cause"] if attribution.is_file() else None
            resolved = any(json.loads(c.read_bytes()).get("evidence_root") == alias and
                           (json.loads(c.read_bytes()).get("task"), json.loads(c.read_bytes()).get("repeat"),
                            json.loads(c.read_bytes()).get("model")) == (task, repeat, model)
                           for c in DEST.glob("MBR3-*-resolution.json"))
            if outcome["status"] == "fail" and (cause == "model" or resolved):
                continue
            assert cause in ("harness", "task", "unresolved"), (task, repeat, model, cause)
            adjudication = None
            for candidate in DEST.glob("MBR3-*-task-adjudication.json"):
                value = json.loads(candidate.read_bytes())
                if (value.get("evidence_root"), value.get("task"), value.get("repeat"), value.get("model")) == (
                        alias, task, repeat, model):
                    adjudication = {"file": candidate.name, "sha256": sha(candidate.read_bytes())}
                    cause = "task"
            excluded.append({"task": task, "repeat": repeat, "model": model, "evidence_root": alias,
                             "outcomeSha256": sha((run / "outcome.json").read_bytes()),
                             "attributionSha256": sha(attribution.read_bytes()),
                             "failure_modes": {"harness": ["harness-error"], "task": ["task-caused"]}.get(
                                 cause, ["model-failure-unclassified"]),
                             "cutoff": outcome.get("nativeStop") or outcome.get("error") or cause,
                             "closesScheduledSlot": True, "pendingAdjudication": cause == "unresolved",
                             **({"taskAdjudication": adjudication} if adjudication else {})})
        done = {(t, r, m) for t, r, m in selected
                if (root / "trials" / t / f"repeat-{r}" / m / "outcome.json").exists()}
        keys = {(e["task"], e["repeat"], e["model"]) for e in excluded}
        selected = done - keys
        plan.setdefault("excluded_priors", []).extend(excluded)
        rows = generate.ledger_records(root, selected=selected)
        assert all(row["deployment_class"] == "cloud" for row in rows)
        expected_records.extend(rows)
        plan["cohortSchedules"].append({"evidence_root": alias, "sha256": sha(schedule_bytes),
                                        **({"continues": "mbr3-models-screen-v11"}
                                           if alias == "mbr3-models-screen-v12b" else {})})
        plan["source_epochs"][epoch] = {
            "ownerSha256": safety["source"]["benchmarks/michael/local_transport/owner.mjs"],
            "safetySha256": sha(safety_bytes)}
        plan["attempts"].extend({"task": t, "repeat": r, "model": m, "evidence_root": alias, "source_epoch": epoch}
                                for t, r, m in sorted(selected))
        keep(root / "safety.json")
        keep(root / "schedule.json")
        if (root / "repeated-summary.json").exists():
            keep(root / "repeated-summary.json")
        if alias == "mbr3-anchors-v10":
            containment = json.loads((root / "harbor-containment-proof.json").read_bytes())
            assert containment["passed"] and containment["source"] == safety["source"]
            keep(root / "harbor-containment-proof.json")
        snapshots = sorted(root.glob("trials/*/repeat-*/source-snapshot"))
        assert snapshots
        for relative, expected in safety["source"].items():
            path = snapshots[0] / relative
            assert sha(path.read_bytes()) == expected
            keep(path, alias + "/source-snapshot/" + relative)
        for item in schedule:
            batch = root / "trials" / item["task"] / f"repeat-{item['repeat']}"
            if (batch / "ledger.jsonl").exists():
                keep(batch / "ledger.jsonl")
            for model in item["models"]:
                run = batch / model
                if not (run / "outcome.json").exists():
                    continue
                terminal_projection(run / "receipt/terminal.json")
                for name in ("outcome.json", "collected-source.bin", "independent-grader/report.json"):
                    if name == "outcome.json" or (run / name).exists():
                        keep(run / name)
                attribution = root / "attribution" / item["task"] / f"repeat-{item['repeat']}" / model / "attribution.json"
                if attribution.is_file():
                    keep(attribution)
    if "mbr3-successors-v7c" in aliases:
        for name in ("MBR3-vhs-v2-scratch-harness-fault.json",
                     "MBR3-scratch-old-cap-proximity.json"):
            keep(DEST / name, "receipts/" + name)
        keep(generate.ROOT / "benchmarks/michael/local_transport/mbr3-scratch-parity-verification.json",
             "receipts/mbr3-scratch-parity-verification.json")
        old = OWNED / "mbr3-successors-v7"
        admission = old / "admission/vhs-room-registry-sync-v2"
        keep(old / "safety.json")
        keep(admission / "admission.json")
        keep(admission / "blind/ledger.jsonl")
        keep(admission / "blind/gemini-4-neon/outcome.json")
        terminal_projection(admission / "blind/gemini-4-neon/receipt/terminal.json")
        for audit_index in range(2):
            keep(admission / f"audit-{audit_index}/verdict.json")
    for name in ("run_mbr3_expanded_v5.py", "resume_expanded_resolved.py", "resolve_yv_repeat1.py",
                 "resume_expanded_resolved_v2.py", "resolve_yv_repeat3.py", "prove_harbor_containment.py",
                 "run_mbr3_followups.py", "publish_expanded_admissions.py", "publish_expanded_results.py",
                 "publish_foal_and_scratch_history.py", "publish_scratch_epoch.py",
                 "publish_mbr3_cloud.py"):
        keep(OWNED / name, "controllers/" + name)
    for name in ("run_mbr3m.py", "local_safety.py", "publish_cloud_v2.py", "local_tasks.json"):
        keep(HERE / name, "controllers/" + name)
    plan_path = "mbr3-cloud-v2/primary-plan.json"
    members[plan_path] = encode(plan)
    proof = {"schema_version": 1, "primaryPlan": plan,
             "role": "Complete cloud schedules, frozen native sources, and immutable core recovery selection"}
    buffer = io.BytesIO()
    with gzip.GzipFile(fileobj=buffer, mode="wb", mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w") as archive:
            for name, raw in sorted(members.items()):
                info = tarfile.TarInfo(name)
                info.mode, info.size, info.mtime = 0o600, len(raw), 0
                archive.addfile(info, io.BytesIO(raw))
    data = buffer.getvalue()
    archive_path = DEST / "MBR3-cloud-v2-evidence.tar.gz"
    verification = {
        "schema_version": 1, "archiveFile": archive_path.name, "archiveSha256": sha(data),
        "primaryPlanPath": plan_path, "localRunRoots": [],
        "members": {name: sha(raw) for name, raw in sorted(members.items())},
        "nativeTerminalProjections": projections, "logicalAttempts": len(plan["attempts"]),
        "physicalAttempts": len(plan["attempts"]) + len(plan["excluded_priors"]),
        "scope": index["scope"], "coreArchiveSha256": index["archiveSha256"]}
    index_path = DEST / "MBR3-cloud-v2-verification.json"
    with tempfile.TemporaryDirectory(prefix="mbr3-cloud-publish-", dir=OWNED) as directory:
        staging = Path(directory)
        staged_repository = staging / "repository"
        staged_proof = staged_repository / PROOF.relative_to(generate.ROOT)
        staged_proof.parent.mkdir(parents=True)
        staged_proof.write_bytes(encode(proof))
        if "paritySweepSha256" in plan:
            sweep = PROOF.with_name("mbr3-discovery-parity.json")
            staged_proof.with_name(sweep.name).write_bytes(sweep.read_bytes())
        staged_curriculum = staged_repository / DEST.relative_to(generate.ROOT)
        staged_curriculum.mkdir(parents=True)
        (staged_curriculum / archive_path.name).write_bytes(data)
        staged_index = staged_curriculum / index_path.name
        staged_index.write_bytes(encode(verification))
        for resolution in [*DEST.glob("MBR3-*-resolution.json"), *DEST.glob("MBR3-*-task-adjudication.json")]:
            (staged_curriculum / resolution.name).write_bytes(resolution.read_bytes())
        original_repository = generate.ROOT
        try:
            generate.ROOT = staged_repository
            records, _ = generate.sealed_epoch_records(staged_index)
        finally:
            generate.ROOT = original_repository
    core, _ = generate.sealed_epoch_records(DEST / "MBR3-core-verification.json")
    assert len(records) == len(core) + len(expected_records)
    actual = {(row["task"], row["repeat"], row["model"]): row for row in records}
    for row in expected_records:
        projected = {**row, "condition": row["condition"] + "/" + next(
            item["source_epoch"] for item in plan["attempts"] if
            (item["task"], item["repeat"], item["model"]) == (row["task"], row["repeat"], row["model"]))}
        assert actual[row["task"], row["repeat"], row["model"]] == projected
    if verify_only:
        print("verified staged cloud records", len(records), "members", len(members),
              "archive bytes", len(data), "public files written", 0)
        return
    outputs = ((archive_path, data), (index_path, encode(verification)), (PROOF, encode(proof)))
    for path, raw in outputs:
        if path.exists():
            assert path.read_bytes() == raw, "sealed cloud evidence differs"
    for path, raw in outputs:
        if not path.exists():
            with path.open("xb") as target:
                target.write(raw)
    print("verified sealed cloud records", len(records), "members", len(members), "archive bytes", len(data))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cohort", action="append", required=True, choices=sorted(ALLOWED))
    parser.add_argument("--verify-only", action="store_true",
                        help="validate completed staged cohorts without publishing a final cloud archive")
    args = parser.parse_args()
    publish(args.cohort, verify_only=args.verify_only)
