"""Nine-package native calibration, fresh admission, then exclusive balanced repeats."""
import json
from pathlib import Path
import runpy
import sys
import yaml

OWNED = Path(__file__).parent
ROOT = OWNED / "mbr3-expanded-v5"
REQUESTED_TASKS = (
    "design-alethiometer-case-v4", "kerrigan-plan-conflict-queue-v4", "yv-relevance-instrument-v4",
    "kirkland-compose-adoption", "vhs-room-registry-sync", "te-baseline-eval",
    "design-alethiometer-gear-mesh", "cs-mismatch-stage-authority", "foal-meadow-regression-review",
)
TASKS = tuple(task for task in REQUESTED_TASKS if task != "foal-meadow-regression-review")
driver = runpy.run_path(str(OWNED / "run_mbr3.py"), run_name="trusted_driver")
api, native, live, metrics = (driver[key] for key in ("api", "native", "live", "metrics"))
MODELS, read = driver["MODELS"], driver["read"]


def persist(path, value):
    if path.exists():
        assert read(path) == value, "expanded immutable record differs"
    else:
        api.grader.persist(path, value)


def safety():
    assert set(REQUESTED_TASKS) <= set(native.NAMES), "merge f8662c6 or later first"
    name = "foal-meadow-regression-review"
    files, policy, _ = native.material(name)
    oversized = {path: len(data) for path, data in files.items()
                 if path in policy["write"] and len(data) > policy["bytes"]}
    assert oversized == {"foal-rescue-meadow.html": 35505, "index.html": 36330}
    fit = {
        "schema_version": 1, "kind": "native-package-fit", "task": name,
        "state": "needs_native_fit_successor", "modelPrompts": 0, "nativeProcessesStarted": 0,
        "fileLimitBytes": policy["bytes"], "oversizedBaseWritableFiles": oversized,
        "referenceWritableSizes": {path: len(data) for path, data in
                                   native.specs.unbundle(name, native.specs.reference(name)).items()},
        "task": name, "manifestSha256": api.sha((native.tasks.HERE / name / "manifest.json").read_bytes()),
        "decision": "No silent native-limit widening. Continue the other eight packages and request a bounded semantics-preserving successor or an explicit new condition.",
    }
    ROOT.mkdir(exist_ok=True)
    persist(ROOT / "native-fit.json", fit)
    persist(native.tasks.HERE.parent / "curriculum/MBR3-foal-meadow-regression-review-native-fit.json", fit)
    driver["safety"].__globals__.update(ROOT=ROOT, TASKS=TASKS)
    return driver["safety"]()


def admit():
    proof = read(ROOT / "safety.json")
    assert proof["source"] == native.sources()
    for task in TASKS:
        root = ROOT / "admission" / task
        path = root / "admission.json"
        result = read(path) if path.exists() else live.admission(
            OWNED, root, task, proof, active_seconds=driver["policy"](task)["activeSeconds"])
        print("admission", task, result["decision"], flush=True)


def trials():
    proof = read(ROOT / "safety.json")
    assert proof["source"] == native.sources()
    admitted = [task for task in TASKS if read(ROOT / "admission" / task / "admission.json")[
        "decision"]["state"] in ("admitted", "admitted_with_findings")]
    schedule = []
    for repeat in range(1, 4):
        for index, task in enumerate(admitted):
            order = list(MODELS if (index + repeat - 1) % 2 == 0 else reversed(MODELS))
            schedule.append({"task": task, "repeat": repeat, "models": order})
    persist(ROOT / "schedule.json", schedule)
    for item in schedule:
        task, repeat, models = item["task"], item["repeat"], item["models"]
        batch = ROOT / "trials" / task / f"repeat-{repeat}"
        for model in models:
            run = batch / model
            outcome = read(run / "outcome.json") if (run / "outcome.json").exists() else native.execute(
                OWNED, batch, task, model, models, proof, policy=driver["policy"](task))
            assert outcome["quiescent"]
            print("subject", task, repeat, model, outcome["status"],
                  outcome["elapsedSeconds"], outcome.get("counts"), flush=True)
            if outcome["status"] != "pass":
                where = ROOT / "attribution" / task / f"repeat-{repeat}" / model
                if not (where / "attribution.json").exists():
                    live.attribution(OWNED, where, task, run, proof)
                attribution = read(where / "attribution.json")
                print("nonpass", task, repeat, model, attribution["cause"], flush=True)
                if attribution["cause"] != "model":
                    raise RuntimeError("New non-model cause; retain slot without automatic retry")
    rows = []
    for item in schedule:
        for position, model in enumerate(item["models"]):
            outcome = read(ROOT / "trials" / item["task"] / f"repeat-{item['repeat']}" /
                           model / "outcome.json")
            rows.append({"task": item["task"], "repeat": item["repeat"], "model": model,
                         "order": position, "resolved": outcome["status"] == "pass",
                         "completion_seconds": outcome["completionSeconds"],
                         "source_epoch": "expanded-v5", "evidence_root": ROOT.name})
    persist(ROOT / "repeated-summary.json", metrics.repeated(rows))


if __name__ == "__main__":
    command = sys.argv[1]
    if command == "safety":
        safety()
    elif command == "admit":
        admit()
    elif command == "trials":
        trials()
    elif command == "all":
        safety()
        admit()
        trials()
    else:
        raise ValueError("unknown expanded command")
