"""Preserve the old blind fault and certify the uniform forward scratch policy."""
import json
from pathlib import Path

from benchmarks.michael.curriculum import automation
from benchmarks.michael.replay_trial import api, curriculum as native

OWNED = Path(__file__).parent
REPO = api.packages.ROOT
OLD = OWNED / "mbr3-successors-v7"
NEW = OWNED / "mbr3-successors-v7c"
TASK = "vhs-room-registry-sync-v2"
root = OLD / "admission" / TASK
blind = root / "blind/gemini-4-neon"
read = lambda path: json.loads(path.read_bytes())
sha = lambda path: api.sha(path.read_bytes())


def persist(path, value):
    if path.exists():
        assert read(path) == value, "immutable recovery receipt differs"
    else:
        api.grader.persist(path, value)


outcome, terminal = read(blind / "outcome.json"), read(blind / "receipt/terminal.json")
assert outcome["status"] == "ungraded" and terminal["stopReason"] == "scratch:scratch_byte_budget"
assert terminal["wholeProcessQuiescent"] and terminal["cleanupSeconds"] <= 15
assert terminal["scratch"]["cleanup"] == {"discarded": True}
audits = [read(root / f"audit-{index}/verdict.json")["verdict"] for index in range(2)]
decision = automation.admission(oracle_passes=True, base_fails=True, audits=audits,
                                 blind=[{"passed": False, "adjudication": None}])
assert decision["state"] == "provisional"
persist(root / "admission.json", {
    "task": TASK, "audits": audits, "blind": {"passed": False, "adjudication": None},
    "blindOutcome": outcome, "decision": decision,
    "aggregationRecovery": "Original None.get exception retained in controller history; "
                           "this is the fixed aggregator's provisional result, not a retroactive admission.",
    "aggregatorSha256": sha(Path(automation.__file__))})
fault = {
    "schema_version": 1, "kind": "native-admission-harness-fault",
    "task": TASK, "evidence_root": OLD.name, "source_epoch": "successors-v7",
    "cause": "harness", "counts_as_model_failure": False, "blindVerdict": "ungraded",
    "decisionSource": {"kind": "coordinator-instruction",
        "session": "ba383ac7-f3a0-4cbd-aff3-291f26881ccb",
        "sourceToolCallId": "toolu_016zuzS9QTpBHtKUEHYXTuZR"},
    "reason": "The original 1MiB/128-entry scratch condition cut off ordinary API-tree copies "
              "for peer self-tests; stock CLI has no equivalent cap.",
    "originalOutcomeSha256": sha(blind / "outcome.json"),
    "originalRawTerminalSha256": sha(blind / "receipt/terminal.json"),
    "originalLedgerSha256": sha(root / "blind/ledger.jsonl"),
    "originalSafetySha256": sha(OLD / "safety.json"),
    "originalAudits": [{"verdictSha256": sha(root / f"audit-{index}/verdict.json"),
                       "requestSha256": sha(root / f"audit-{index}/request.json")} for index in range(2)],
    "nativeScratch": terminal["scratch"], "wholeProcessQuiescent": True,
    "cleanupSeconds": terminal["cleanupSeconds"],
    "measurementLimit": "The rejected scan's exact size is unknown; peakBytes records only successful scans.",
    "selectedScoredSubjectsAffected": 0, "freshAdjudicationCalls": 0,
    "replacement": {"evidence_root": NEW.name, "blindSlotsAllowed": 1,
        "disclosure": "Fresh admission under the new uniform policy, including one fresh blind slot; "
                      "old audits/slot/ledger remain untouched."},
    "newPolicyEpoch": "scratch-parity-v7c",
    "newLimits": {"directory": ".scratch", "bytes": 67108864, "entries": 4096},
    "unchanged": ["final-artifact allowlists", "file/channel/action limits", "process/network denial",
                  "alias rejection", "15-second cleanup bound", "post-quiescence scratch disposal"]}
persist(REPO / "benchmarks/michael/curriculum/MBR3-vhs-v2-scratch-harness-fault.json", fault)

safety = read(NEW / "safety.json")
assert safety["passed"] and safety["source"] == native.sources()
proofs = []
for path in sorted((OWNED / "scratch-parity-native-v7c").glob("**/receipt/terminal.json")):
    value = read(path)
    assert value["wholeProcessQuiescent"] and value["cleanupSeconds"] <= 15 and value["nativePrompts"] == 0
    assert all(row["reaped"] and not row["warnings"] for row in value["records"])
    proofs.append({"path": path.relative_to(OWNED).as_posix(), "rawTerminalSha256": sha(path),
                   "cleanupSeconds": value["cleanupSeconds"], "wholeProcessQuiescent": True})
assert proofs
persist(REPO / "benchmarks/michael/local_transport/mbr3-scratch-parity-verification.json", {
    "schema_version": 1, "kind": "native-scratch-policy-recertification",
    "policyEpoch": "scratch-parity-v7c", "passed": True, "environment": "local-attested-macos",
    "source": native.sources(), "limits": fault["newLimits"],
    "nativeRegression": "77 passed, 50 package calibrations deselected",
    "coverage": ["real API-tree copies exceed both former limits and complete",
                 "actual native cutoff above 64MiB logical scratch bytes",
                 "actual native cutoff above 4096 entries", "existing alias/special-file denial",
                 "quiescent cleanup/disposal", "every round-three prompt advertises the same scratch policy",
                 "explicit null or absent adjudication returns provisional"],
    "fixtureCorrection": "First positive fixture copied only 556209 bytes and missed its own old-cap "
                         "threshold assertion; corrected copy count derives from actual API-tree size. "
                         "No subject or admission ran during recertification.",
    "promptAlignment": "Scratch broker-write text now follows each package's effective file cap "
                       "(foal has 131072, defaults 32768); scratch persists across tool actions. "
                       "The earlier v7b calibration was offline-only and remains preserved.",
    "modelPrompts": 0, "operationalLocalEndpointContacted": False, "nativeTerminals": proofs,
    "successorSafetySha256": sha(NEW / "safety.json"),
    "priorScratchProximitySha256": sha(REPO / "benchmarks/michael/curriculum/MBR3-scratch-old-cap-proximity.json"),
    "blindFaultSha256": sha(REPO / "benchmarks/michael/curriculum/MBR3-vhs-v2-scratch-harness-fault.json")})
print(json.dumps({"faultRetained": True, "freshBlindAllowance": 1, "nativeReceipts": len(proofs),
                  "newSourceEpoch": "successors-v7c", "policyEpoch": "scratch-parity-v7c"}))
