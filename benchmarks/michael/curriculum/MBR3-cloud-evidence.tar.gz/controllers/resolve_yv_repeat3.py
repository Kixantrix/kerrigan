"""Apply the standing grammar ruling only after exact failed-observation comparison."""
import hashlib
import json
from pathlib import Path

OWNED = Path(__file__).parent
REPO = Path.cwd()
ROOT = OWNED / "mbr3-expanded-v5"
TASK = "yv-relevance-instrument-v4"
RUN = ROOT / "trials" / TASK / "repeat-3/mai-code-2"
PANEL = ROOT / "attribution" / TASK / "repeat-3/mai-code-2/attribution.json"
PRIOR = REPO / "benchmarks/michael/curriculum/MBR3-yv-v4-repeat1-resolution.json"
DEST = PRIOR.with_name("MBR3-yv-v4-repeat3-resolution.json")
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()

assert json.loads(PANEL.read_bytes())["cause"] == "unresolved"
outcome = json.loads((RUN / "outcome.json").read_bytes())
assert outcome["status"] == "fail" and outcome["quiescent"]
assert outcome["counts"] == {"audit": {"passed": 3, "total": 5},
                             "blind": {"passed": 6, "total": 6}, "score": {"passed": 5, "total": 5}}
report = json.loads((RUN / "independent-grader/report.json").read_bytes())
original = json.loads((ROOT / "trials" / TASK / "repeat-1/mai-code-2/independent-grader/report.json").read_bytes())
assert [row for row in report["assertions"] if not row["passed"]] == [
    row for row in original["assertions"] if not row["passed"]]
assert "topics.some(" in json.loads((RUN / "collected-source.bin").read_bytes())["evals/relevance/audit.ts"]
receipt = json.loads(PRIOR.read_bytes())
assert receipt["specSha256"] == sha(REPO / "benchmarks/michael/tasks" / TASK / "agent/evals/relevance/SPEC.md")
receipt.update(
    repeat=3, originalPanelSha256=sha(PANEL), outcomeSha256=sha(RUN / "outcome.json"),
    collectedArtifactsSha256=sha(RUN / "collected-source.bin"),
    graderReportSha256=sha(RUN / "independent-grader/report.json"),
    priorResolutionSha256=sha(PRIOR),
    decision="Apply the standing coordinator grammar adjudication to the identical failed clauses and observations in MAI repeat 3; retain its split panel and failed 14/16 result without rerun.",
)
data = (json.dumps(receipt, sort_keys=True, indent=2) + "\n").encode()
if DEST.exists():
    assert DEST.read_bytes() == data
else:
    with DEST.open("xb") as target:
        target.write(data)
print(sha(DEST))
