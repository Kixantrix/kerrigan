"""Use the proven repeated-trial controller for the next explicitly queued cohorts."""
from pathlib import Path
import importlib.util
import runpy
import sys

OWNED = Path(__file__).parent
COHORTS = {
    "foal": ("mbr3-foal-v6", ("foal-meadow-regression-review-v2",)),
    "successors": ("mbr3-successors-v7c", (
        "vhs-room-registry-sync-v2", "cs-mismatch-stage-authority-v2")),
    "gapfill": ("mbr3-gapfill-v8", (
        "research-admin-auth-choice", "research-cs-speech-stack",
        "plan-dashboard-decomposition", "plan-custom-action-briefing",
        "orchestrate-dashboard-stages", "orchestrate-sl-sim-phase-one")),
    "anchors": ("mbr3-anchors-v10", (
        "anchor-tb-fix-git", "anchor-tb-nginx-request-logging",
        "anchor-swepro-ansible", "anchor-swepro-openlibrary",
        "anchor-swepro-qutebrowser", "anchor-swepro-element-web",
        "anchor-swepro-tutanota")),
}


def balanced_schedule(tasks, models):
    return [{"task": task, "repeat": repeat, "models": list(
        models if (index + repeat - 1) % 2 == 0 else reversed(models))}
        for repeat in range(1, 4) for index, task in enumerate(tasks)]


def anchor_safety(context, root, tasks):
    native, read = context["native"], context["read"]
    root.mkdir(exist_ok=True)
    for task in tasks:
        retained = read(native.tasks.directory(task) / "calibration.json")
        for label, data in (("base", native.specs.base(task)), ("reference", native.specs.reference(task))):
            folder = root / "calibration" / task / label
            report = native.offline(OWNED, folder, task, data, policy=context["driver"]["policy"](task))
            phase = next(row for row in retained["phases"]
                         if row["phase"] == ("baseline" if label == "base" else label))
            assert report["counts"] == phase["counts"] and report["cleanup"]["proven"]
            print("calibrated", task, label, report["counts"], flush=True)
    specification = importlib.util.spec_from_file_location("checks",
        native.api.packages.ROOT / "tests/projects/michael_bench/test_curriculum_native.py")
    checks = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(checks)
    for name in ("validator", "grouping"):
        folder = root / ("scratch-proof-" + name)
        folder.mkdir()
        checks.test_round_three_tmpdir_write_run_cleanup_and_denial(OWNED, folder, name)
    context["persist"](root / "safety.json", {
        "passed": True, "condition": "MB-R3", "source": native.sources(),
        "calibration": str(root / "calibration"), "attester": "authorized-local-executor",
        "nativePrompts": 0, "classes": ["exact native calibration and Docker reference/base",
            "actual Node/Python sandbox scratch, denial/no-fork and disposal"],
        "subjectTargets": list(context["MODELS"]), "taskList": list(tasks),
        "harborContainmentProofRequiredBeforeSubjects": True})


def trials(context, root, alias, tasks):
    native, live, read = (context[key] for key in ("native", "live", "read"))
    proof = read(root / "safety.json")
    assert proof["source"] == native.sources()
    admitted = [task for task in tasks if read(root / "admission" / task / "admission.json")[
        "decision"]["state"] in ("admitted", "admitted_with_findings")]
    schedule = balanced_schedule(admitted, context["MODELS"])
    context["persist"](root / "schedule.json", schedule)
    for item in schedule:
        task, repeat, models = item["task"], item["repeat"], item["models"]
        batch = root / "trials" / task / f"repeat-{repeat}"
        for model in models:
            run = batch / model
            outcome = read(run / "outcome.json") if (run / "outcome.json").exists() else native.execute(
                OWNED, batch, task, model, models, proof, policy=context["driver"]["policy"](task))
            assert outcome["quiescent"]
            print("subject", task, repeat, model, outcome["status"],
                  outcome["elapsedSeconds"], outcome.get("counts"), flush=True)
            if outcome["status"] != "pass":
                where = root / "attribution" / task / f"repeat-{repeat}" / model
                if not (where / "attribution.json").exists():
                    live.attribution(OWNED, where, task, run, proof)
                attribution = read(where / "attribution.json")
                print("nonpass", task, repeat, model, attribution["cause"], flush=True)
                if attribution["cause"] != "model":
                    raise RuntimeError("New non-model cause; retain slot without automatic retry")
    rows = []
    for item in schedule:
        for position, model in enumerate(item["models"]):
            outcome = read(root / "trials" / item["task"] / f"repeat-{item['repeat']}" /
                           model / "outcome.json")
            rows.append({"task": item["task"], "repeat": item["repeat"], "model": model,
                         "order": position, "resolved": outcome["status"] == "pass",
                         "completion_seconds": outcome["completionSeconds"],
                         "source_epoch": alias.removeprefix("mbr3-"), "evidence_root": alias})
    context["persist"](root / "repeated-summary.json", context["metrics"].repeated(rows))


def fit_receipt(context, root, name):
    native, api, read = (context[key] for key in ("native", "api", "read"))
    files, policy, _ = native.material(name)
    declared = read(native.tasks.HERE / name / "native-policy.json")
    reference = native.specs.unbundle(name, native.specs.reference(name))
    inventories = {"base": {path: len(files[path]) for path in reference},
                   "reference": {path: len(data) for path, data in reference.items()}}
    largest = max(size for table in inventories.values() for size in table.values())
    assert policy["bytes"] >= largest * 2
    assert policy["channel"] >= policy["bytes"]
    assert policy["finalOutputReserve"] == policy["bytes"] * len(reference)
    assert policy["outputAggregate"] > policy["finalOutputReserve"]
    for path, data in reference.items():
        assert len(api.packages.encoded({"op": "write", "path": path, "data": data.decode()})) <= policy["payload"]
    calibrations = {}
    for label in ("base", "reference"):
        folder = root / "calibration" / name / label
        terminal_path, report_path = folder / "receipt/terminal.json", folder / "independent-grader/report.json"
        terminal, report = read(terminal_path), read(report_path)
        assert terminal["wholeProcessQuiescent"] and terminal["nativePrompts"] == 0
        assert terminal["cleanupSeconds"] <= 15 and report["cleanup"]["proven"]
        passed = sum(row["passed"] for row in report["counts"].values())
        total = sum(row["total"] for row in report["counts"].values())
        assert report["status"] == "graded" and total > 0
        assert passed < total if label == "base" else passed == total
        calibrations[label] = {"counts": report["counts"], "nativePrompts": 0,
                               "terminalSha256": api.sha(terminal_path.read_bytes()),
                               "reportSha256": api.sha(report_path.read_bytes()),
                               "exactArtifactRoundTrip": True}
    receipt = {
        "schema_version": 1, "kind": "native-package-fit", "task": name, "state": "native_fit_verified",
        "writableSizes": inventories, "largestWritableBytes": largest,
        "declaredNativePolicy": declared,
        "effectiveLimits": {key: policy[key] for key in native.tasks.NATIVE_LIMITS},
        "finalReserveDerivation": "Existing collector reserves file cap times artifact count; not a shared-default change.",
        "source": native.sources(), "safetyReceiptSha256": api.sha((root / "safety.json").read_bytes()),
        "calibrations": calibrations,
        "scope": "Native answer-free diagnostics and exact whole-file collection followed by independent Docker calibration; no model prompts.",
    }
    destination = native.tasks.HERE.parent / "curriculum" / f"MBR3-{name}-native-fit.json"
    if destination.exists():
        assert read(destination) == receipt, "sealed native-fit receipt differs"
    else:
        api.grader.persist(destination, receipt)
    return receipt


def main(cohort, command):
    alias, tasks = COHORTS[cohort]
    root = OWNED / alias
    template = runpy.run_path(str(OWNED / "run_mbr3_expanded_v5.py"), run_name="trusted_template")
    context = template["admit"].__globals__
    context.update(ROOT=root, TASKS=tasks, REQUESTED_TASKS=tasks)
    assert set(tasks) <= set(context["native"].NAMES), "merge parent f8857a9 or later after the current cohort completes"
    safety = context["driver"]["safety"]
    safety.__globals__.update(ROOT=root, TASKS=tasks)
    if command in ("safety", "all"):
        if cohort == "anchors":
            anchor_safety(context, root, tasks)
        else:
            safety()
        if cohort == "foal":
            fit_receipt(context, root, tasks[0])
    if cohort == "anchors" and command in ("admit", "trials", "all"):
        proof = context["read"](root / "harbor-containment-proof.json")
        assert proof["passed"] is True and proof["source"] == context["native"].sources()
        assert set(proof["tasks"]) == set(tasks), "fresh containment proof must cover both anchor images"
    if command in ("admit", "all"):
        template["admit"]()
    if command in ("trials", "all"):
        trials(context, root, alias, tasks)
    if command not in ("safety", "admit", "trials", "all"):
        raise ValueError("unrecognized follow-up command")


if __name__ == "__main__":
    main(*sys.argv[1:])
