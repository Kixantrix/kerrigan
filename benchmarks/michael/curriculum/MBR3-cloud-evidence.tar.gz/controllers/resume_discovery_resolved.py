"""Apply the hash-bound adjudication in memory; retain the original split panel."""
import hashlib
import json
from pathlib import Path
import runpy
import sys
import yaml

OWNED = Path(__file__).parent
REPO = Path("/Users/mvh/.copilot/repos/copilot-worktrees/kerrigan/kixantrix-redesigned-barnacle")
sys.argv = ["run_mbr3_discovery_v4.py", "plan"]
namespace = runpy.run_path(str(OWNED / "run_mbr3_discovery_v4.py"), run_name="trusted_driver")
read = namespace["read"]
root = OWNED / "mbr3-discovery-v4"
panel = root / "attribution/orchestrate-voice-integration-v5/repeat-2/mai-code-2/attribution.json"
resolution_path = REPO / "benchmarks/michael/curriculum/MBR3-orchestrate-v5-repeat2-resolution.json"
resolution = read(resolution_path)
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
run = root / "trials/orchestrate-voice-integration-v5/repeat-2/mai-code-2"
assert resolution["originalPanelSha256"] == sha(panel)
assert resolution["outcomeSha256"] == sha(run / "outcome.json")
assert resolution["collectedArtifactsSha256"] == sha(run / "collected-source.bin")
assert resolution["graderReportSha256"] == sha(run / "independent-grader/report.json")
assert resolution["cause"] == "model" and resolution["subject_rerun"] is False


def resolved_read(path):
    value = read(path)
    if path == panel:
        assert value["cause"] == "unresolved"
        return {**value, "cause": "model", "counts_as_model_failure": True,
                "action": "record_model_result", "deterministicResolutionSha256": sha(resolution_path)}
    return value


trials = namespace["driver"]["trials"]
trials.__globals__["read"] = resolved_read
trials()
