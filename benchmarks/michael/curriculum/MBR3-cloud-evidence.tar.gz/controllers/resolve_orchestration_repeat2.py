"""Publish the confirmed deterministic resolution without changing sealed evidence."""
import hashlib
import json
from pathlib import Path

OWNED = Path(__file__).parent
REPO = Path("/Users/mvh/.copilot/repos/copilot-worktrees/kerrigan/kixantrix-redesigned-barnacle")
TASK = "orchestrate-voice-integration-v5"
ROOT = OWNED / "mbr3-discovery-v4"
RUN = ROOT / "trials" / TASK / "repeat-2" / "mai-code-2"
PANEL = ROOT / "attribution" / TASK / "repeat-2" / "mai-code-2" / "attribution.json"
DEST = REPO / "benchmarks/michael/curriculum/MBR3-orchestrate-v5-repeat2-resolution.json"
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()

assert json.loads(PANEL.read_bytes())["cause"] == "unresolved"
outcome = json.loads((RUN / "outcome.json").read_bytes())
assert outcome["status"] == "fail" and outcome["quiescent"]
assert outcome["counts"]["ledger"] == {"passed": 6, "total": 7}
receipt = {
    "schema_version": 1, "kind": "deterministic-attribution-resolution",
    "task": TASK, "model": "mai-code-2", "repeat": 2, "source_epoch": "discovery-parity-v4",
    "evidence_root": ROOT.name, "cause": "model", "counts_as_model_failure": True,
    "failure_modes": ["unsupported-defect-claim"], "subject_rerun": False,
    "originalPanelSha256": sha(PANEL), "outcomeSha256": sha(RUN / "outcome.json"),
    "collectedArtifactsSha256": sha(RUN / "collected-source.bin"),
    "graderReportSha256": sha(RUN / "independent-grader/report.json"),
    "baseServerSha256": sha(REPO / "benchmarks/michael/tasks" / TASK / "agent/src/server.ts"),
    "decision": "Coordinator-confirmed deterministic adjudication; preserve the split panel and failed 17/18 result without rerun.",
    "evidence": [
        "The landed join handler rejects unknown tokens before creating any authenticated session.",
        "A failed rejoin retains only the earlier authenticated session; the connection did not acquire unauthenticated authority.",
        "R1-R8 do not require revocation of a previously authenticated session on rejected rejoin.",
        "Deleting the old session changes an unspecified recovery behavior; it does not demonstrate the claimed auth-bypass defect.",
        "The candidate lists auth-bypass. All functional and preservation checks pass; the deterministic ledger rejects this unsupported defect claim.",
    ],
    "publicationScope": "Sanitized attribution and immutable hashes only; original panel, model streams and artifacts remain unchanged.",
}
data = (json.dumps(receipt, sort_keys=True, indent=2) + "\n").encode()
if DEST.exists():
    assert DEST.read_bytes() == data
else:
    with DEST.open("xb") as target:
        target.write(data)
print(sha(DEST))
