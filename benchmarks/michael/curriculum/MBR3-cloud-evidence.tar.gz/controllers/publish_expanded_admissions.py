"""Safe completed-admission projections; never reads task streams or credential state."""
import argparse
import hashlib
import json
from pathlib import Path

OWNED = Path(__file__).parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--cohort", default="mbr3-expanded-v5", choices=(
    "mbr3-expanded-v5", "mbr3-foal-v6", "mbr3-successors-v7c",
    "mbr3-gapfill-v8", "mbr3-anchors-v10"))
ROOT = OWNED / parser.parse_args().cohort
DESTINATION = Path.cwd() / "benchmarks/michael/curriculum"
FIELDS = ("status", "model", "counts", "conditionSha256", "sourceSha256",
          "activeSeconds", "cleanupSeconds", "completionSeconds", "elapsedSeconds",
          "quiescent", "nativePrompts", "nativeStarts", "nativeStop")


def sha(data):
    return hashlib.sha256(data).hexdigest()


for path in sorted((ROOT / "admission").glob("*/admission.json")):
    raw = path.read_bytes()
    receipt = json.loads(raw)
    task = path.parent.name
    assert receipt["task"] == task
    assert receipt["decision"]["state"] in ("needs_fix", "admitted", "admitted_with_findings")
    projection = {
        "schema_version": 1, "kind": "native-admission-projection", "task": task,
        "sourceReceiptSha256": sha(raw),
        "safetyReceiptSha256": sha((ROOT / "safety.json").read_bytes()),
        "audits": [{"admit": audit["admit"], "findings": [
            {key: finding[key] for key in ("kind", "citation", "description")}
            for finding in audit["findings"]]} for audit in receipt["audits"]],
        "decision": receipt["decision"], "blind": {"passed": receipt["blind"]["passed"]},
        "blindOutcome": {key: receipt["blindOutcome"][key] for key in FIELDS
                         if key in receipt["blindOutcome"]},
        "publicationScope": "Admission judgments and native outcome metadata only; prompts, raw streams, HTTP bodies, configuration and credential state excluded.",
    }
    if "prelaunchRecovery" in receipt:
        assert isinstance(receipt["prelaunchRecovery"], str)
        projection["prelaunchRecovery"] = receipt["prelaunchRecovery"]
    data = (json.dumps(projection, sort_keys=True, separators=(",", ":")) + "\n").encode()
    target = DESTINATION / f"MBR3-{task}-admission.json"
    if target.exists():
        assert target.read_bytes() == data, "sealed projection differs"
    else:
        with target.open("xb") as output:
            output.write(data)
    print(task, projection["decision"]["state"], sha(data))
