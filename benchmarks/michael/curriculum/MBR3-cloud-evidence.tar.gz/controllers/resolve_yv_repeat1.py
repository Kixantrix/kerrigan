"""Preserve the split panel and bind the coordinator's explicit grammar adjudication."""
import hashlib
import json
from pathlib import Path

OWNED = Path(__file__).parent
REPO = Path.cwd()
TASK = "yv-relevance-instrument-v4"
ROOT = OWNED / "mbr3-expanded-v5"
RUN = ROOT / "trials" / TASK / "repeat-1/mai-code-2"
PANEL = ROOT / "attribution" / TASK / "repeat-1/mai-code-2/attribution.json"
SPEC = REPO / "benchmarks/michael/tasks" / TASK / "agent/evals/relevance/SPEC.md"
DEST = REPO / "benchmarks/michael/curriculum/MBR3-yv-v4-repeat1-resolution.json"
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()

assert json.loads(PANEL.read_bytes())["cause"] == "unresolved"
outcome = json.loads((RUN / "outcome.json").read_bytes())
assert outcome["status"] == "fail" and outcome["quiescent"]
assert outcome["counts"] == {"audit": {"passed": 3, "total": 5},
                             "blind": {"passed": 6, "total": 6}, "score": {"passed": 5, "total": 5}}
receipt = {
    "schema_version": 1, "kind": "deterministic-attribution-resolution",
    "task": TASK, "model": "mai-code-2", "repeat": 1, "source_epoch": "expanded-v5",
    "evidence_root": ROOT.name, "cause": "model", "counts_as_model_failure": True,
    "failure_modes": ["spec-misread"], "subject_rerun": False,
    "originalPanelSha256": sha(PANEL), "outcomeSha256": sha(RUN / "outcome.json"),
    "collectedArtifactsSha256": sha(RUN / "collected-source.bin"),
    "graderReportSha256": sha(RUN / "independent-grader/report.json"),
    "specSha256": sha(SPEC),
    "decisionSource": {"session": "ba383ac7-f3a0-4cbd-aff3-291f26881ccb",
                       "messageToolCallId": "toolu_014i52jcJ2b5Rv9g2avK8jHT"},
    "decision": "Coordinator adjudicated model-caused; retain original split panel and failed 14/16 result, no rerun.",
    "requirementQuote": "topicsFromTitle counts items with at least one topic whose every lower-cased topic is a token of the title",
    "evidence": [
        "spec-misread: the candidate uses topics.some; the requirement explicitly says every lower-cased topic.",
        "The nonempty condition and universal condition both apply to the item's topic list; a topic has no topics of its own.",
        "Only the two topicsFromTitle count checks fail; other audit values and all blind/scoring checks pass.",
        "Observed county/legislature counts are 7/5 versus 4/3; the second corpus's legislature count is 4 versus 2.",
    ],
    "clarityKnownIssue": {
        "round": 4, "changeV4DuringCohort": False,
        "proposedWording": "items whose topic list is nonempty and in which every lower-cased topic is a title token",
        "reconsiderationTrigger": "Flag if Sonnet also misses this exact clause; coordinator will reconsider task attribution.",
    },
    "publicationScope": "Sanitized attribution and immutable hashes; no raw messages, account data or credential state.",
}
data = (json.dumps(receipt, sort_keys=True, indent=2) + "\n").encode()
if DEST.exists():
    assert DEST.read_bytes() == data
else:
    with DEST.open("xb") as target:
        target.write(data)
print(sha(DEST))
