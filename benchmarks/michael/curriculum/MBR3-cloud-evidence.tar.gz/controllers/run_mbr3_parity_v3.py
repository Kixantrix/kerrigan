"""Immutable forward CLI-parity epoch; retain every physical attempt."""
import hashlib
import json
from pathlib import Path
import runpy
import sys
import yaml

OWNED = Path(__file__).parent
ROOT = OWNED / "mbr3-parity-v3"
OLD, PREVIOUS = OWNED / "mbr3-v1", OWNED / "mbr3-tooltip-v2"
driver = runpy.run_path(str(OWNED / "run_mbr3.py"), run_name="trusted_driver")
api, native, live, metrics = (driver[key] for key in ("api", "native", "live", "metrics"))
read = driver["read"]
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def persist(path, value):
    if path.exists():
        assert read(path) == value, "immutable parity plan differs"
    else:
        api.grader.persist(path, value)


def plan():
    proof = read(ROOT / "safety.json")
    assert proof["source"] == native.sources()
    previous = read(PREVIOUS / "primary-plan.json")
    rows = []
    for row in previous["attempts"]:
        item = dict(row)
        path = OWNED / row["evidence_root"] / "trials" / row["task"] / f"repeat-{row['repeat']}" / row["model"] / "outcome.json"
        if path.exists():
            outcome = read(path)
            assert outcome["quiescent"] is True
            if outcome["status"] in ("pass", "fail"):
                item["retained_verified_result"] = True
                rows.append(item)
                continue
            assert (row["task"], row["repeat"], row["model"]) == (
                "orchestrate-voice-integration-v5", 2, "mai-code-2")
            assert outcome["nativeStop"] == "broker:action_denied"
        item.update(evidence_root=ROOT.name, source_epoch="cli-parity-v3", retained_verified_result=False)
        rows.append(item)
    owner_path = "benchmarks/michael/local_transport/owner.mjs"
    source_epochs = {**previous["source_epochs"], "cli-parity-v3": {
        "ownerSha256": proof["source"][owner_path], "safetySha256": sha(ROOT / "safety.json")}}
    fault_run = PREVIOUS / "trials/orchestrate-voice-integration-v5/repeat-2/mai-code-2"
    fault_attribution = PREVIOUS / "attribution/orchestrate-voice-integration-v5/repeat-2/mai-code-2/attribution.json"
    assert read(fault_attribution)["cause"] == "harness"
    return {
        "scheduleSha256": sha(OLD / "schedule.json"), "source_epochs": source_epochs,
        "previousPlanSha256": sha(PREVIOUS / "primary-plan.json"),
        "attempts": rows, "excluded_priors": [
            {**previous["excluded_prior"], "evidence_root": OLD.name, "failure_modes": ["harness-error"]},
            {"task": "orchestrate-voice-integration-v5", "repeat": 2, "model": "mai-code-2",
             "evidence_root": PREVIOUS.name, "cause": "harness", "status": "ungraded",
             "behavior": "invented-path-read", "cutoff": "harness-policy",
             "failure_modes": ["invented-path-read"],
             "outcomeSha256": sha(fault_run / "outcome.json"), "attributionSha256": sha(fault_attribution)}],
        "pooling": "Retain eleven completed results. Two physical harness cutoffs excluded from task-failure denominator; new source epoch labeled. Old-rule sensitivity includes invented-path cutoff as unsuccessful.",
    }


def trials():
    primary = plan()
    persist(ROOT / "primary-plan.json", primary)
    proof = read(ROOT / "safety.json")
    for row in primary["attempts"]:
        task, repeat, model = row["task"], row["repeat"], row["model"]
        root = OWNED / row["evidence_root"]
        batch = root / "trials" / task / f"repeat-{repeat}"
        run = batch / model
        if not (run / "outcome.json").exists():
            assert root == ROOT
            assert read(OLD / "admission" / task / "admission.json")["decision"]["state"] in (
                "admitted", "admitted_with_findings")
            models = [r["model"] for r in primary["attempts"]
                      if r["task"] == task and r["repeat"] == repeat and r["evidence_root"] == ROOT.name]
            outcome = native.execute(OWNED, batch, task, model, models, proof, policy=driver["policy"](task))
        else:
            outcome = read(run / "outcome.json")
        assert outcome["quiescent"]
        print("subject", task, repeat, model, row["source_epoch"], outcome["status"],
              outcome["elapsedSeconds"], outcome.get("counts"), flush=True)
        if outcome["status"] != "pass":
            where = root / "attribution" / task / f"repeat-{repeat}" / model
            if not (where / "attribution.json").exists():
                live.attribution(OWNED, where, task, run, proof)
            attribution = read(where / "attribution.json")
            print("nonpass", task, repeat, model, attribution["cause"], flush=True)
            if attribution["cause"] != "model":
                raise RuntimeError("New non-model cause; retain slot without automatic retry")
    measured = []
    for row in primary["attempts"]:
        outcome = read(OWNED / row["evidence_root"] / "trials" / row["task"] /
                       f"repeat-{row['repeat']}" / row["model"] / "outcome.json")
        measured.append({**row, "resolved": outcome["status"] == "pass",
                         "completion_seconds": outcome["completionSeconds"],
                         "elapsed_seconds": outcome["elapsedSeconds"]})
    old_rule = [dict(row) for row in measured]
    for row in old_rule:
        if (row["task"], row["repeat"], row["model"]) == ("orchestrate-voice-integration-v5", 2, "mai-code-2"):
            row.update(resolved=False, completion_seconds=None)
    persist(ROOT / "repeated-summary.json", {
        "parity": metrics.repeated(measured), "oldRuleSensitivity": metrics.repeated(old_rule),
        "physicalAttempts": len(measured) + len(primary["excluded_priors"]),
        "logicalAttempts": len(measured), "rows": measured})


if __name__ == "__main__":
    if sys.argv[1] == "plan":
        persist(ROOT / "primary-plan.json", plan())
    elif sys.argv[1] == "trials":
        trials()
    else:
        raise ValueError("unknown parity command")
