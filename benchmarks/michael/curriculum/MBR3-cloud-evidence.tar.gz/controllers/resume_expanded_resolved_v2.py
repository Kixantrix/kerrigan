"""Preserve both YV split panels and every prior subject; resume unused slots only."""
from pathlib import Path
import runpy

from benchmarks.michael.matrix import generate

OWNED = Path(__file__).parent
namespace = runpy.run_path(str(OWNED / "run_mbr3_expanded_v5.py"), run_name="trusted_resume")
trials, read = namespace["trials"], namespace["read"]
root = OWNED / "mbr3-expanded-v5"
task = "yv-relevance-instrument-v4"
resolved_panels = {}
for repeat in (1, 3):
    run = root / "trials" / task / f"repeat-{repeat}/mai-code-2"
    panel = root / "attribution" / task / f"repeat-{repeat}/mai-code-2/attribution.json"
    resolved, resolution_sha = generate.resolved_attribution(root, task, repeat, "mai-code-2", run)
    assert resolved["cause"] == "model" and generate.failure_modes(resolved) == ["spec-misread"]
    resolved_panels[panel] = {**resolved, "deterministicResolutionSha256": resolution_sha}


def check_outcome(path, value):
    if path.name == "outcome.json" and task in path.parts and "claude-sonnet-5.5" in path.parts:
        if value["status"] == "fail":
            report = read(path.parent / "independent-grader/report.json")
            for row in report["assertions"]:
                if row["original_id"] not in (
                        "per-source corpus audit", "substantive government summaries change the finding"):
                    continue
                clause = row["checks"][0]["clause"]
                expected = clause[2] if clause[1] == ["sources"] else clause[2]["sources"]
                observed = row["observed"]["sources"]
                if any(observed[source]["topicsFromTitle"] != counts["topicsFromTitle"]
                       for source, counts in expected.items()):
                    raise RuntimeError("Coordinator reconsideration trigger: Sonnet also missed the exact topicsFromTitle clause; preserve slot.")
    return value


def resolved_read(path):
    value = read(path)
    if path in resolved_panels:
        assert value["cause"] == "unresolved"
        return resolved_panels[path]
    return check_outcome(path, value)


native = namespace["native"]
execute = native.execute


def execute_checked(owned, batch, name, model, models, safety, **options):
    outcome = execute(owned, batch, name, model, models, safety, **options)
    if Path(batch).is_relative_to(root / "trials"):
        check_outcome(Path(batch) / model / "outcome.json", outcome)
    return outcome


native.execute = execute_checked
trials.__globals__["read"] = resolved_read
trials()
