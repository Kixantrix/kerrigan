"""Continue the fixed cohort with disclosed source epochs and no slot reuse."""
import hashlib
import json
from pathlib import Path
import runpy
import sys
import yaml

OWNED = Path(__file__).parent
OLD = OWNED / "mbr3-v1"
ROOT = OWNED / "mbr3-tooltip-v2"
driver = runpy.run_path(str(OWNED / "run_mbr3.py"), run_name="trusted_driver")
api, native, live, metrics = (driver[key] for key in ("api", "native", "live", "metrics"))
read = driver["read"]
owner_path = "benchmarks/michael/local_transport/owner.mjs"
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def persist_once(path, value):
    if path.exists():
        assert read(path) == value, f"immutable continuation differs: {path.name}"
    else:
        api.grader.persist(path, value)


def retained(task, repeat, model):
    path = OLD / "trials" / task / f"repeat-{repeat}" / model / "outcome.json"
    if not path.exists():
        return False
    outcome = read(path)
    assert outcome["quiescent"] is True
    if outcome["status"] == "pass":
        return True
    attribution = read(OLD / "attribution" / task / f"repeat-{repeat}" / model / "attribution.json")
    if attribution["cause"] == "model":
        return True
    assert task == "orchestrate-voice-integration-v5" and repeat == 1
    assert model == "claude-sonnet-5.5" and outcome["nativeStop"] == "broker:action_denied"
    assert attribution["cause"] == "harness"
    return False


if sys.argv[1] == "safety":
    driver["safety"].__globals__["ROOT"] = ROOT
    driver["safety"]()
elif sys.argv[1] == "trials":
    proof = read(ROOT / "safety.json")
    assert proof["source"] == native.sources()
    schedule = read(OLD / "schedule.json")
    rows = []
    for item in schedule:
        for position, model in enumerate(item["models"]):
            keep = retained(item["task"], item["repeat"], model)
            rows.append({
                "task": item["task"], "repeat": item["repeat"], "model": model,
                "order": position,
                "source_epoch": "original-tooltip-v1" if keep else "policy-tooltip-v2",
                "evidence_root": OLD.name if keep else ROOT.name,
                "retained_verified_result": keep,
            })
    plan = {
        "scheduleSha256": sha(OLD / "schedule.json"),
        "source_epochs": {
            "original-tooltip-v1": {
                "ownerSha256": read(OLD / "safety.json")["source"][owner_path],
                "safetySha256": sha(OLD / "safety.json"),
            },
            "policy-tooltip-v2": {
                "ownerSha256": proof["source"][owner_path],
                "safetySha256": sha(ROOT / "safety.json"),
            },
        },
        "excluded_prior": {
            "task": "orchestrate-voice-integration-v5", "repeat": 1,
            "model": "claude-sonnet-5.5", "cause": "harness", "status": "ungraded",
            "outcomeSha256": sha(OLD / "trials/orchestrate-voice-integration-v5/repeat-1/claude-sonnet-5.5/outcome.json"),
            "attributionSha256": sha(OLD / "attribution/orchestrate-voice-integration-v5/repeat-1/claude-sonnet-5.5/attribution.json"),
        },
        "pooling": "Original five verified results retained; source epochs labeled per logical attempt. The ungraded harness-fault slot is excluded, not overwritten.",
        "attempts": rows,
    }
    persist_once(ROOT / "primary-plan.json", plan)
    for item in schedule:
        task, repeat = item["task"], item["repeat"]
        models = [model for model in item["models"] if not retained(task, repeat, model)]
        for model in item["models"]:
            keep = retained(task, repeat, model)
            run_root = OLD if keep else ROOT
            batch = run_root / "trials" / task / f"repeat-{repeat}"
            run = batch / model
            if not (run / "outcome.json").exists():
                assert read(OLD / "admission" / task / "admission.json")["decision"]["state"] in (
                    "admitted", "admitted_with_findings")
                outcome = native.execute(OWNED, batch, task, model, models, proof,
                                         policy=driver["policy"](task))
            else:
                outcome = read(run / "outcome.json")
            assert outcome["quiescent"]
            print("subject", task, repeat, model,
                  "original-tooltip-v1" if keep else "policy-tooltip-v2",
                  outcome["status"], outcome["elapsedSeconds"], outcome.get("counts"), flush=True)
            if outcome["status"] != "pass":
                where = run_root / "attribution" / task / f"repeat-{repeat}" / model
                if not (where / "attribution.json").exists():
                    live.attribution(OWNED, where, task, run, proof)
                attribution = read(where / "attribution.json")
                print("nonpass", task, repeat, model, attribution, flush=True)
                if attribution["cause"] != "model":
                    raise RuntimeError("Unresolved non-model cause; preserved slot, no automatic retry")
    measured = []
    for row in rows:
        outcome = read(OWNED / row["evidence_root"] / "trials" / row["task"] /
                       f"repeat-{row['repeat']}" / row["model"] / "outcome.json")
        measured.append({
            **row, "resolved": outcome["status"] == "pass",
            "completion_seconds": outcome["completionSeconds"],
        })
    persist_once(ROOT / "repeated-summary.json", metrics.repeated(measured))
else:
    raise ValueError("unknown continuation command")
