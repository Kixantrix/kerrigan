"""Publish complete cohort statistics and safe immutable bindings before the source merge."""
import argparse
import hashlib
import json
from pathlib import Path

from benchmarks.michael.matrix import generate
from benchmarks.michael.replay_trial import curriculum as native

OWNED = Path(__file__).parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--cohort", default="mbr3-expanded-v5", choices=(
    "mbr3-expanded-v5", "mbr3-successors-v7c", "mbr3-gapfill-v8", "mbr3-anchors-v10"))
alias = parser.parse_args().cohort
ROOT = OWNED / alias
label = {"mbr3-expanded-v5": "expanded", "mbr3-successors-v7c": "successors",
         "mbr3-gapfill-v8": "gapfill", "mbr3-anchors-v10": "anchors"}[alias]
DEST = generate.ROOT / f"benchmarks/michael/curriculum/MBR3-{label}-results.json"
read = lambda path: json.loads(path.read_bytes())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()

schedule = read(ROOT / "schedule.json")
selected = {(row["task"], row["repeat"], model) for row in schedule for model in row["models"]}
assert len(selected) == sum(len(row["models"]) for row in schedule) > 0
admitted = {path.parent.name for path in (ROOT / "admission").glob("*/admission.json")
            if read(path)["decision"]["state"] in ("admitted", "admitted_with_findings")}
assert {row["task"] for row in schedule} == admitted
assert all({row["repeat"] for row in schedule if row["task"] == task} == {1, 2, 3}
           for task in admitted)
assert read(ROOT / "safety.json")["source"] == native.sources()
records = generate.ledger_records(ROOT, selected=selected)
assert len(records) == len(selected)
summary = read(ROOT / "repeated-summary.json")
for model, result in summary["models"].items():
    rows = [row for row in records if row["model"] == model]
    assert len(rows) == result["attempts"] == len(schedule)
    assert sum(row["resolved"] for row in rows) == result["successes"]
subjects = []
for record in records:
    task, repeat, model = record["task"], record["repeat"], record["model"]
    batch = ROOT / "trials" / task / f"repeat-{repeat}"
    run = batch / model
    terminal = read(run / "receipt/terminal.json")
    assert terminal["nativePrompts"] == 1 and terminal["wholeProcessQuiescent"]
    assert terminal["cleanupSeconds"] <= 15
    assert all(row["reaped"] and not row["warnings"] for row in terminal["records"])
    row = {key: record[key] for key in
           ("task", "repeat", "model", "resolved", "completion_seconds", "failure_modes", "tokens")}
    row.update(
        counts=read(run / "outcome.json")["counts"],
        ledgerSha256=sha(batch / "ledger.jsonl"),
        collectedArtifactsSha256=sha(run / "collected-source.bin"),
        graderReportSha256=sha(run / "independent-grader/report.json"),
        rawTerminalSha256=sha(run / "receipt/terminal.json"),
        effectiveInventorySha256=sha(run / "receipt/inventory.json"),
        observedModel=terminal.get("observedModel") or "unknown",
        wholeProcessQuiescent=True, cleanupSeconds=terminal["cleanupSeconds"],
    )
    if not record["resolved"]:
        panel = ROOT / "attribution" / task / f"repeat-{repeat}" / model / "attribution.json"
        resolved, resolution_sha = generate.resolved_attribution(ROOT, task, repeat, model, run)
        assert resolved["cause"] == "model"
        row.update(originalPanelSha256=sha(panel), resolutionSha256=resolution_sha)
    subjects.append(row)
receipt = {
    "schema_version": 1, "kind": "completed-native-curriculum-cohort",
    "evidence_root": ROOT.name, "source_epoch": alias.removeprefix("mbr3-"),
    "logicalAttempts": len(selected), "physicalSubjectExecutions": len(selected),
    "harnessFaultReplacements": 0, "sourceMap": native.sources(),
    "scheduleSha256": sha(ROOT / "schedule.json"), "safetySha256": sha(ROOT / "safety.json"),
    "summarySha256": sha(ROOT / "repeated-summary.json"),
    "summary": summary, "subjects": subjects,
    "scope": ("Complete six-task scored schedule only. Admission and attribution calls are not scored subjects; original split panels are preserved."
              if alias == "mbr3-expanded-v5" else
              "Complete admitted-task scored schedule only. Admission and attribution calls are not scored subjects; rejected packages have no scored subjects and original panels are preserved."),
    "timingCaution": "Verified-time quantiles exclude failures and therefore use different successful-task mixtures; not clean standalone hardware performance.",
    "publication": "Safe allowlisted metadata and hashes; no raw terminal, messages, requests, account/quota/credit or credential contents.",
}
data = (json.dumps(receipt, sort_keys=True, separators=(",", ":")) + "\n").encode()
if DEST.exists():
    assert DEST.read_bytes() == data
else:
    with DEST.open("xb") as target:
        target.write(data)
print("sealed complete cohort", len(subjects), sha(DEST))
