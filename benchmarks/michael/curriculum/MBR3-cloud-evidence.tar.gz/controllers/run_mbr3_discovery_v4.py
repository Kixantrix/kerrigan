"""Resume only unresolved logical slots after one consolidated parity sweep."""
import hashlib
import json
from pathlib import Path
import runpy
import sys
import yaml

OWNED = Path(__file__).parent
ROOT = OWNED / "mbr3-discovery-v4"
PREVIOUS = OWNED / "mbr3-parity-v3"
driver = runpy.run_path(str(OWNED / "run_mbr3_parity_v3.py"), run_name="trusted_driver")
read, api, native = (driver[key] for key in ("read", "api", "native"))
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def plan():
    proof = read(ROOT / "safety.json")
    assert proof["source"] == native.sources()
    previous = read(PREVIOUS / "primary-plan.json")
    rows = []
    for row in previous["attempts"]:
        item = dict(row)
        path = OWNED / row["evidence_root"] / "trials" / row["task"] / f"repeat-{row['repeat']}" / row["model"] / "outcome.json"
        if path.exists():
            outcome = read(path)
            assert outcome["quiescent"]
            if outcome["status"] in ("pass", "fail"):
                item["retained_verified_result"] = True
                rows.append(item)
                continue
            assert (row["task"], row["repeat"], row["model"]) == (
                "orchestrate-voice-integration-v5", 2, "mai-code-2")
            assert outcome["nativeStop"] == "broker:action_denied"
        item.update(evidence_root=ROOT.name, source_epoch="discovery-parity-v4", retained_verified_result=False)
        rows.append(item)
    fault_run = PREVIOUS / "trials/orchestrate-voice-integration-v5/repeat-2/mai-code-2"
    fault_attribution = PREVIOUS / "attribution/orchestrate-voice-integration-v5/repeat-2/mai-code-2/attribution.json"
    assert read(fault_attribution)["cause"] == "harness"
    sweep = Path(native.api.packages.ROOT) / "benchmarks/michael/local_transport/mbr3-discovery-parity.json"
    assert read(sweep)["source"] == proof["source"]
    return {
        "scheduleSha256": previous["scheduleSha256"],
        "source_epochs": {**previous["source_epochs"], "discovery-parity-v4": {
            "ownerSha256": proof["source"]["benchmarks/michael/local_transport/owner.mjs"],
            "safetySha256": sha(ROOT / "safety.json")}},
        "previousPlanSha256": sha(PREVIOUS / "primary-plan.json"), "paritySweepSha256": sha(sweep),
        "attempts": rows, "excluded_priors": [
            *previous["excluded_priors"],
            {"task": "orchestrate-voice-integration-v5", "repeat": 2, "model": "mai-code-2",
             "evidence_root": PREVIOUS.name, "cause": "harness", "status": "ungraded",
             "behavior": "directory-read", "cutoff": "harness-policy", "failure_modes": ["harness-error"],
             "outcomeSha256": sha(fault_run / "outcome.json"), "attributionSha256": sha(fault_attribution)}],
        "pooling": "Retain eleven completed results, label all source epochs, exclude three physical discovery-policy cutoffs. Report invented-path behavior separately and old-rule logical sensitivity.",
    }


driver["trials"].__globals__.update(ROOT=ROOT, plan=plan)
if sys.argv[1] == "plan":
    driver["persist"](ROOT / "primary-plan.json", plan())
elif sys.argv[1] == "trials":
    driver["trials"]()
else:
    raise ValueError("unknown discovery command")
