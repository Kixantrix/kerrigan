"""Publish verified core ledgers and explicit native-metadata projections, never raw streams."""
from collections import Counter
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

from benchmarks.michael.curriculum import metrics
from benchmarks.michael.matrix import generate

OWNED = Path(__file__).parent
DEST = generate.ROOT / "benchmarks/michael/curriculum"
ROOT = OWNED / "mbr3-discovery-v4"
read = lambda path: json.loads(path.read_bytes())
sha = lambda data: hashlib.sha256(data).hexdigest()
encode = lambda value: (json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n").encode()
plan = read(ROOT / "primary-plan.json")
records, epoch_source = generate.epoch_records(ROOT / "primary-plan.json")
summary = read(ROOT / "repeated-summary.json")
lookup = {(row["task"], row["repeat"], row["model"]): row for row in records}
for row in summary["rows"]:
    observed = lookup[row["task"], row["repeat"], row["model"]]
    assert (row["resolved"], row["completion_seconds"]) == (
        observed["resolved"], observed["completion_seconds"])
assert len(records) == len(summary["rows"]) == 18 and summary["physicalAttempts"] == 21
old_first = [dict(row) for row in summary["rows"]]
for row in old_first:
    if any((row["task"], row["repeat"], row["model"]) == (prior["task"], prior["repeat"], prior["model"])
           for prior in plan["excluded_priors"]):
        row.update(resolved=False, completion_seconds=None)

members, projections = {}, []


def keep(path, alias=None):
    name = alias or path.relative_to(OWNED).as_posix()
    data = path.read_bytes()
    assert name not in members or members[name] == data
    members[name] = data


def native_projection(path):
    raw = path.read_bytes()
    value = json.loads(raw)
    fields = ("stopReason", "activeSeconds", "partialBudgetExhausted", "finalSourceError",
              "cleanupSeconds", "wholeProcessQuiescent", "actions", "actionBytes", "events",
              "protocolBytes", "evidenceDiskBytesBeforeTerminal", "unparsedProtocolBytesLowerBound",
              "requestedModel", "observedModel", "nativeStarts", "nativePrompts", "ownerRetries",
              "taskOutputBytesBeforeCutoff", "taskOutputRetainedBytes", "replayedActions", "verdict", "scratch")
    projection = {key: value[key] for key in fields if key in value}
    projection["records"] = [{key: row[key] for key in ("kind", "id", "reaped", "warnings", "finishedMs")
                              if key in row} for row in value["records"]]
    counters = ("model", "responseModel", "inputTokens", "outputTokens", "reasoningTokens",
                "cacheReadTokens", "cacheWriteTokens")
    projection["usage"] = [{key: row[key] for key in counters if key in row}
                           for row in value["usage"]] if isinstance(value["usage"], list) else "unknown"
    projection.update(projection="Safe metadata allowlist; messages/requests/raw streams/account/quota/credit/provider IDs excluded.",
                      rawTerminalSha256=sha(raw))
    name = path.relative_to(OWNED).as_posix()
    members[name] = encode(projection)
    projections.append({"path": name, "rawSha256": sha(raw), "projectionSha256": sha(members[name])})
    return value


aliases = {row["evidence_root"] for row in plan["attempts"]} | {
    row["evidence_root"] for row in plan["excluded_priors"]}
for alias in sorted(aliases):
    root = OWNED / alias
    keep(root / "safety.json")
    safety = read(root / "safety.json")
    snapshots = sorted(root.glob("trials/*/repeat-*/source-snapshot"))
    assert snapshots
    for path, digest in safety["source"].items():
        source = snapshots[0] / path
        assert sha(source.read_bytes()) == digest
        keep(source, alias + "/source-snapshot/" + path)
keep(OWNED / "mbr3-v1/schedule.json")
keep(ROOT / "primary-plan.json")
keep(ROOT / "repeated-summary.json")
identities = {}
for row in [*plan["attempts"], *plan["excluded_priors"]]:
    root = OWNED / row["evidence_root"]
    batch = root / "trials" / row["task"] / f"repeat-{row['repeat']}"
    run = batch / row["model"]
    keep(run / "outcome.json")
    terminal = native_projection(run / "receipt/terminal.json")
    identities.setdefault(row["model"], set()).update(
        terminal["observedModel"] if isinstance(terminal["observedModel"], list) else [])
    for relative in ("collected-source.bin", "independent-grader/report.json"):
        if (run / relative).is_file():
            keep(run / relative)
    attribution = root / "attribution" / row["task"] / f"repeat-{row['repeat']}" / row["model"] / "attribution.json"
    if attribution.is_file():
        keep(attribution)
    if row in plan["attempts"]:
        keep(batch / "ledger.jsonl")
for name in ("run_mbr3.py", "run_mbr3_tooltip_v2.py", "run_mbr3_parity_v3.py",
             "run_mbr3_discovery_v4.py", "resolve_orchestration_repeat2.py",
             "resume_discovery_resolved.py", "publish_mbr3_core.py"):
    keep(OWNED / name, "controllers/" + name)

archive_path = DEST / "MBR3-core-evidence.tar.gz"
buffer = io.BytesIO()
with gzip.GzipFile(fileobj=buffer, mode="wb", mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode="w") as archive:
        for name, data in sorted(members.items()):
            info = tarfile.TarInfo(name)
            info.mode, info.size, info.mtime = 0o600, len(data), 0
            archive.addfile(info, io.BytesIO(data))
archive_data = buffer.getvalue()
verification = {
    "schema_version": 1, "archiveFile": archive_path.name, "archiveSha256": sha(archive_data),
    "primaryPlanPath": "mbr3-discovery-v4/primary-plan.json", "localRunRoots": [],
    "members": {name: sha(data) for name, data in sorted(members.items())},
    "nativeTerminalProjections": projections, "logicalAttempts": 18, "physicalAttempts": 21,
    "scope": "Exact ledger chains, frozen benchmark conditions, artifacts, independent reports, original attributions and source snapshots. Native terminal metadata is projected; raw streams/messages/account/credentials/CLI configuration are not archived.",
}
results = {
    "schema_version": 1, "cohort": "round-three initial admitted three-task cohort",
    "complete": True, "logicalAttempts": 18, "physicalAttempts": 21,
    "metrics": summary["parity"], "oldMissingPathRuleSensitivity": summary["oldRuleSensitivity"],
    "firstPhysicalAllOriginalRulesSensitivity": metrics.repeated(old_first),
    "records": records, "sourceEpochs": plan["source_epochs"], "priorAttempts": epoch_source["prior_attempts"],
    "nativeObservedModelIds": {key: sorted(value) for key, value in identities.items()},
    "modelRevisions": {key: None for key in identities},
    "failureModeCounts": dict(Counter(mode for row in records for mode in row["failure_modes"])),
    "archiveSha256": sha(archive_data), "primaryPlanSha256": sha((ROOT / "primary-plan.json").read_bytes()),
    "limits": "Repeated variants/exposure and source epochs are labeled. Wilson intervals are descriptive, not independent-task population guarantees. Cost, peak model memory and energy remain unknown.",
}
for path, data in ((archive_path, archive_data),
                   (DEST / "MBR3-core-verification.json", encode(verification)),
                   (DEST / "MBR3-core-results.json", encode(results))):
    if path.exists():
        assert path.read_bytes() == data, "sealed core artifact differs"
    else:
        with path.open("xb") as target:
            target.write(data)
print("sealed core", len(members), "members", len(archive_data), "bytes", sha(archive_data))
