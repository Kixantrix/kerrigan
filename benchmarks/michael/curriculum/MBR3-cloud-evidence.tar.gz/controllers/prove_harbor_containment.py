"""Use the existing grader's exact container constructor; never start model inference."""
import argparse
import json
from pathlib import Path
import uuid

from benchmarks.michael.replay_grader import api as grader, specs
from benchmarks.michael.replay_trial import curriculum as native

TASKS = ("anchor-tb-fix-git", "anchor-tb-nginx-request-logging",
         "anchor-swepro-ansible", "anchor-swepro-openlibrary",
         "anchor-swepro-qutebrowser", "anchor-swepro-element-web",
         "anchor-swepro-tutanota")
PROBE = r"""
import ctypes, errno, json, os, socket
status = {}
for line in open("/proc/self/status"):
    key, _, value = line.partition(":")
    if key in ("CapEff", "CapBnd", "CapAmb", "NoNewPrivs"):
        status[key] = value.strip()
network = socket.socket()
network.settimeout(1)
try:
    network.connect(("198.51.100.1", 443))
    network_error = None
except OSError as error:
    network_error = error.errno
finally:
    network.close()
target = "/tmp/mbr3-owned-mount-probe"
os.mkdir(target)
libc = ctypes.CDLL(None, use_errno=True)
mounted = libc.mount(b"none", target.encode(), b"tmpfs", 0, None)
mount_error = ctypes.get_errno() if mounted else None
print(json.dumps({"uid": os.getuid(), "gid": os.getgid(), "status": status,
                  "interfaces": sorted(os.listdir("/sys/class/net")),
                  "networkErrno": network_error, "mountErrno": mount_error,
                  "dockerSocketPresent": os.path.exists("/var/run/docker.sock")}))
"""


def prove(root):
    source = native.sources()
    assert "benchmarks/michael/replay_grader/harbor_adapter.py" in source, "adapter must be source-pinned"
    safety = json.loads((root / "safety.json").read_bytes())
    assert safety["passed"] is True and safety["source"] == source
    expected_caps = sorted(["CHOWN", "DAC_OVERRIDE", "FOWNER", "FSETID",
                            "KILL", "NET_BIND_SERVICE", "SETGID", "SETUID"])
    assert sorted(grader.ANCHOR_CAPS) == expected_caps
    receipt = {"schema_version": 1, "kind": "actual-harbor-container-containment",
               "passed": False, "source": source, "tasks": {}, "modelPrompts": 0,
               "constructor": "unchanged replay_grader.api._create_anchor",
               "capScope": "Exact eight compatibility capabilities; not a claim that every task needs every cap."}
    for task in TASKS:
        specification = specs.spec(task)
        assert specification["runtime"] == "harbor"
        calibration = json.loads((root / "calibration" / task / "reference/independent-grader/report.json").read_bytes())
        assert calibration["status"] == "graded" and calibration["verdict"] == "pass"
        assert calibration["cleanup"]["proven"] is True
        image_id = calibration["image_id"]
        run_id = uuid.uuid4().hex
        name = "mb-harbor-proof-" + run_id
        observed = {"imageId": image_id, "passed": False}
        receipt["tasks"][task] = observed
        try:
            grader._create_anchor(specification, name, run_id, image_id)
            info = json.loads(grader.docker("inspect", name))[0]
            config = info["HostConfig"]
            caps = sorted(cap.removeprefix("CAP_") for cap in config["CapAdd"] or [])
            assert info["Config"]["User"] == "0:0" and info["Image"] == image_id
            assert info["Mounts"] == [] and config["Binds"] is None and not config["Privileged"]
            assert config["NetworkMode"] == "none" and config["PidMode"] in ("", "private")
            assert config["IpcMode"] != "host" and config["CapDrop"] == ["ALL"]
            assert caps == expected_caps and "no-new-privileges:true" in config["SecurityOpt"]
            assert 0 < config["Memory"] == config["MemorySwap"]
            assert config["NanoCpus"] == 1000000000 and 0 < config["PidsLimit"] <= 512
            observed["configured"] = {key: config[key] for key in
                ("NetworkMode", "PidMode", "IpcMode", "Privileged", "Binds", "CapDrop", "CapAdd",
                 "ReadonlyRootfs", "SecurityOpt", "Memory", "MemorySwap", "NanoCpus", "PidsLimit")}
            observed["configured"].update(User=info["Config"]["User"], Mounts=info["Mounts"])
            grader.docker("start", name)
            result = json.loads(grader.docker(
                "exec", name, specification["python"], "-I", "-B", "-c", PROBE))
            observed["runtime"] = result
            assert result["uid"] == result["gid"] == 0
            assert result["interfaces"] == ["lo"] and result["networkErrno"] in (101, 113)
            assert result["mountErrno"] == 1 and result["dockerSocketPresent"] is False
            assert int(result["status"]["CapEff"], 16) == int(result["status"]["CapBnd"], 16) == 0x4fb
            assert int(result["status"]["CapAmb"], 16) == 0 and result["status"]["NoNewPrivs"] == "1"
            observed["passed"] = True
        finally:
            observed["cleanup"] = grader.cleanup(run_id)
            grader.persist(root / "harbor-containment-proof.json", receipt)
    assert native.sources() == source
    receipt["passed"] = all(row["passed"] and row["cleanup"]["proven"] for row in receipt["tasks"].values())
    grader.persist(root / "harbor-containment-proof.json", receipt)
    return receipt


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", required=True, type=Path)
    print(json.dumps(prove(parser.parse_args().root), sort_keys=True))
