"""Seal the complete old-epoch foal cohort and report observed scratch headroom."""
import json
from pathlib import Path
from collections import Counter

from benchmarks.michael.matrix import generate
from benchmarks.michael.replay_trial import api

OWNED = Path(__file__).parent
DEST = generate.ROOT / "benchmarks/michael/curriculum"
read = lambda path: json.loads(path.read_bytes())
sha = lambda path: api.sha(path.read_bytes())


def persist(path, value):
    if path.exists():
        assert read(path) == value
    else:
        api.grader.persist(path, value)


root = OWNED / "mbr3-foal-v6"
schedule, safety = read(root / "schedule.json"), read(root / "safety.json")
selected = {(row["task"], row["repeat"], model) for row in schedule for model in row["models"]}
records = generate.ledger_records(root, selected=selected)
assert len(records) == 6 and all(row["resolved"] for row in records)
assert all(row["transport_source_sha256"] == generate.condition_digest(safety["source"]) for row in records)
snapshot = root / "trials/foal-meadow-regression-review-v2/repeat-1/source-snapshot"
assert all(sha(snapshot / name) == digest for name, digest in safety["source"].items())
subjects = []
for row in records:
    run = root / "trials" / row["task"] / f"repeat-{row['repeat']}" / row["model"]
    terminal = read(run / "receipt/terminal.json")
    assert terminal["wholeProcessQuiescent"] and terminal["cleanupSeconds"] <= 15
    assert all(record["reaped"] and not record["warnings"] for record in terminal["records"])
    subjects.append({**row, "counts": read(run / "outcome.json")["counts"],
        "rawTerminalSha256": sha(run / "receipt/terminal.json"),
        "graderReportSha256": sha(run / "independent-grader/report.json"),
        "effectiveInventorySha256": sha(run / "receipt/inventory.json"),
        "observedModel": terminal.get("observedModel") or "unknown",
        "wholeProcessQuiescent": True, "cleanupSeconds": terminal["cleanupSeconds"]})
persist(DEST / "MBR3-foal-results.json", {
    "schema_version": 1, "kind": "completed-native-curriculum-cohort",
    "evidence_root": root.name, "source_epoch": "foal-v6", "sourceMap": safety["source"],
    "logicalAttempts": 6, "physicalSubjectExecutions": 6, "harnessFaultReplacements": 0,
    "summary": read(root / "repeated-summary.json"), "subjects": subjects,
    "safetySha256": sha(root / "safety.json"), "scheduleSha256": sha(root / "schedule.json"),
    "summarySha256": sha(root / "repeated-summary.json"),
    "publication": "Allowlisted metadata/hashes only; no raw terminal, messages, requests, account/quota/credit/provider IDs."})

rows = []
for alias in ("mbr3-v1", "mbr3-tooltip-v2", "mbr3-parity-v3", "mbr3-discovery-v4",
              "mbr3-expanded-v5", "mbr3-foal-v6"):
    for path in sorted((OWNED / alias).glob("trials/*/repeat-*/*/receipt/terminal.json")):
        terminal = read(path)
        scratch = terminal["scratch"]
        rows.append({"path": path.relative_to(OWNED).as_posix(), "rawTerminalSha256": sha(path),
            "peakBytes": scratch["peakBytes"], "peakEntries": scratch["peakEntries"],
            "error": scratch.get("error"), "limits": scratch["limits"]})
assert len(rows) == 63 and all(row["error"] is None for row in rows)
maximum_bytes, maximum_entries = max(row["peakBytes"] for row in rows), max(row["peakEntries"] for row in rows)
persist(DEST / "MBR3-scratch-old-cap-proximity.json", {
    "schema_version": 1, "kind": "prior-scored-scratch-proximity",
    "physicalScoredSlots": len(rows),
    "byCohort": dict(Counter(row["path"].split("/")[0] for row in rows)),
    "scope": "All 63 physical scored round-three executions, including three retained non-scratch harness cutoffs. Admissions excluded. Rounds 1/2 predate sandbox scratch.",
    "oldLimits": {"bytes": 1048576, "entries": 128},
    "maxObservedBytes": maximum_bytes, "oldByteLimitFraction": maximum_bytes / 1048576,
    "maxObservedEntries": maximum_entries, "oldEntryLimitFraction": maximum_entries / 128,
    "scratchCutoffs": 0, "observations": rows,
    "measurementLimit": "Peaks are successful metadata scans at tool boundaries/100ms, not kernel high-water marks; transient unobserved growth cannot be excluded."})
print(json.dumps({"foal": {model: value["successes"] for model, value in
    read(root / "repeated-summary.json")["models"].items()},
    "priorPhysicalScoredSlots": len(rows), "maxBytes": maximum_bytes, "maxEntries": maximum_entries}))
