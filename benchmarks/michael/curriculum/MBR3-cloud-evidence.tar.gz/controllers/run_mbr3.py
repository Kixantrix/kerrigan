"""Closed A workstream: fresh gate, immutable schedule and exclusive repeated slots."""
import importlib.util
import json
from pathlib import Path
import sys

REPO = Path("/Users/mvh/.copilot/repos/copilot-worktrees/kerrigan/kixantrix-redesigned-barnacle")
OWNED = Path("/Users/mvh/.copilot/session-state/a45ee9a4-394e-4af7-afba-d8f78ae19672/files/local-mxc")
ROOT = OWNED / "mbr3-v1"
sys.path.insert(0, str(REPO))
from benchmarks.michael.replay_trial import api, curriculum as native
from benchmarks.michael.replay_grader import specs
from benchmarks.michael.curriculum import live, metrics
from benchmarks.michael.tasks import curriculum as tasks

TASKS = ("review-conflict-predictor-v4", "design-alethiometer-case-v3",
         "kerrigan-plan-conflict-queue-v3", "yv-relevance-instrument-v3",
         "emv-thumbnails-gallery-v3", "orchestrate-voice-integration-v5")
MODELS = ("mai-code-2", "claude-sonnet-5.5")
read = lambda path: json.loads(path.read_bytes())


def policy(name):
    return native.round_three_policy(name,
        active_seconds=10800 if tasks.meta(name).get("long_horizon") else 3600)


def safety():
    ROOT.mkdir(exist_ok=True)
    for name in TASKS:
        for label, data in (("base", specs.base(name)), ("reference", specs.reference(name))):
            folder = ROOT / "calibration" / name / label
            if (folder / "independent-grader/report.json").exists():
                assert read(folder / "curriculum-start.json")["source"] == native.sources()
                report = read(folder / "independent-grader/report.json")
            else:
                report = native.offline(OWNED, folder, name, data, policy=policy(name))
            retained = read(tasks.HERE / name / "calibration.json")
            phase = next(p for p in retained["phases"] if p["phase"] == ("baseline" if label == "base" else label))
            assert report["counts"] == phase["counts"]
            print("calibrated", name, label, report["counts"], flush=True)
    specification = importlib.util.spec_from_file_location("checks",
        REPO / "tests/projects/michael_bench/test_curriculum_native.py")
    checks = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(checks)
    for name in ("validator", "grouping"):
        folder = ROOT / ("scratch-proof-" + name)
        folder.mkdir()
        checks.test_round_three_tmpdir_write_run_cleanup_and_denial(OWNED, folder, name)
    proof = {"passed": True, "condition": "MB-R3", "source": native.sources(),
        "calibration": str(ROOT / "calibration"), "attester": "authorized-local-executor",
        "nativePrompts": 0, "classes": ["exact native calibration and Docker reference/base",
            "actual Node/Python sandbox scratch, denial/no-fork and disposal"],
        "subjectTargets": list(MODELS), "taskList": list(TASKS)}
    api.grader.persist(ROOT / "safety.json", proof)
    return proof


if __name__ == "__main__":
    command = sys.argv[1]
    if command == "safety":
        safety()
    else:
        proof = read(ROOT / "safety.json")
        assert proof["source"] == native.sources()
        if command == "admit":
            name = sys.argv[2]
            assert name in TASKS
            folder = ROOT / "admission" / name
            if (folder / "admission.json").exists():
                result = read(folder / "admission.json")
            else:
                result = live.admission(OWNED, folder, name, proof, active_seconds=policy(name)["activeSeconds"])
            print(name, result["decision"], flush=True)
        elif command == "trials":
            admitted = [name for name in TASKS if read(ROOT / "admission" / name / "admission.json")
                ["decision"]["state"] in ("admitted", "admitted_with_findings")]
            schedule = []
            for repeat in range(1, 4):
                for i, name in enumerate(admitted):
                    order = list(MODELS if (i + repeat - 1) % 2 == 0 else reversed(MODELS))
                    schedule.append({"task": name, "repeat": repeat, "models": order})
            path = ROOT / "schedule.json"
            if path.exists():
                assert read(path) == schedule
            else:
                api.grader.persist(path, schedule)
            for item in schedule:
                name, repeat, order = item["task"], item["repeat"], item["models"]
                batch = ROOT / "trials" / name / f"repeat-{repeat}"
                for model in order:
                    run = batch / model
                    if not (run / "outcome.json").exists():
                        # A slot that exists without a completed outcome is not retryable.
                        outcome = native.execute(OWNED, batch, name, model, order, proof, policy=policy(name))
                    else:
                        outcome = read(run / "outcome.json")
                    assert outcome["quiescent"]
                    print("subject", name, repeat, model, outcome["status"],
                        outcome["elapsedSeconds"], outcome.get("counts"), flush=True)
                    if outcome["status"] != "pass":
                        where = ROOT / "attribution" / name / f"repeat-{repeat}" / model
                        if not (where / "attribution.json").exists():
                            live.attribution(OWNED, where, name, run, proof)
                        attribution = read(where / "attribution.json")
                        print("nonpass", name, repeat, model, attribution, flush=True)
                        if attribution["cause"] != "model":
                            raise RuntimeError("Task/harness/ambiguous cause requires deterministic investigation; no automatic subject retry")
            rows = []
            for item in schedule:
                for position, model in enumerate(item["models"]):
                    outcome = read(ROOT / "trials" / item["task"] / f"repeat-{item['repeat']}" / model / "outcome.json")
                    rows.append({"task": item["task"], "model": model, "repeat": item["repeat"],
                        "order": position, "resolved": outcome["status"] == "pass",
                        "completion_seconds": outcome["completionSeconds"]})
            api.grader.persist(ROOT / "repeated-summary.json", metrics.repeated(rows))
        else:
            raise ValueError("Unknown closed command")
